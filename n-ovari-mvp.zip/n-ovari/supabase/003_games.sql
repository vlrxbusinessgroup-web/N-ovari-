-- ============================================================================
--  N-OVARI — Jeux : logique officielle  ·  003_games.sql  (script canonique)
-- ============================================================================
--  IDEMPOTENT : relançable autant de fois que nécessaire.
--
--  CONTENU
--    1. game_prizes   : lots, montants, poids (probabilités) par jeu
--    2. game_schedule : ouverture hebdomadaire par niveau sur 20 niveaux
--    3. game_sessions : journal de chaque partie (quotas jour/semaine, Tour+)
--    4. game_gifts    : lots physiques à livrer (cadeau, écouteurs, téléphone)
--    5. game_config() : état des 3 jeux (débloqué / jour / quotas / budget)
--    6. play_game()   : tirage pondéré + règlement, EN BASE
--
--  PROGRESSION DES ACCÈS SUR LES 20 NIVEAUX
--    • LV1 à LV2        : Aucun jeu accessible (« Débloqué au niveau 3 »)
--    • LV3 à LV6        : Roue 1×/semaine (Lundi uniquement)
--                         Grattage & Slots verrouillés
--    • LV7 à LV11       : Roue 2×/semaine (Lundi et Mercredi)
--                         Grattage 1×/semaine (jour au choix du membre)
--                         Slots verrouillé
--    • LV12 à LV16      : Roue 3×/semaine (Lundi, Mercredi, Vendredi)
--                         Grattage 2×/semaine (jours au choix)
--                         Slots 1×/semaine (jour au choix)
--    • LV17 à LV20 (VIP): Roue, Grattage, Slots 1×/jour chacun (accès quotidien)
-- ============================================================================

alter type wallet_tx_type add value if not exists 'game_reward';

-- ---------------------------------------------------------------------------
-- 1. TABLES
-- ---------------------------------------------------------------------------
create table if not exists public.game_prizes (
  id          uuid primary key default gen_random_uuid(),
  game_key    text not null check (game_key in ('wheel', 'scratch', 'slots')),
  position    int  not null,
  label       text not null,
  kind        text not null check (kind in ('cash', 'extra_spin', 'gift')),
  amount      numeric(12, 2) not null default 0,
  weight      numeric(8, 2)  not null default 0,
  symbol      text,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  unique (game_key, position)
);

create table if not exists public.game_schedule (
  id             uuid primary key default gen_random_uuid(),
  game_key       text not null check (game_key in ('wheel', 'scratch', 'slots')),
  level_min      int  not null,
  level_max      int  not null,
  weekdays       int[] not null,          -- 1 = lundi … 7 = dimanche (ISO)
  plays_per_day  int  not null default 1,
  plays_per_week int  not null default 1,
  created_at     timestamptz not null default now(),
  unique (game_key, level_min, level_max)
);

alter table public.game_schedule
  add column if not exists plays_per_week int not null default 1;

create table if not exists public.game_sessions (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null references public.profiles(id) on delete cascade,
  game_key        text not null,
  outcome_index   int,
  kind            text not null,
  amount          numeric(12, 2) not null default 0,
  label           text not null,
  consumed_quota  boolean not null default true,
  created_at      timestamptz not null default now()
);
create index if not exists game_sessions_user_day_idx
  on public.game_sessions (user_id, game_key, created_at desc);

create table if not exists public.game_gifts (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references public.profiles(id) on delete cascade,
  session_id   uuid references public.game_sessions(id) on delete set null,
  prize_label  text not null,
  game_key     text not null,
  status       text not null default 'pending'
                 check (status in ('pending', 'preparing', 'delivered', 'cancelled')),
  admin_note   text,
  processed_by uuid references public.profiles(id),
  processed_at timestamptz,
  created_at   timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- 2. LOTS OFFICIELS
-- ---------------------------------------------------------------------------
delete from public.game_prizes;

-- ROUE — 11 lots (position 0 → 10), total des poids = 100
insert into public.game_prizes (game_key, position, label, kind, amount, weight, symbol) values
  ('wheel',  0, '25 F',      'cash',       25, 30.00, 'coin'),
  ('wheel',  1, '100 F',     'cash',      100, 25.00, 'coin'),
  ('wheel',  2, 'Tour +',    'extra_spin',  0, 15.00, 'spin'),
  ('wheel',  3, '500 F',     'cash',      500, 10.00, 'coin'),
  ('wheel',  4, '1 000 F',   'cash',     1000,  5.00, 'coin'),
  ('wheel',  5, 'Cadeau',    'gift',        0,  5.00, 'gift'),
  ('wheel',  6, '5 000 F',   'cash',     5000,  5.00, 'coin'),
  ('wheel',  7, '15 000 F',  'cash',    15000,  2.50, 'coin'),
  ('wheel',  8, 'Écouteurs', 'gift',        0,  1.50, 'headphones'),
  ('wheel',  9, 'Téléphone', 'gift',        0,  0.50, 'phone'),
  ('wheel', 10, '25 000 F',  'cash',    25000,  0.50, 'coin');

-- GRATTAGE — 3 symboles identiques sur 9 cases
insert into public.game_prizes (game_key, position, label, kind, amount, weight, symbol) values
  ('scratch', 0, '25 F',    'cash',   25, 40.00, 'coin'),
  ('scratch', 1, '100 F',   'cash',  100, 40.00, 'coin'),
  ('scratch', 2, '500 F',   'cash',  500, 14.00, 'star'),
  ('scratch', 3, '1 000 F', 'cash', 1000,  5.00, 'star'),
  ('scratch', 4, 'Cadeau',  'gift',    0,  1.00, 'gift');

-- MACHINE À SOUS — 3 rouleaux identiques
insert into public.game_prizes (game_key, position, label, kind, amount, weight, symbol) values
  ('slots', 0, 'Aucun gain', 'cash',    0, 78.00, 'none'),
  ('slots', 1, '3 cerises',  'cash',  100, 17.00, 'cherry'),
  ('slots', 2, '3 cloches',  'cash',  500,  4.00, 'bell'),
  ('slots', 3, '3 diamants', 'cash', 2000,  1.00, 'gem');

-- ---------------------------------------------------------------------------
-- 3. CALENDRIER D'ACCÈS SUR 20 NIVEAUX (game_schedule)
--    LV1–LV2   : Aucun jeu accessible (« Débloqué au niveau 3 »)
--    LV3–LV6   : Roue 1×/semaine (Lundi) · Grattage & Slots verrouillés
--    LV7–LV11  : Roue 2×/semaine (Lundi, Mercredi) · Grattage 1×/semaine (au choix) · Slots verrouillé
--    LV12–LV16 : Roue 3×/semaine (Lundi, Mercredi, Vendredi) · Grattage 2×/semaine (au choix) · Slots 1×/semaine (au choix)
--    LV17–LV20 : Roue, Grattage, Slots 1×/jour chacun (accès quotidien VIP)
-- ---------------------------------------------------------------------------
delete from public.game_schedule;

insert into public.game_schedule
  (game_key, level_min, level_max, weekdays, plays_per_day, plays_per_week)
values
  -- LV3 à LV6 : Roue uniquement le lundi (1 fois / semaine)
  ('wheel',    3,  6, array[1],             1, 1),

  -- LV7 à LV11 : Roue lundi & mercredi (2×/sem) + Grattage 1×/semaine (au choix)
  ('wheel',    7, 11, array[1, 3],          1, 2),
  ('scratch',  7, 11, array[1,2,3,4,5,6,7], 1, 1),

  -- LV12 à LV16 : Roue lun/mer/ven (3×/sem) + Grattage 2×/sem (au choix) + Slots 1×/sem (au choix)
  ('wheel',   12, 16, array[1, 3, 5],       1, 3),
  ('scratch', 12, 16, array[1,2,3,4,5,6,7], 1, 2),
  ('slots',   12, 16, array[1,2,3,4,5,6,7], 1, 1),

  -- LV17 à LV20 (VIP) : les 3 jeux 1×/jour tous les jours
  ('wheel',   17, 20, array[1,2,3,4,5,6,7], 1, 7),
  ('scratch', 17, 20, array[1,2,3,4,5,6,7], 1, 7),
  ('slots',   17, 20, array[1,2,3,4,5,6,7], 1, 7);

-- ---------------------------------------------------------------------------
-- 4. PARAMÈTRES (reward_rules)
-- ---------------------------------------------------------------------------
insert into reward_rules (key, label, value, description) values
  ('game_unlock_level', 'Niveau minimum pour les jeux', '3',
   'Aucun jeu accessible pour LV1 et LV2 — déblocage au niveau 3'),
  ('game_scratch_unlock_level', 'Niveau minimum Grattage', '7',
   'Grattage débloqué à partir du niveau 7'),
  ('game_slots_unlock_level', 'Niveau minimum Machine à sous', '12',
   'Machine à sous débloquée à partir du niveau 12'),
  ('game_vip_level', 'Niveau VIP accès quotidien aux 3 jeux', '17',
   'LV17 à LV20 : 1 partie par jour sur chaque jeu + badge VIP doré'),
  ('game_monthly_budget_rate', 'Budget jeux mensuel (% du forfait)', '35',
   'Plafond des gains de jeu par mois civil, exprimé en % du prix du forfait'),
  ('game_reward_min', 'Gain minimum par partie', '25', 'Lot le plus fréquent (FCFA)'),
  ('game_reward_max', 'Gain maximum par partie', '25000', 'Jackpot en FCFA')
on conflict (key) do update set
  label = excluded.label,
  value = excluded.value,
  description = excluded.description;

-- Ancienne logique (v1) — retirée
drop function if exists public.play_game(text);
drop function if exists public.game_config();
drop function if exists public.game_pick_index();
drop function if exists public.game_prizes(numeric);
drop function if exists public.game_weights();

-- ---------------------------------------------------------------------------
-- 5. TIRAGE PONDÉRÉ
-- ---------------------------------------------------------------------------
-- VOLATILE obligatoire : une fonction STABLE serait évaluée une seule fois
-- par requête (résultat figé, tous les tirages identiques).
create or replace function public.game_pick_prize(p_game_key text)
returns public.game_prizes
language plpgsql
volatile
security definer
set search_path = public
as $$
declare
  v_total numeric := 0;
  v_roll  numeric;
  v_acc   numeric := 0;
  v_row   public.game_prizes;
begin
  select coalesce(sum(weight), 0) into v_total
    from public.game_prizes where game_key = p_game_key and is_active;

  if v_total <= 0 then
    raise exception 'Aucun lot configuré pour ce jeu';
  end if;

  v_roll := random() * v_total;

  for v_row in
    select * from public.game_prizes
     where game_key = p_game_key and is_active order by position
  loop
    v_acc := v_acc + v_row.weight;
    if v_roll < v_acc then return v_row; end if;
  end loop;

  select * into v_row from public.game_prizes
   where game_key = p_game_key and is_active order by position limit 1;
  return v_row;
end;
$$;

create or replace function public.weekday_label(p_weekday int)
returns text
language sql
immutable
as $$
  select (array['lundi','mardi','mercredi','jeudi','vendredi','samedi','dimanche'])[p_weekday];
$$;

-- ---------------------------------------------------------------------------
-- 6. ÉTAT DES JEUX POUR L'UTILISATEUR
-- ---------------------------------------------------------------------------
create or replace function public.game_config()
returns json
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_user    uuid := auth.uid();
  v_level   int := 0;
  v_pkg     text;
  v_price   numeric := 0;
  v_today   int := extract(isodow from now())::int;
  v_games   json;
  v_rate    numeric;
  v_budget  numeric;
  v_spent   numeric;
begin
  if v_user is null then raise exception 'Session expirée'; end if;

  select pk.level, pk.name, pk.price into v_level, v_pkg, v_price
    from public.member_packages mp
    join public.packages pk on pk.id = mp.package_id
   where mp.user_id = v_user and mp.status = 'active'
   order by mp.created_at desc
   limit 1;

  v_level := coalesce(v_level, 0);

  -- Budget jeux du mois civil
  select coalesce(value::numeric, 35) into v_rate
    from reward_rules where key = 'game_monthly_budget_rate';
  v_rate := coalesce(v_rate, 35);
  v_budget := round(v_price * v_rate / 100);

  select coalesce(sum(amount), 0) into v_spent
    from wallet_transactions
   where user_id = v_user and type = 'game_reward' and status = 'completed'
     and created_at >= date_trunc('month', now());

  select json_agg(game order by ord) into v_games
  from (
    select
      u.game_key,
      (u.open_day and u.plays_done_week < u.plays_per_week) as open_today,
      true as level_ok,
      u.level_min,
      u.level_max,
      u.weekdays,
      u.plays_per_day,
      u.plays_per_week,
      u.plays_done,
      u.plays_done_week,
      case
        when u.plays_done_week >= u.plays_per_week then
          (select min(d) from generate_series(8 - v_today, 14) as d
            where extract(isodow from (current_date + d))::int = any(u.weekdays))
        when u.plays_done >= u.plays_per_day then
          (select min(d) from generate_series(1, 7) as d
            where extract(isodow from (current_date + d))::int = any(u.weekdays))
        else
          (select min(d) from generate_series(0, 7) as d
            where extract(isodow from (current_date + d))::int = any(u.weekdays))
      end as next_in_days,
      u.ord
    from (
      select
        s.game_key,
        (v_today = any(s.weekdays)) as open_day,
        s.level_min,
        s.level_max,
        s.weekdays,
        s.plays_per_day,
        s.plays_per_week,
        (select count(*)::int from public.game_sessions gs
          where gs.user_id = v_user and gs.game_key = s.game_key
            and gs.consumed_quota
            and gs.created_at >= date_trunc('day', now())) as plays_done,
        (select count(*)::int from public.game_sessions gs
          where gs.user_id = v_user and gs.game_key = s.game_key
            and gs.consumed_quota
            and gs.created_at >= date_trunc('week', now())) as plays_done_week,
        case s.game_key when 'wheel' then 1 when 'scratch' then 2 else 3 end as ord
      from public.game_schedule s
      where v_level between s.level_min and s.level_max
    ) u
    union all
    -- Jeux pas encore débloqués : affichés verrouillés avec leur niveau minimal d'accès
    select g.game_key, false, false, g.level_min, m.level_max,
           m.weekdays, m.plays_per_day, m.plays_per_week, 0, 0, null,
           case g.game_key when 'wheel' then 1 when 'scratch' then 2 else 3 end
    from (select game_key, min(level_min) as level_min
            from public.game_schedule group by game_key) g
    join public.game_schedule m
      on m.game_key = g.game_key and m.level_min = g.level_min
    where v_level < g.level_min
  ) game;

  return json_build_object(
    'has_access', v_level >= 3,
    'unlock_level', coalesce((select min(level_min) from public.game_schedule), 3),
    'level', v_level,
    'package_name', v_pkg,
    'weekday_today', v_today,
    'budget_month', v_budget,
    'budget_used', v_spent,
    'budget_rate', v_rate,
    'games', coalesce(v_games, '[]'::json)
  );
end;
$$;

-- ---------------------------------------------------------------------------
-- 7. JOUER
-- ---------------------------------------------------------------------------
create or replace function public.play_game(p_game_key text)
returns json
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user      uuid := auth.uid();
  v_level     int := 0;
  v_price     numeric := 0;
  v_today     int := extract(isodow from now())::int;
  v_sched     public.game_schedule;
  v_min_lvl   int;
  v_prize     public.game_prizes;
  v_done      int := 0;
  v_done_week int := 0;
  v_limit     int := 1;
  v_rate      numeric;
  v_budget    numeric;
  v_spent     numeric;
  v_payload   json;
  v_session   uuid;
  v_gift      uuid;
  v_board     text[];
  v_reels     text[];
  v_others    text[];
  v_sym       text;
  i           int;
begin
  if v_user is null then raise exception 'Session expirée'; end if;
  if p_game_key not in ('wheel', 'scratch', 'slots') then
    raise exception 'Jeu inconnu';
  end if;
  if exists (select 1 from public.profiles where id = v_user and is_blocked) then
    raise exception 'Compte suspendu';
  end if;

  select pk.level, pk.price into v_level, v_price
    from public.member_packages mp
    join public.packages pk on pk.id = mp.package_id
   where mp.user_id = v_user and mp.status = 'active'
   order by mp.created_at desc limit 1;

  if v_level is null then
    raise exception 'Un forfait actif est requis pour jouer';
  end if;

  if v_level < 3 then
    raise exception 'Débloqué au niveau 3 (votre niveau actuel : LV%)', v_level;
  end if;

  select * into v_sched from public.game_schedule
   where game_key = p_game_key and v_level between level_min and level_max
   order by level_min limit 1;

  if v_sched.id is null then
    select min(level_min) into v_min_lvl
      from public.game_schedule where game_key = p_game_key;
    raise exception 'Niveau % requis pour ce jeu (votre niveau : LV%)',
      coalesce(v_min_lvl, 3), v_level;
  end if;

  if not (v_today = any(v_sched.weekdays)) then
    raise exception 'Ce jeu n''ouvre pas aujourd''hui (jours : %)', (
      select string_agg(public.weekday_label(w), ', ' order by w)
        from unnest(v_sched.weekdays) as w);
  end if;

  select count(*) into v_done from public.game_sessions
   where user_id = v_user and game_key = p_game_key and consumed_quota
     and created_at >= date_trunc('day', now());

  v_limit := v_sched.plays_per_day;
  if v_done >= v_limit then
    raise exception 'Vous avez déjà joué ce jeu aujourd''hui. Revenez à la prochaine ouverture.';
  end if;

  select count(*) into v_done_week from public.game_sessions
   where user_id = v_user and game_key = p_game_key and consumed_quota
     and created_at >= date_trunc('week', now());

  if v_done_week >= v_sched.plays_per_week then
    raise exception 'Quota hebdomadaire atteint (% / semaine). Revenez Lundi.', v_sched.plays_per_week;
  end if;

  -- Garde-fou : plafond mensuel des gains de jeu
  select coalesce(value::numeric, 35) into v_rate
    from reward_rules where key = 'game_monthly_budget_rate';
  v_rate := coalesce(v_rate, 35);
  v_budget := round(v_price * v_rate / 100);

  select coalesce(sum(amount), 0) into v_spent from wallet_transactions
   where user_id = v_user and type = 'game_reward' and status = 'completed'
     and created_at >= date_trunc('month', now());

  if v_budget > 0 and v_spent >= v_budget then
    raise exception 'Plafond mensuel de gains de jeu atteint (%). Il se réinitialise le 1er du mois.', round(v_budget);
  end if;

  -- TIRAGE (avant toute animation)
  v_prize := public.game_pick_prize(p_game_key);

  insert into public.game_sessions (user_id, game_key, outcome_index, kind, amount, label, consumed_quota)
  values (v_user, p_game_key, v_prize.position, v_prize.kind, v_prize.amount, v_prize.label,
          v_prize.kind <> 'extra_spin')
  returning id into v_session;

  -- Règlement
  if v_prize.kind = 'cash' and v_prize.amount > 0 then
    insert into public.wallet_transactions (user_id, amount, type, status, description, reference_id)
    values (v_user,
            least(v_prize.amount, greatest(v_budget - v_spent, 0)),
            'game_reward', 'completed',
            case p_game_key
              when 'wheel' then 'Roue de la fortune'
              when 'scratch' then 'Grattage N-OVARI'
              else 'Machine à sous'
            end || ' — ' || v_prize.label,
            v_session::text);

  elsif v_prize.kind = 'gift' then
    insert into public.game_gifts (user_id, session_id, prize_label, game_key)
    values (v_user, v_session, v_prize.label, p_game_key)
    returning id into v_gift;

    insert into public.notifications (user_id, title, body, type)
    values (v_user, 'Lot gagné : ' || v_prize.label,
            'Votre lot est enregistré. L''équipe N-OVARI vous contacte pour la remise.', 'reward');
  end if;

  -- Grille de grattage : UNE SEULE combinaison possible (gagnant ×3, autres ≤ ×2)
  if p_game_key = 'scratch' then
    v_sym := coalesce(v_prize.symbol, 'coin');
    v_others := array_remove(array['coin', 'star', 'gem', 'bell', 'cherry'], v_sym);

    v_board := array[v_sym, v_sym, v_sym];
    for i in 1..3 loop
      declare
        k int := 1 + floor(random() * array_length(v_others, 1))::int;
        picked text := v_others[k];
      begin
        while picked = any(v_board[4:array_length(v_board, 1)]) loop
          k := 1 + floor(random() * array_length(v_others, 1))::int;
          picked := v_others[k];
        end loop;
        v_board := v_board || array[picked, picked];
      end;
    end loop;

    for i in reverse 9..2 loop
      declare
        j int := 1 + floor(random() * i)::int;
        tmp text := v_board[i];
      begin
        v_board[i] := v_board[j];
        v_board[j] := tmp;
      end;
    end loop;
  end if;

  -- Rouleaux : 3 identiques en cas de gain, jamais 3 identiques sinon
  if p_game_key = 'slots' then
    if v_prize.symbol = 'none' then
      v_reels := array[
        (array['cherry','bell','gem'])[1 + floor(random() * 3)::int],
        (array['cherry','bell','gem'])[1 + floor(random() * 3)::int],
        (array['cherry','bell','gem'])[1 + floor(random() * 3)::int]];
      while v_reels[1] = v_reels[2] and v_reels[2] = v_reels[3] loop
        v_reels[3] := (array['cherry','bell','gem'])[1 + floor(random() * 3)::int];
      end loop;
    else
      v_reels := array[v_prize.symbol, v_prize.symbol, v_prize.symbol];
    end if;
  end if;

  v_payload := json_build_object(
    'game_key', p_game_key,
    'result_index', v_prize.position,
    'kind', v_prize.kind,
    'amount', v_prize.amount,
    'label', v_prize.label,
    'symbol', v_prize.symbol,
    'extra_spin', v_prize.kind = 'extra_spin',
    'gift_id', v_gift,
    'board', to_json(v_board),
    'reels', to_json(v_reels),
    'plays_done_today', v_done + case when v_prize.kind = 'extra_spin' then 0 else 1 end,
    'plays_limit', v_limit,
    'plays_done_week', v_done_week + case when v_prize.kind = 'extra_spin' then 0 else 1 end,
    'plays_limit_week', v_sched.plays_per_week,
    'budget_month', v_budget,
    'budget_used', v_spent + case when v_prize.kind = 'cash' then v_prize.amount else 0 end
  );

  return v_payload;
end;
$$;

-- ---------------------------------------------------------------------------
-- 8. RLS
-- ---------------------------------------------------------------------------
alter table public.game_prizes   enable row level security;
alter table public.game_schedule enable row level security;
alter table public.game_sessions enable row level security;
alter table public.game_gifts    enable row level security;

drop policy if exists "game_prizes_read" on public.game_prizes;
create policy "game_prizes_read" on public.game_prizes for select using (true);
drop policy if exists "game_prizes_admin" on public.game_prizes;
create policy "game_prizes_admin" on public.game_prizes
  for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "game_schedule_read" on public.game_schedule;
create policy "game_schedule_read" on public.game_schedule for select using (true);
drop policy if exists "game_schedule_admin" on public.game_schedule;
create policy "game_schedule_admin" on public.game_schedule
  for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "game_sessions_read_own" on public.game_sessions;
create policy "game_sessions_read_own" on public.game_sessions
  for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists "game_sessions_admin" on public.game_sessions;
create policy "game_sessions_admin" on public.game_sessions
  for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "game_gifts_read_own" on public.game_gifts;
create policy "game_gifts_read_own" on public.game_gifts
  for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists "game_gifts_admin" on public.game_gifts;
create policy "game_gifts_admin" on public.game_gifts
  for all using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------------------
-- 9. VÉRIFICATION
-- ---------------------------------------------------------------------------
select game_key, sum(weight) as poids_total, count(*) as lots
  from public.game_prizes group by game_key order by game_key;

select game_key, level_min, level_max, weekdays, plays_per_day, plays_per_week
  from public.game_schedule order by level_min, game_key;
