-- ============================================================================
--  N-OVARI — Schéma Supabase (MVP)  ·  SCRIPT CANONIQUE
--  Fichier : supabase/001_init.sql
--  Exécution : Supabase Dashboard > SQL Editor > Run
-- ============================================================================
--  Le script est IDEMPOTENT : vous pouvez le relancer sans perdre de données.
--
--  Décisions validées :
--    • Forfait À VIE : expires_at = null, aucun renouvellement imposé
--    • Parrainage : 1 seul niveau direct, prime créditée UNIQUEMENT quand
--      l'admin valide le paiement du filleul
--    • Le solde est TOUJOURS la somme de wallet_transactions (jamais stocké)
--    • Aucune récompense ne peut être créée depuis le client :
--      tout crédit passe par une fonction "security definer" ou par l'admin
-- ============================================================================

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------------------
-- 1. TYPES
-- ---------------------------------------------------------------------------
do $$ begin create type user_role as enum ('user', 'admin'); exception when duplicate_object then null; end $$;
do $$ begin create type validation_status as enum ('pending', 'approved', 'rejected'); exception when duplicate_object then null; end $$;
do $$ begin create type membership_status as enum ('pending', 'active', 'expired', 'rejected'); exception when duplicate_object then null; end $$;
do $$ begin create type referral_status as enum ('pending', 'validated', 'rejected'); exception when duplicate_object then null; end $$;
do $$ begin create type withdrawal_status as enum ('pending', 'processing', 'paid', 'rejected'); exception when duplicate_object then null; end $$;
do $$ begin create type wallet_tx_type as enum (
  'task_reward', 'referral_bonus', 'package_bonus', 'admin_credit',
  'withdrawal', 'withdrawal_reversal', 'adjustment'
); exception when duplicate_object then null; end $$;
do $$ begin create type wallet_tx_status as enum ('pending', 'completed', 'rejected'); exception when duplicate_object then null; end $$;
do $$ begin create type payment_method as enum ('tmoney', 'flooz'); exception when duplicate_object then null; end $$;
do $$ begin create type campaign_status as enum ('draft', 'active', 'paused', 'completed'); exception when duplicate_object then null; end $$;

-- ---------------------------------------------------------------------------
-- 2. PROFILES
-- ---------------------------------------------------------------------------
alter table profiles
  add column if not exists role user_role not null default 'user',
  add column if not exists referral_code text,
  add column if not exists referred_by text,
  add column if not exists active_package_id uuid,
  add column if not exists is_blocked boolean not null default false,
  add column if not exists email text,
  add column if not exists phone text,
  add column if not exists full_name text;

create unique index if not exists profiles_referral_code_key on profiles (referral_code);

-- Code parrain : "NV" + 6 caractères, sans caractères ambigus (pas de O/0/I/1)
create or replace function public.generate_referral_code()
returns text
language plpgsql
as $$
declare
  alphabet constant text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  candidate text;
  i int;
begin
  loop
    candidate := 'NV';
    for i in 1..6 loop
      candidate := candidate || substr(alphabet, floor(random() * length(alphabet))::int + 1, 1);
    end loop;
    exit when not exists (select 1 from public.profiles p where p.referral_code = candidate);
  end loop;
  return candidate;
end;
$$;

-- ---------------------------------------------------------------------------
-- 3. TRIGGER : profil + code parrain + parrainage à l'inscription
-- ---------------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_code_used text;
  v_sponsor_id uuid;
begin
  insert into public.profiles (id, full_name, phone, email, role, referral_code, referred_by)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', ''),
    new.raw_user_meta_data->>'phone',
    new.email,
    'user',
    public.generate_referral_code(),
    null
  )
  on conflict (id) do nothing;

  v_code_used := upper(trim(coalesce(new.raw_user_meta_data->>'referral_code_used', '')));

  if v_code_used <> '' then
    select p.id into v_sponsor_id
      from public.profiles p
     where upper(p.referral_code) = v_code_used
       and p.id <> new.id
     limit 1;

    if v_sponsor_id is not null then
      update public.profiles set referred_by = v_code_used
       where id = new.id and referred_by is null;

      -- Statut "pending" : la prime n'est créditée qu'à la validation du paiement
      insert into public.referrals (sponsor_id, referred_id, status)
      values (v_sponsor_id, new.id, 'pending')
      on conflict do nothing;
    end if;
  end if;

  insert into public.notifications (user_id, title, body, type)
  values (new.id, 'Bienvenue sur N-OVARI',
          'Regardez, gagnez, évoluez. Choisissez un forfait pour commencer.', 'info');

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------------
-- 4. PACKAGES — les 20 forfaits officiels
-- ---------------------------------------------------------------------------
alter table packages
  add column if not exists is_vip boolean not null default false,
  add column if not exists is_active boolean not null default true;

create unique index if not exists packages_level_key on packages (level);

insert into packages (level, name, price, tasks_per_day, daily_reward, bonus, is_vip, is_active)
values
  ( 1, 'LV1',    5100,  3,   160,    200, false, true),
  ( 2, 'LV2',   10000,  4,   320,    400, false, true),
  ( 3, 'LV3',   20000,  5,   640,    800, false, true),
  ( 4, 'LV4',   30000,  6,   960,   1200, false, true),
  ( 5, 'LV5',   40000,  7,  1280,   1600, false, true),
  ( 6, 'LV6',   50000,  8,  1600,   2000, false, true),
  ( 7, 'LV7',   65000,  9,  2080,   2600, false, true),
  ( 8, 'LV8',   80000, 10,  2560,   3200, false, true),
  ( 9, 'LV9',   95000, 11,  3040,   3800, false, true),
  (10, 'LV10', 110000, 12,  3520,   4400, false, true),
  (11, 'LV11', 130000, 13,  4160,   5200, false, true),
  (12, 'LV12', 150000, 15,  4800,   6000, false, true),
  (13, 'LV13', 200000, 18,  6000,   8000, false, true),
  (14, 'LV14', 250000, 20,  8000,  10000, false, true),
  (15, 'LV15', 300000, 25, 10000,  15000, false, true),
  (16, 'LV16', 400000, 30, 12500,  20000, false, true),
  (17, 'LV17', 500000, 35, 15000,  30000, true,  true),
  (18, 'LV18', 650000, 40, 20000,  40000, true,  true),
  (19, 'LV19', 800000, 45, 25000,  50000, true,  true),
  (20, 'LV20', 1000000, 50, 30000, 100000, true, true)
on conflict (level) do update set
  name = excluded.name,
  price = excluded.price,
  tasks_per_day = excluded.tasks_per_day,
  daily_reward = excluded.daily_reward,
  bonus = excluded.bonus,
  is_vip = excluded.is_vip;

-- ---------------------------------------------------------------------------
-- 5. COMPLÉMENTS DE COLONNES
-- ---------------------------------------------------------------------------
alter table test_payments
  add column if not exists admin_note text,
  add column if not exists reviewed_by uuid references profiles(id),
  add column if not exists reviewed_at timestamptz;

alter table wallet_transactions
  add column if not exists reference_id text,
  add column if not exists metadata jsonb;

alter table campaigns
  add column if not exists created_by uuid references profiles(id);

create index if not exists wallet_tx_user_created_idx on wallet_transactions (user_id, created_at desc);
create index if not exists wallet_tx_user_type_idx    on wallet_transactions (user_id, type);
create index if not exists test_payments_status_idx   on test_payments (status, created_at desc);
create index if not exists referrals_sponsor_idx      on referrals (sponsor_id);

-- ---------------------------------------------------------------------------
-- 6. FONCTIONS
-- ---------------------------------------------------------------------------

-- 6.1 L'appelant est-il administrateur ?
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
     where p.id = auth.uid() and p.role = 'admin'
  );
$$;

-- 6.2 Solde disponible réel (crédits − débits, hors pending/rejeté)
create or replace function public.wallet_balance(p_user_id uuid)
returns numeric
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(sum(
    case
      when t.type in ('withdrawal', 'adjustment') then -abs(t.amount)
      else abs(t.amount)
    end
  ), 0)
  from public.wallet_transactions t
  where t.user_id = p_user_id
    and t.status = 'completed';
$$;

-- 6.3 Validation d'un paiement (bouton "Valider" côté admin)
--     Active le forfait À VIE, crédite le bonus puis la prime de parrainage.
drop function if exists public.approve_payment(uuid, uuid);
drop function if exists public.approve_payment(uuid);

create or replace function public.approve_payment(p_payment_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_payment   test_payments;
  v_package   packages;
  v_sponsor   uuid;
  v_referral  referrals;
begin
  if not public.is_admin() then
    raise exception 'Action réservée à l''administration';
  end if;

  select * into v_payment from public.test_payments where id = p_payment_id for update;
  if v_payment is null then raise exception 'Paiement introuvable'; end if;
  if v_payment.status <> 'pending' then raise exception 'Ce paiement a déjà été traité'; end if;

  select * into v_package from public.packages where id = v_payment.package_id;

  -- a) Paiement validé
  update public.test_payments
     set status = 'approved', reviewed_by = auth.uid(), reviewed_at = now()
   where id = p_payment_id;

  -- b) Forfait À VIE (expires_at = null). Les anciens forfaits sont clôturés.
  update public.member_packages
     set status = 'expired'
   where user_id = v_payment.user_id and status in ('active', 'pending');

  insert into public.member_packages (user_id, package_id, status, payment_id, activated_at, expires_at)
  values (v_payment.user_id, v_payment.package_id, 'active', p_payment_id, now(), null);

  update public.profiles
     set active_package_id = v_payment.package_id
   where id = v_payment.user_id;

  -- c) Bonus d'activation
  insert into public.wallet_transactions (user_id, amount, type, status, description, reference_id)
  values (v_payment.user_id, v_package.bonus, 'package_bonus', 'completed',
          'Bonus d''activation ' || v_package.name, p_payment_id::text);

  -- d) Prime parrainage — UNIQUEMENT ici, après validation du paiement du filleul
  select * into v_referral
    from public.referrals
   where referred_id = v_payment.user_id and status = 'pending'
   limit 1;

  if v_referral.id is not null then
    update public.referrals
       set status = 'validated',
           validated_at = now(),
           bonus_amount = round(v_package.price
             * coalesce((select value::numeric from public.reward_rules where key = 'referral_bonus_rate'), 10) / 100)
     where id = v_referral.id
    returning * into v_referral;

    insert into public.wallet_transactions (user_id, amount, type, status, description, reference_id)
    values (v_referral.sponsor_id, v_referral.bonus_amount, 'referral_bonus', 'completed',
            'Prime de parrainage — filleul validé', v_referral.id::text);

    insert into public.notifications (user_id, title, body, type)
    values (v_referral.sponsor_id, 'Prime de parrainage créditée',
            'Votre filleul a validé son forfait ' || v_package.name || '.', 'reward');
  end if;

  -- e) Notification + traçabilité
  insert into public.notifications (user_id, title, body, type)
  values (v_payment.user_id, 'Forfait activé',
          'Votre forfait ' || v_package.name || ' est actif. Bonne découverte !', 'success');

  insert into public.audit_logs (actor_id, action, entity, entity_id, payload)
  values (auth.uid(), 'payment.approved', 'test_payments', p_payment_id::text,
          jsonb_build_object('user_id', v_payment.user_id, 'package_id', v_payment.package_id));
end;
$$;

-- 6.4 Rejet d'un paiement
create or replace function public.reject_payment(p_payment_id uuid, p_note text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare v_payment test_payments;
begin
  if not public.is_admin() then
    raise exception 'Action réservée à l''administration';
  end if;

  select * into v_payment from public.test_payments where id = p_payment_id for update;
  if v_payment is null then raise exception 'Paiement introuvable'; end if;
  if v_payment.status <> 'pending' then raise exception 'Ce paiement a déjà été traité'; end if;

  update public.test_payments
     set status = 'rejected', admin_note = nullif(trim(p_note), ''),
         reviewed_by = auth.uid(), reviewed_at = now()
   where id = p_payment_id;

  insert into public.notifications (user_id, title, body, type)
  values (v_payment.user_id, 'Paiement non validé',
          coalesce(nullif(trim(p_note), ''), 'Référence introuvable. Contactez le support.'), 'warning');

  insert into public.audit_logs (actor_id, action, entity, entity_id, payload)
  values (auth.uid(), 'payment.rejected', 'test_payments', p_payment_id::text,
          jsonb_build_object('note', p_note));
end;
$$;

-- 6.5 Fin d'une publicité → crédit de la récompense (contrôles serveur)
create or replace function public.complete_ad_task(p_task_id uuid)
returns json
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user    uuid := auth.uid();
  v_task    ad_tasks;
  v_package packages;
  v_done    int;
  v_already int;
begin
  if v_user is null then raise exception 'Session expirée'; end if;

  if exists (select 1 from profiles where id = v_user and is_blocked) then
    raise exception 'Compte suspendu';
  end if;

  -- Forfait actif obligatoire (règle LV0)
  select pk.* into v_package
    from member_packages mp
    join packages pk on pk.id = mp.package_id
   where mp.user_id = v_user and mp.status = 'active'
   order by mp.created_at desc
   limit 1;

  if v_package.id is null then
    raise exception 'Un forfait actif est requis pour effectuer des tâches';
  end if;

  select * into v_task from ad_tasks where id = p_task_id and is_active;
  if v_task.id is null then raise exception 'Publicité indisponible'; end if;

  if v_task.min_package_level > v_package.level then
    raise exception 'Votre forfait % ne donne pas accès à cette publicité', v_package.name;
  end if;

  -- Quota quotidien
  select count(*) into v_done
    from wallet_transactions
   where user_id = v_user and type = 'task_reward' and status = 'completed'
     and created_at >= date_trunc('day', now());

  if v_done >= v_package.tasks_per_day then
    raise exception 'Quota quotidien atteint (% publicités par jour avec le forfait %)',
      v_package.tasks_per_day, v_package.name;
  end if;

  -- Déjà vue aujourd'hui ?
  select count(*) into v_already
    from wallet_transactions
   where user_id = v_user and type = 'task_reward'
     and reference_id = p_task_id::text
     and created_at >= date_trunc('day', now());

  if v_already > 0 then
    raise exception 'Vous avez déjà été récompensé pour cette publicité aujourd''hui';
  end if;

  insert into wallet_transactions (user_id, amount, type, status, description, reference_id)
  values (v_user, v_task.reward, 'task_reward', 'completed', v_task.title, p_task_id::text);

  return json_build_object(
    'reward', v_task.reward,
    'tasks_done_today', v_done + 1,
    'tasks_limit', v_package.tasks_per_day
  );
end;
$$;

-- 6.6 Demande de retrait (solde vérifié côté serveur)
create or replace function public.request_withdrawal(
  p_amount numeric,
  p_method payment_method,
  p_destination text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user      uuid := auth.uid();
  v_balance   numeric;
  v_reserved  numeric;
  v_min       numeric;
begin
  if v_user is null then raise exception 'Session expirée'; end if;

  select coalesce(value::numeric, 2000) into v_min
    from reward_rules where key = 'withdrawal_min_amount';
  v_min := coalesce(v_min, 2000);

  if p_amount < v_min then
    raise exception 'Le retrait minimum est de % F', v_min;
  end if;

  v_balance := public.wallet_balance(v_user);

  select coalesce(sum(amount), 0) into v_reserved
    from withdrawal_requests
   where user_id = v_user and status in ('pending', 'processing');

  if p_amount > (v_balance - v_reserved) then
    raise exception 'Solde insuffisant : % F disponibles', (v_balance - v_reserved);
  end if;

  insert into withdrawal_requests (user_id, amount, method, destination, status)
  values (v_user, round(p_amount), p_method, trim(p_destination), 'pending');
end;
$$;

-- 6.7 Traitement d'un retrait par l'admin
create or replace function public.process_withdrawal(
  p_request_id uuid,
  p_action text,
  p_note text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare v_req withdrawal_requests;
begin
  if not public.is_admin() then raise exception 'Action réservée à l''administration'; end if;

  select * into v_req from withdrawal_requests where id = p_request_id for update;
  if v_req is null then raise exception 'Demande introuvable'; end if;
  if v_req.status in ('paid', 'rejected') then raise exception 'Demande déjà traitée'; end if;

  if p_action = 'paid' then
    update withdrawal_requests
       set status = 'paid', processed_by = auth.uid(), processed_at = now(),
           admin_note = nullif(trim(p_note), '')
     where id = p_request_id;

    insert into wallet_transactions (user_id, amount, type, status, description, reference_id)
    values (v_req.user_id, v_req.amount, 'withdrawal', 'completed',
            'Retrait ' || upper(v_req.method::text) || ' vers ' || v_req.destination,
            p_request_id::text);

    insert into notifications (user_id, title, body, type)
    values (v_req.user_id, 'Retrait payé',
            'Votre retrait a été envoyé sur ' || v_req.destination || '.', 'success');
  else
    update withdrawal_requests
       set status = 'rejected', processed_by = auth.uid(), processed_at = now(),
           admin_note = nullif(trim(p_note), '')
     where id = p_request_id;

    insert into notifications (user_id, title, body, type)
    values (v_req.user_id, 'Retrait rejeté',
            coalesce(nullif(trim(p_note), ''), 'Votre demande a été rejetée.'), 'warning');
  end if;

  insert into audit_logs (actor_id, action, entity, entity_id, payload)
  values (auth.uid(), 'withdrawal.' || p_action, 'withdrawal_requests', p_request_id::text,
          jsonb_build_object('amount', v_req.amount, 'note', p_note));
end;
$$;

-- 6.8 Liste des filleuls du parrain connecté (1 niveau direct)
create or replace function public.my_referrals()
returns table (
  referred_id uuid,
  full_name text,
  status referral_status,
  joined_at timestamptz,
  bonus_amount numeric,
  package_level int
)
language sql
stable
security definer
set search_path = public
as $$
  select r.referred_id,
         coalesce(p.full_name, 'Membre N-OVARI') as full_name,
         r.status::referral_status as status,
         r.created_at as joined_at,
         r.bonus_amount,
         pk.level as package_level
    from referrals r
    join profiles p on p.id = r.referred_id
    left join member_packages mp on mp.user_id = r.referred_id and mp.status = 'active'
    left join packages pk on pk.id = mp.package_id
   where r.sponsor_id = auth.uid()
   order by r.created_at desc;
$$;

-- ---------------------------------------------------------------------------
-- 7. ROW LEVEL SECURITY
-- ---------------------------------------------------------------------------
alter table profiles            enable row level security;
alter table packages            enable row level security;
alter table member_packages     enable row level security;
alter table test_payments       enable row level security;
alter table campaigns           enable row level security;
alter table ad_tasks            enable row level security;
alter table wallet_transactions enable row level security;
alter table withdrawal_requests enable row level security;
alter table referrals           enable row level security;
alter table reward_rules        enable row level security;
alter table audit_logs          enable row level security;
alter table notifications       enable row level security;

-- profiles
drop policy if exists "profiles_select_self_or_admin" on profiles;
create policy "profiles_select_self_or_admin" on profiles
  for select using (id = auth.uid() or public.is_admin());

drop policy if exists "profiles_update_self" on profiles;
create policy "profiles_update_self" on profiles
  for update using (id = auth.uid())
  with check (id = auth.uid() and role = (select p.role from profiles p where p.id = auth.uid()));

drop policy if exists "profiles_admin_all" on profiles;
create policy "profiles_admin_all" on profiles
  for all using (public.is_admin()) with check (public.is_admin());

-- packages (lecture publique, écriture admin)
drop policy if exists "packages_read_all" on packages;
create policy "packages_read_all" on packages for select using (true);

drop policy if exists "packages_admin_write" on packages;
create policy "packages_admin_write" on packages
  for all using (public.is_admin()) with check (public.is_admin());

-- member_packages (lecture seule côté utilisateur : l'activation est serveur)
drop policy if exists "member_packages_select_own" on member_packages;
create policy "member_packages_select_own" on member_packages
  for select using (user_id = auth.uid() or public.is_admin());

drop policy if exists "member_packages_admin_write" on member_packages;
create policy "member_packages_admin_write" on member_packages
  for all using (public.is_admin()) with check (public.is_admin());

-- test_payments
drop policy if exists "test_payments_select_own" on test_payments;
create policy "test_payments_select_own" on test_payments
  for select using (user_id = auth.uid() or public.is_admin());

drop policy if exists "test_payments_insert_own" on test_payments;
create policy "test_payments_insert_own" on test_payments
  for insert with check (user_id = auth.uid() and status = 'pending');

drop policy if exists "test_payments_admin_update" on test_payments;
create policy "test_payments_admin_update" on test_payments
  for update using (public.is_admin()) with check (public.is_admin());

-- campaigns / ad_tasks
drop policy if exists "campaigns_read_active" on campaigns;
create policy "campaigns_read_active" on campaigns
  for select using (status = 'active' or public.is_admin());

drop policy if exists "campaigns_admin_write" on campaigns;
create policy "campaigns_admin_write" on campaigns
  for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "ad_tasks_read_active" on ad_tasks;
create policy "ad_tasks_read_active" on ad_tasks
  for select using (is_active = true or public.is_admin());

drop policy if exists "ad_tasks_admin_write" on ad_tasks;
create policy "ad_tasks_admin_write" on ad_tasks
  for all using (public.is_admin()) with check (public.is_admin());

-- wallet_transactions : LECTURE seule pour l'utilisateur, jamais d'insert client
drop policy if exists "wallet_select_own" on wallet_transactions;
create policy "wallet_select_own" on wallet_transactions
  for select using (user_id = auth.uid() or public.is_admin());

drop policy if exists "wallet_admin_all" on wallet_transactions;
create policy "wallet_admin_all" on wallet_transactions
  for all using (public.is_admin()) with check (public.is_admin());

-- withdrawal_requests
drop policy if exists "withdrawals_select_own" on withdrawal_requests;
create policy "withdrawals_select_own" on withdrawal_requests
  for select using (user_id = auth.uid() or public.is_admin());

drop policy if exists "withdrawals_insert_own" on withdrawal_requests;
create policy "withdrawals_insert_own" on withdrawal_requests
  for insert with check (user_id = auth.uid() and status = 'pending');

drop policy if exists "withdrawals_admin_update" on withdrawal_requests;
create policy "withdrawals_admin_update" on withdrawal_requests
  for update using (public.is_admin()) with check (public.is_admin());

-- referrals
drop policy if exists "referrals_select_own" on referrals;
create policy "referrals_select_own" on referrals
  for select using (sponsor_id = auth.uid() or referred_id = auth.uid() or public.is_admin());

drop policy if exists "referrals_admin_all" on referrals;
create policy "referrals_admin_all" on referrals
  for all using (public.is_admin()) with check (public.is_admin());

-- reward_rules / notifications / audit_logs
drop policy if exists "reward_rules_read" on reward_rules;
create policy "reward_rules_read" on reward_rules for select using (true);

drop policy if exists "reward_rules_admin_write" on reward_rules;
create policy "reward_rules_admin_write" on reward_rules
  for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "notifications_select_own" on notifications;
create policy "notifications_select_own" on notifications
  for select using (user_id = auth.uid() or public.is_admin());

drop policy if exists "notifications_update_own" on notifications;
create policy "notifications_update_own" on notifications
  for update using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists "audit_logs_admin_read" on audit_logs;
create policy "audit_logs_admin_read" on audit_logs for select using (public.is_admin());

-- ---------------------------------------------------------------------------
-- 8. RÈGLES DE RÉCOMPENSE (paramétrables)
-- ---------------------------------------------------------------------------
insert into reward_rules (key, label, value, description) values
  ('task_timer_seconds',   'Durée du chronomètre publicitaire', '3',    'Secondes avant d''activer le bouton Suivant'),
  ('referral_bonus_rate',  'Taux de prime parrainage',          '10',   'Pourcentage du forfait du filleul crédité au parrain'),
  ('withdrawal_min_amount','Retrait minimum',                   '2000', 'Montant minimum de retrait en FCFA'),
  ('referral_depth',       'Profondeur du parrainage',          '1',    'Un seul niveau direct'),
  ('membership_mode',      'Durée du forfait',                  'lifetime', 'Forfait à vie (expires_at = null)')
on conflict (key) do update set value = excluded.value;

-- ---------------------------------------------------------------------------
-- 9. PASSAGE EN ADMINISTRATEUR
--    À exécuter une fois, après avoir créé votre compte via /auth :
--    update profiles set role = 'admin' where email = 'vous@exemple.com';
-- ---------------------------------------------------------------------------
