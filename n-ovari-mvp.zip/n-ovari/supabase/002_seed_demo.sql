-- ============================================================================
--  N-OVARI — Données de démonstration  ·  002_seed_demo.sql
-- ============================================================================
--  Objectif : peupler campagnes + publicités pour tester l'application de bout
--  en bout sans attendre de vrais annonceurs.
--
--  ⚠️ À N'EXÉCUTER QU'EN ENVIRONNEMENT DE TEST.
--     Les campagnes sont préfixées "[DÉMO]" pour être supprimables d'un bloc :
--
--       delete from ad_tasks
--        where campaign_id in (select id from campaigns where title like '[DÉMO]%');
--       delete from campaigns where title like '[DÉMO]%';
--
--  Les visuels sont servis par l'application elle-même (/creatives/pub-*.svg),
--  donc aucun bucket Storage n'est nécessaire pour démarrer. Pour de vraies
--  campagnes, remplacez image_url par l'URL publique du bucket `ad-creatives`.
--
--  Récompenses alignées sur les forfaits :
--    LV1 = 160 F/jour pour 3 tâches  → 160 F par publicité
--    LV5 = 1 280 F/jour pour 7 tâches → ~180 F par publicité
--  On reste donc sur 150–320 F par publicité pour rester cohérent avec la grille.
-- ============================================================================

-- 1. CAMPAGNES ---------------------------------------------------------------
insert into campaigns (advertiser, title, description, budget, status, starts_at, ends_at)
values
  ('Banque Démo SA', '[DÉMO] Ouverture de compte', 'Acquisition de comptes bancaires — cible Lomé et Kara.', 900000, 'active', now() - interval '10 days', now() + interval '60 days'),
  ('Télécom Démo', '[DÉMO] Offre data', 'Promotion forfaits data 4G+.', 600000, 'active', now() - interval '5 days', now() + interval '45 days'),
  ('École Démo', '[DÉMO] Formations en ligne', 'Catalogue de formations professionnelles certifiantes.', 350000, 'active', now() - interval '2 days', now() + interval '30 days'),
  ('Boutique Démo', '[DÉMO] Livraison 24 h', 'E-commerce avec paiement à la livraison.', 400000, 'active', now() - interval '1 day', now() + interval '21 days'),
  ('Assurance Démo', '[DÉMO] Assurance familiale', 'Souscription mobile, sans examen médical.', 250000, 'draft', null, null)
on conflict do nothing;

-- 2. PUBLICITÉS --------------------------------------------------------------
-- (reliées aux campagnes ci-dessus par leur titre)
insert into ad_tasks (campaign_id, title, image_url, target_url, reward, duration_seconds, min_package_level, is_active)
select c.id, v.title, v.image_url, v.target_url, v.reward, v.duration, v.min_level, true
from (values
  ('[DÉMO] Ouverture de compte', 'Ouvrez un compte en 5 minutes',        '/creatives/pub-1.svg', 'https://example.com/banque',    160, 3, 1),
  ('[DÉMO] Offre data',          'Doublez vos données mobiles',          '/creatives/pub-2.svg', 'https://example.com/telecom',   180, 3, 1),
  ('[DÉMO] Formations en ligne', 'Apprenez un métier 100 % en ligne',    '/creatives/pub-3.svg', 'https://example.com/formation', 200, 3, 2),
  ('[DÉMO] Livraison 24 h',      'Livraison en 24 h à Lomé',            '/creatives/pub-4.svg', 'https://example.com/boutique',  220, 3, 3),
  ('[DÉMO] Formations en ligne', 'Certificat reconnu en 6 semaines',     '/creatives/pub-3.svg', 'https://example.com/formation', 200, 3, 4),
  ('[DÉMO] Offre data',          'Forfait 4G+ dès 1 000 F',             '/creatives/pub-2.svg', 'https://example.com/telecom',   180, 3, 5),
  ('[DÉMO] Livraison 24 h',      'Payez à la livraison',                '/creatives/pub-4.svg', 'https://example.com/boutique',  240, 3, 6),
  ('[DÉMO] Ouverture de compte', 'Carte bancaire gratuite 1 an',        '/creatives/pub-1.svg', 'https://example.com/banque',    300, 3, 8)
) as v(campaign_title, title, image_url, target_url, reward, duration, min_level)
join campaigns c on c.title = v.campaign_title
where not exists (
  select 1 from ad_tasks t where t.title = v.title and t.campaign_id = c.id
);

-- 3. VÉRIFICATION ------------------------------------------------------------
-- Doit renvoyer 5 campagnes (dont 4 actives) et 8 publicités actives.
select
  (select count(*) from campaigns) as campagnes,
  (select count(*) from campaigns where status = 'active') as campagnes_actives,
  (select count(*) from ad_tasks where is_active) as publicites_actives;

-- ============================================================================
--  RAPPEL — pour tester le parcours complet :
--
--   1. Créez un compte via /auth
--   2. Passez-le administrateur :
--        update profiles set role = 'admin' where email = 'vous@exemple.com';
--   3. Déclarez un paiement (Forfaits → choisir un forfait → référence bidon)
--   4. Dans /admin → Paiements → « Valider »
--        → forfait actif À VIE + bonus crédité + prime parrain si applicable
--   5. /taches → regardez la pub, le chrono se débloque à 3 s, gain crédité
--   6. /portefeuille → le solde et l'historique reflètent l'ensemble
-- ============================================================================
