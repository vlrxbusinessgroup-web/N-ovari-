#!/usr/bin/env bash
# ============================================================================
#  N-OVARI — Tests base LOCAUX (hors Supabase)
# ----------------------------------------------------------------------------
#  Exécute réellement les scripts SQL du projet dans un PostgreSQL local, puis
#  vérifie les règles métier : tirages pondérés, quotas, plafond budgétaire,
#  grille de grattage, rouleaux, retraits, tâches, parrainage.
#
#  Prérequis : postgresql installé et démarré, droits sudo.
#  Usage : ./supabase/tests/run_local.sh
# ============================================================================
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

# PostgreSQL n'a pas accès aux fichiers du dépôt : on copie dans /tmp
for f in "$HERE/00_stub_supabase.sql" "$ROOT/supabase/001_init.sql" \
         "$ROOT/supabase/002_seed_demo.sql" "$ROOT/supabase/003_games.sql" \
         "$HERE/10_games_scenarios.sql"; do
  cp "$f" "$TMP/"
done
chmod 755 "$TMP"
chmod 644 "$TMP"/*.sql

run() { sudo -n -u postgres psql -q -v ON_ERROR_STOP=0 -d novari -f "$1"; }

sudo -n -u postgres psql -q -c "drop database if exists novari;" -c "create database novari;" >/dev/null
echo "→ harnais Supabase (schéma auth, auth.uid, 12 tables)"
run "$TMP/00_stub_supabase.sql"
echo "→ 001_init.sql"
run "$TMP/001_init.sql"
echo "→ 002_seed_demo.sql"
run "$TMP/002_seed_demo.sql"
echo "→ 003_games.sql (doit être idempotent : exécuté 2 fois)"
run "$TMP/003_games.sql"
run "$TMP/003_games.sql"
echo "→ scénarios métier"
run "$TMP/10_games_scenarios.sql"
echo "✔ terminé"
