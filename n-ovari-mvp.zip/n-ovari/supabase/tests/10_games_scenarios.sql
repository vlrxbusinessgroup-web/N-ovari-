-- ============================================================================
--  N-OVARI — Scénarios métier des jeux sur 20 niveaux (tests locaux)
--  Prérequis : 00_stub_supabase.sql + 001 + 002 + 003
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 0. JEU DE DONNÉES DE TEST (idempotent)
-- ---------------------------------------------------------------------------
insert into auth.users (id, email, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111','membre@novari.app',
   '{"full_name":"Kossi Test","phone":"+22890123456"}'),
  ('22222222-2222-2222-2222-222222222222','parrain@novari.app',
   '{"full_name":"Parrain Test"}'),
  ('33333333-3333-3333-3333-333333333333','filleul@novari.app',
   '{"full_name":"Filleul Test"}')
on conflict (id) do nothing;

update profiles set role = 'admin' where id = '11111111-1111-1111-1111-111111111111';

set app.uid = '11111111-1111-1111-1111-111111111111';

-- Helper : ouvre/ferme un jeu pour le niveau actif, aujourd'hui
create or replace function test_force_day(p_game text, p_open boolean) returns void
language plpgsql as $$
declare v_today int := extract(isodow from now())::int; v_level int;
begin
  select pk.level into v_level from member_packages mp join packages pk on pk.id=mp.package_id
   where mp.user_id=auth.uid() and mp.status='active' order by mp.created_at desc limit 1;
  update game_schedule
     set weekdays = case when p_open then array[v_today]
                         else array[((v_today) % 7) + 1] end
   where game_key = p_game and v_level between level_min and level_max;
end $$;

\echo '===== 0. Progression des accès sur 20 niveaux ====='
-- LV2 : aucun jeu accessible
update member_packages set status='expired' where user_id=auth.uid();
insert into member_packages (user_id, package_id, status, activated_at)
select auth.uid(), id, 'active', now() from packages where level = 2;
do $$ begin
  perform play_game('wheel');
  raise exception 'ECHEC : LV2 ne doit pas pouvoir jouer';
exception when others then
  raise notice 'OK LV2 bloqué -> %', sqlerrm;
end $$;

-- LV5 (palier LV3-LV6) : Roue débloquée, Grattage (LV7) et Slots (LV12) verrouillés
update member_packages set status='expired' where user_id=auth.uid();
insert into member_packages (user_id, package_id, status, activated_at)
select auth.uid(), id, 'active', now() from packages where level = 5;
do $$ begin
  perform play_game('scratch');
  raise exception 'ECHEC : Grattage devrait être verrouillé au LV5';
exception when others then
  raise notice 'OK LV5 Grattage verrouillé -> %', sqlerrm;
end $$;

-- LV8 (palier LV7-LV11) : Grattage débloqué (1×/semaine au choix), Slots (LV12) verrouillé
update member_packages set status='expired' where user_id=auth.uid();
insert into member_packages (user_id, package_id, status, activated_at)
select auth.uid(), id, 'active', now() from packages where level = 8;
do $$ begin
  perform play_game('slots');
  raise exception 'ECHEC : Slots devrait être verrouillé au LV8';
exception when others then
  raise notice 'OK LV8 Slots verrouillé -> %', sqlerrm;
end $$;

\echo '===== A. Grattage LV7 : 3 identiques sur 200 grilles ====='
update member_packages set status='expired' where user_id=auth.uid();
insert into member_packages (user_id, package_id, status, activated_at)
select auth.uid(), id, 'active', now() from packages where level = 7;
select test_force_day('scratch', true);
do $$
declare r json; b json; best int; i int;
begin
  for i in 1..200 loop
    delete from game_sessions where user_id=auth.uid();
    delete from wallet_transactions where user_id=auth.uid();
    r := play_game('scratch');
    b := r->'board';
    if json_array_length(b) <> 9 then raise exception 'grille de % cases', json_array_length(b); end if;
    select max(c) into best from (select count(*) c from json_array_elements_text(b) s group by s) x;
    if best <> 3 then raise exception 'grille invalide : % identiques (partie %)', best, i; end if;
  end loop;
  raise notice 'OK : 200 grilles de 9 cases, exactement 3 identiques';
end $$;

\echo '===== B. Slots LV12 : 300 parties cohérentes ====='
update member_packages set status='expired' where user_id=auth.uid();
insert into member_packages (user_id, package_id, status, activated_at)
select auth.uid(), id, 'active', now() from packages where level = 12;
select test_force_day('slots', true);
do $$
declare r json; reels json; same boolean; i int; gains numeric := 0;
begin
  for i in 1..300 loop
    delete from game_sessions where user_id=auth.uid();
    delete from wallet_transactions where user_id=auth.uid();
    r := play_game('slots');
    reels := r->'reels';
    same := (reels->>0) = (reels->>1) and (reels->>1) = (reels->>2);
    if (r->>'amount')::numeric > 0 and not same then raise exception 'gain sans alignement'; end if;
    if (r->>'amount')::numeric = 0 and same then raise exception 'alignement sans gain'; end if;
    gains := gains + (r->>'amount')::numeric;
  end loop;
  raise notice 'OK : 300 parties, gain moyen % F', round(gains/300, 1);
end $$;

\echo '===== C. Jour de fermeture & quota hebdomadaire ====='
update member_packages set status='expired' where user_id=auth.uid();
insert into member_packages (user_id, package_id, status, activated_at)
select auth.uid(), id, 'active', now() from packages where level = 5;
delete from game_sessions where user_id=auth.uid();
select test_force_day('wheel', false);
do $$ begin
  perform play_game('wheel');
  raise notice 'ECHEC : la roue aurait dû être fermée';
exception when others then raise notice 'OK : fermé -> %', sqlerrm; end $$;

-- Quota hebdomadaire : Grattage LV7 limité à 1×/semaine (plays_per_week = 1)
update member_packages set status='expired' where user_id=auth.uid();
insert into member_packages (user_id, package_id, status, activated_at)
select auth.uid(), id, 'active', now() from packages where level = 7;
delete from game_sessions where user_id=auth.uid();
insert into game_sessions (user_id, game_key, outcome_index, kind, amount, label, consumed_quota, created_at)
values (auth.uid(), 'scratch', 0, 'cash', 25, '25 F', true, date_trunc('week', now()) + interval '1 minute');
-- On force plays_per_day = 2 pour isoler le garde-fou hebdomadaire (plays_per_week = 1)
update game_schedule set plays_per_day = 2 where game_key = 'scratch' and level_min = 7;
do $$ begin
  perform play_game('scratch');
  raise notice 'ECHEC : quota hebdomadaire aurait dû bloquer';
exception when others then raise notice 'OK quota hebdo -> %', sqlerrm; end $$;
update game_schedule set plays_per_day = 1 where game_key = 'scratch' and level_min = 7;

\echo '===== D. Retrait : solde insuffisant puis OK ====='
delete from wallet_transactions where user_id=auth.uid();
delete from withdrawal_requests where user_id=auth.uid();
insert into wallet_transactions (user_id, amount, type, status) values (auth.uid(), 10000, 'task_reward', 'completed');
select wallet_balance(auth.uid()) as solde;
do $$ begin
  perform request_withdrawal(50000, 'tmoney', '+22890123456');
  raise notice 'ECHEC : retrait supérieur au solde accepté';
exception when others then raise notice 'OK : %', sqlerrm; end $$;
do $$ begin
  perform request_withdrawal(500, 'tmoney', '+22890123456');
  raise notice 'ECHEC : retrait sous le minimum accepté';
exception when others then raise notice 'OK : %', sqlerrm; end $$;
select request_withdrawal(5000, 'tmoney', '+22890123456');
do $$ begin
  perform request_withdrawal(6000, 'tmoney', '+22890123456');
  raise notice 'ECHEC : double engagement accepté';
exception when others then raise notice 'OK : %', sqlerrm; end $$;

\echo '===== E. Tâche publicitaire : crédit + quota + doublon ====='
delete from wallet_transactions where user_id=auth.uid();
delete from game_sessions where user_id=auth.uid();
select id as task1 from ad_tasks where min_package_level <= 5 order by min_package_level limit 1 \gset
select complete_ad_task(:'task1') as resultat;
do $$ begin
  perform complete_ad_task((select id from ad_tasks order by min_package_level limit 1));
  raise notice 'ECHEC : doublon accepté';
exception when others then raise notice 'OK doublon : %', sqlerrm; end $$;

\echo '===== F. my_referrals (parrain) ====='
set app.uid = '22222222-2222-2222-2222-222222222222';
select * from my_referrals();
