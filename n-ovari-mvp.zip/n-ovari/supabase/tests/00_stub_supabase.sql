-- ============================================================================
--  Harnais de test LOCAL (ne pas exécuter sur Supabase)
--  Reproduit le minimum de l'environnement Supabase : schéma auth, auth.uid(),
--  et les 12 tables telles que supposées par le projet.
-- ============================================================================
create schema if not exists auth;

create table if not exists auth.users (
  id uuid primary key default gen_random_uuid(),
  email text unique,
  raw_user_meta_data jsonb default '{}'::jsonb
);

-- auth.uid() simulé : lit le GUC "app.uid"
create or replace function auth.uid() returns uuid
language sql stable as $$ select nullif(current_setting('app.uid', true), '')::uuid $$;

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text, phone text, email text,
  role text not null default 'user',
  referral_code text, referred_by text, active_package_id uuid,
  is_blocked boolean not null default false,
  created_at timestamptz not null default now()
);
create table if not exists packages (
  id uuid primary key default gen_random_uuid(),
  level int, name text, price numeric,
  tasks_per_day int, daily_reward numeric, bonus numeric,
  is_vip boolean default false, is_active boolean default true,
  created_at timestamptz default now()
);
create table if not exists member_packages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  package_id uuid references packages(id),
  status text default 'pending', payment_id uuid,
  activated_at timestamptz, expires_at timestamptz,
  created_at timestamptz default now()
);
create table if not exists test_payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id), package_id uuid references packages(id),
  amount numeric, method text, reference text, status text default 'pending',
  admin_note text, reviewed_by uuid, reviewed_at timestamptz,
  created_at timestamptz default now()
);
create table if not exists campaigns (
  id uuid primary key default gen_random_uuid(),
  advertiser text, title text, description text, budget numeric,
  status text default 'draft', starts_at timestamptz, ends_at timestamptz,
  created_by uuid, created_at timestamptz default now()
);
create table if not exists ad_tasks (
  id uuid primary key default gen_random_uuid(),
  campaign_id uuid references campaigns(id), title text, image_url text,
  target_url text, reward numeric, duration_seconds int default 3,
  min_package_level int default 1, is_active boolean default true,
  created_at timestamptz default now()
);
create table if not exists wallet_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id), amount numeric, type text,
  status text default 'completed', description text, reference_id text,
  metadata jsonb, created_at timestamptz default now()
);
create table if not exists withdrawal_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id), amount numeric, method text,
  destination text, status text default 'pending', admin_note text,
  processed_by uuid, processed_at timestamptz, created_at timestamptz default now()
);
create table if not exists referrals (
  id uuid primary key default gen_random_uuid(),
  sponsor_id uuid references profiles(id), referred_id uuid references profiles(id),
  status text default 'pending', bonus_amount numeric, validated_at timestamptz,
  created_at timestamptz default now()
);
create table if not exists reward_rules (
  id uuid primary key default gen_random_uuid(),
  key text unique, label text, value text, description text,
  updated_at timestamptz default now()
);
create table if not exists audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid, action text, entity text, entity_id text,
  payload jsonb, created_at timestamptz default now()
);
create table if not exists notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id), title text, body text,
  type text default 'info', is_read boolean default false,
  created_at timestamptz default now()
);
