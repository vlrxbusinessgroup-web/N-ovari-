/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // Charte graphique N-OVARI
        brand: {
          DEFAULT: '#4C1D95', // Violet profond
          deep: '#3B0F7A',
          soft: '#6D28D9',
          tint: '#EDE9FE',
        },
        accent: {
          DEFAULT: '#F59E0B', // Orange
          soft: '#FBBF24',
          deep: '#D97706',
          tint: '#FEF3C7',
        },
        canvas: '#F8FAFC', // Fond clair
        ink: '#0F172A',
        muted: '#64748B',
        line: '#E2E8F0',
      },
      fontFamily: {
        sans: [
          '"Plus Jakarta Sans"',
          '"Inter"',
          'system-ui',
          '-apple-system',
          'Segoe UI',
          'Roboto',
          'sans-serif',
        ],
      },
      borderRadius: {
        '4xl': '2rem',
      },
      boxShadow: {
        soft: '0 4px 24px -8px rgba(15, 23, 42, 0.12)',
        card: '0 10px 40px -16px rgba(76, 29, 149, 0.18)',
        float: '0 18px 48px -20px rgba(76, 29, 149, 0.40)',
      },
      keyframes: {
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'pulse-soft': {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.55' },
        },
      },
      animation: {
        'fade-up': 'fade-up 0.35s ease-out both',
        'pulse-soft': 'pulse-soft 1.6s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};
