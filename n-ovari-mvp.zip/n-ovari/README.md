# N-OVARI — MVP

> **Regardez · Gagnez · Évoluez**
> Plateforme de récompenses publicitaires — marché africain (FCFA).

Stack : **React 18 + TypeScript + Tailwind CSS + Lucide React + Supabase**, Vite, mobile-first.

---

## 1. Démarrage

```bash
cd n-ovari
npm install

# 1) Configurer Supabase
cp .env.example .env
#   → renseigner VITE_SUPABASE_URL et VITE_SUPABASE_ANON_KEY
#   → renseigner les numéros de collecte T-Money / Flooz

# 2) Installer le schéma côté Supabase
#   Dashboard Supabase > SQL Editor > coller supabase/001_init.sql > Run
#   (optionnel, test) coller supabase/002_seed_demo.sql > Run
#    → 5 campagnes + 8 publicités de démonstration, visuels dans /public/creatives

# 3) Lancer
npm run dev      # http://localhost:5173
npm run typecheck
npm run build
```

> ⚠️ Tant que `.env` n'est pas renseigné, l'application affiche l'écran
> « Connexion Supabase requise ». C'est volontaire : **aucune donnée n'est simulée**.

---

## 2. Arborescence

```
n-ovari/
├─ supabase/
│  ├─ 001_init.sql            # schéma + triggers + RLS + seed 20 forfaits + 8 fonctions SQL
│  ├─ 002_seed_demo.sql       # campagnes + publicités de test (supprimables par préfixe [DÉMO])
│  ├─ 003_games.sql           # jeux : lots pondérés, calendrier, budget, play_game()
│  └─ tests/                  # harnais PostgreSQL local + scénarios métier
└─ src/
   ├─ App.tsx                 # routes principales + gardes (auth, admin, LV0)
   ├─ lib/
   │  ├─ supabase.ts          # client Supabase unique (+ TABLES, messages d'erreur FR)
   │  ├─ env.ts               # validation des variables d'environnement
   │  ├─ wallet.ts            # solde = somme signée des wallet_transactions
   │  ├─ payments.ts          # forfaits + déclaration de paiement manuel
   │  ├─ tasks.ts             # publicités + appel RPC complete_ad_task
   │  ├─ referrals.ts         # filleuls (RPC my_referrals)
   │  ├─ withdrawals.ts       # retrait (RPC request_withdrawal)
   │  ├─ admin.ts             # file de validation, campagnes, stats
   │  ├─ notifications.ts     # lecture + marquage lu (table notifications)
   │  ├─ games.ts             # game_config() / play_game() — aucun calcul client
   │  ├─ routes.ts · navigation.ts · format.ts · clipboard.ts · cn.ts
   ├─ types/database.ts       # typage des 12 tables + RPC
   ├─ public/creatives/       # visuels publicitaires de démonstration (SVG)
   ├─ context/AuthContext.tsx # session + profil + forfait actif + solde réel
   ├─ components/ui/          # Button, Badge, Modal, Feedback, Logo, PageHeader…
   ├─ components/layout/      # AppShell, BottomNav, NotificationsBell, RouteGuards, PackageGate
   ├─ components/games/       # GamesHub, LuckyWheel, Scratch, Slots, GameSymbol
   └─ pages/
      ├─ AuthPage.tsx              Connexion / inscription + code parrain
      ├─ DashboardPage.tsx         Solde, forfait, raccourcis
      ├─ PackagesPage.tsx          20 forfaits + modale T-Money / Flooz
      ├─ TasksPage.tsx             Publicité + chrono 3 s + crédit réel
      ├─ WalletPage.tsx            Solde, historique, demande de retrait
      ├─ ReferralPage.tsx          Code parrain, lien, filleuls
      ├─ AdminPage.tsx             Validation paiements, retraits, campagnes
      ├─ CareerPage.tsx            Progression LV1 → LV20
      ├─ SettingsPage.tsx          Profil, code parrain, déconnexion
      ├─ GamesPage.tsx             Jeux : hub, cadenas par niveau/jour, 3 jeux
      ├─ RestrictedAccessPage.tsx  Écran LV0
      └─ NotFoundPage.tsx
```

Un dossier `preview/` contient des captures des écrans (données de démonstration
uniquement — l'application réelle n'affiche que les données Supabase).

---

## 3. Routes (`src/App.tsx`)

| Route | Accès | Écran |
| --- | --- | --- |
| `/auth` | public | Connexion / Inscription (+ `?ref=CODE`) |
| `/` | session | Tableau de bord |
| `/forfaits` | session | 20 forfaits + paiement manuel |
| `/taches` | session **+ forfait** | Tâches publicitaires |
| `/jeux` | session **+ forfait** | Jeux |
| `/portefeuille` | session | Solde + historique + retrait |
| `/parrainage` | session | Code parrain + filleuls |
| `/carriere`, `/parametres` | session | Progression, compte |
| `/acces-restreint` | session | Écran LV0 |
| `/admin` | session **+ rôle admin** | Validation paiements, retraits, campagnes |

---

## 4. Règles métier — où elles sont appliquées

| Règle | Application |
| --- | --- |
| **LV0 = accès restreint** | `PackageGate` (routes `/taches`, `/jeux`) + contrôle serveur dans `complete_ad_task` |
| **Solde jamais en dur** | `lib/wallet.ts` : somme signée des `wallet_transactions` (`pending`/`rejected` exclus) |
| **Code parrain auto-généré** | trigger `handle_new_user` — format `NV` + 6 caractères, unicité vérifiée en base |
| **Parrainage 1 niveau** | table `referrals`, ligne `pending` à l'inscription ; RPC `my_referrals()` |
| **Prime après validation admin** | `approve_payment()` : forfait + bonus + prime crédités dans la même transaction |
| **Paiement manuel** | `test_payments` : référence saisie, statut `pending` imposé par la policy d'insertion |
| **Forfait à vie** | `member_packages.expires_at = null` (aucun renouvellement) |
| **Crédits impossibles côté client** | `wallet_transactions` : lecture seule pour l'utilisateur (RLS) ; écriture via RPC `security definer` |
| **Quota quotidien** | vérifié dans `complete_ad_task` (tâches/jour du forfait + anti-doublon du jour) |
| **Retrait fiable** | `request_withdrawal` (solde − demandes en cours, minimum lu dans `reward_rules`) |
| **Admin caché** | `RequireAdmin` + policies `is_admin()` : forcer l'URL ne donne aucun droit |
| **Jeux non truquables** | `play_game()` tire le gain en base ; le client n'envoie qu'un identifiant de jeu |
| **Quota de jeu** | `game_plays_per_day` dans `reward_rules` (3/jour), vérifié côté serveur |

### Fonctions SQL disponibles

`is_admin()` · `wallet_balance(uuid)` · `approve_payment(uuid)` · `reject_payment(uuid, text)` ·
`complete_ad_task(uuid)` · `request_withdrawal(numeric, payment_method, text)` ·
`process_withdrawal(uuid, text, text)` · `my_referrals()` · `game_config()` · `play_game(text)`

---

## 4 ter. Tester le parcours complet (5 minutes)

1. `supabase/001_init.sql`, puis `002_seed_demo.sql` et `003_games.sql`
2. Créer un compte via `/auth`
3. Passer le compte admin : `update profiles set role = 'admin' where email = 'vous@exemple.com';`
4. `/forfaits` → choisir un forfait → saisir une référence bidon (ex. `TM251026.0900.TEST1`)
5. `/admin` → Paiements → **Valider** → forfait actif à vie + bonus crédité (+ prime parrain)
6. `/taches` → la publicité s'affiche, le bouton se débloque à 3 s, gain crédité
7. `/jeux` → roue / grattage / machine à sous : tirage serveur, gain crédité,
   lot physique placé dans la file **Lots** de l'admin
8. `/portefeuille` → le solde et l'historique reflètent l'ensemble

Supprimer les données de démo :

```sql
delete from ad_tasks where campaign_id in (select id from campaigns where title like '[DÉMO]%');
delete from campaigns where title like '[DÉMO]%';
```

## 4 bis. Passer un compte en administrateur

```sql
update profiles set role = 'admin' where email = 'vous@exemple.com';
```

## 5. Charte appliquée

- Violet profond `#4C1D95` (+ `#6D28D9`, teinte `#EDE9FE`)
- Orange `#F59E0B` (+ `#D97706`, teinte `#FEF3C7`)
- Fond clair `#F8FAFC`, texte `#0F172A`
- `rounded-3xl`, ombres douces (`shadow-soft`, `shadow-float`)
- Barre de navigation fixe en bas (5 entrées), `max-w-md` centré
- Icônes **Lucide uniquement**, aucun emoji

---

## 6. État du MVP

| Module | État |
| --- | --- |
| Authentification + code parrain | ✅ |
| Tableau de bord (solde réel, forfait, raccourcis) | ✅ |
| 20 forfaits + paiement manuel T-Money/Flooz | ✅ |
| Tâches publicitaires (chrono 3 s, crédit serveur) | ✅ |
| Portefeuille (solde, historique, retrait) | ✅ |
| Parrainage (code, lien, filleuls) | ✅ |
| Administration cachée (paiements, retraits, campagnes) | ✅ |
| Notifications (cloche + marquage lu) | ✅ |
| Carrière / Paramètres | ✅ |
| Jeux (roue 11 lots, grattage, machine à sous) | ✅ |
| Lots physiques gagnés (file admin) | ✅ |

## 7. Prochaines étapes

1. **Upload des visuels** — bucket Storage `ad-creatives` + gestion `ad_tasks` dans l'admin
2. **Mise en ligne** — build, hébergement, domaine, checklist de production Supabase
   (SMTP, sauvegardes, confirmations d'e-mail, clés, quotas)
3. **Ajustements jeu** — les probabilités et le plafond de 35 % sont des
   recommandations : à arbitrer avec vos chiffres réels après 2–3 semaines
3. **Extensions** — notifications push/SMS, historique des parties de jeu, classement VIP

### Jeux — logique officielle

Déblocage **au LV3**. Trois jeux, tous tirés **en base** (`play_game`) : lots,
poids et calendrier vivent dans `game_prizes` et `game_schedule`, donc
modifiables sans redéploiement. Le résultat est tiré **avant** l'animation ;
celle-ci ne fait que le révéler.

**Roue — 11 lots (poids total = 100)**

| Groupe | Lots | Poids | Chance |
| --- | --- | --- | --- |
| Petits | 25 F · 100 F · **Tour+** | 30 · 25 · 15 | 70 % |
| Moyens | 500 F · 1 000 F · Cadeau | 10 · 5 · 5 | 20 % |
| Gros | 5 000 F · 15 000 F · Écouteurs | 5 · 2,5 · 1,5 | 9 % |
| Jackpot | Téléphone · 25 000 F | 0,5 · 0,5 | 1 % |

> Groupe « 9 % » : réparti 5 / 2,5 / 1,5 plutôt que 2 / 1 / 1 (qui ne totalise
> que 4). Le lot physique (Écouteurs) est le plus rare du groupe car il coûte
> de l'argent réel et de la logistique, contrairement aux gains FCFA.

**Tour+** — `kind = 'extra_spin'` : aucun crédit, `consumed_quota = false`, donc
le quota du jour n'est pas débité et le bouton reste actif.

**Grattage** — 9 cases ; le serveur garantit **une seule combinaison possible** :
le symbole gagnant apparaît exactement 3 fois, chaque autre symbole 2 fois au
maximum (aucun « j'avais 4 cerises » possible).
80 % petits lots (25 F, 100 F) · 19 % (500 F, 1 000 F) · 1 % Cadeau.

**Machine à sous** — 3 rouleaux (cerise / cloche / diamant), animation 2 s :
3 cerises = 100 F · 3 cloches = 500 F · 3 diamants = 2 000 F.
Probabilités : **78 % aucun gain · 17 % cerises · 4 % cloches · 1 % diamants**
(espérance ≈ 54 F/partie — jeu « à faible coût, forte émotion »).

**Calendrier d'accès sur les 20 niveaux (`game_schedule`)**

| Niveau | Roue | Grattage | Machine à sous | Particularité |
| --- | --- | --- | --- | --- |
| LV1–LV2 | Verrouillé | Verrouillé | Verrouillé | Cadenas « Débloqué au niveau 3 » |
| LV3–LV6 | 1×/semaine (Lundi) | Verrouillé (Niveau 7 requis) | Verrouillé (Niveau 12 requis) | « Revenez Lundi » hors lundi |
| LV7–LV11 | 2×/semaine (Lundi, Mercredi) | 1×/semaine (au choix) | Verrouillé (Niveau 12 requis) | — |
| LV12–LV16 | 3×/semaine (Lundi, Mercredi, Vendredi) | 2×/semaine (au choix) | 1×/semaine (au choix) | — |
| LV17–LV20 (VIP) | 1×/jour (tous les jours) | 1×/jour (tous les jours) | 1×/jour (tous les jours) | Badge « VIP » doré sur chaque carte |

**Garde-fou budgétaire** — `game_monthly_budget_rate` (défaut **35 %**) : les
gains de jeu d'un membre sont plafonnés, par mois civil, à 35 % du prix de son
forfait. Sans ce plafond, le jackpot à 25 000 F devient ingérable en LV3.

| Forfait | Coût jeux / mois (plein régime) | En % du forfait |
| --- | --- | --- |
| LV3 (20 000 F) | ≈ 6 200 F | 31 % |
| LV5 (40 000 F) | ≈ 13 200 F | 33 % |
| LV10 (110 000 F) | ≈ 20 500 F | 19 % |
| LV17 (500 000 F) | ≈ 50 000 F | 10 % |

*(événements rares inclus : ≈ 50 % du coût vient des jackpots et des lots
physiques chez les petits niveaux.)*

**Lots physiques** — cadeau, écouteurs et téléphone créent une ligne
`game_gifts` (`pending`) + une notification. Traitement dans l'onglet **Lots**
de `/admin` (« En préparation » → « Marquer livré »).

---

## 6 bis. Tests base (PostgreSQL local)

Les scripts SQL sont **exécutés pour de vrai** avant livraison :

```bash
./supabase/tests/run_local.sh
```

Le script monte un environnement Supabase minimal (schéma `auth`, `auth.uid()`,
les 12 tables), exécute `001` + `002` + `003` (deux fois, pour vérifier
l'idempotence) puis les scénarios métier :

- 20 000 tirages par jeu → distribution conforme (70/20/9/1 et 78/17/4/1)
- 300 grilles de grattage → exactement 3 symboles identiques, autres ≤ 2
- 300 parties de machine à sous → gain ⇔ alignement
- quota journalier, jour de fermeture, Tour+ sans débit de quota
- plafond mensuel des gains respecté au franc près
- retrait : solde insuffisant, minimum, double engagement
- tâche publicitaire : crédit, doublon refusé
- paiement manuel → forfait actif **à vie** + bonus + prime de parrainage

Ce harnais a permis de corriger trois défauts qui ne se voient pas à la lecture :
`game_pick_prize` déclarée `stable` (tous les tirages identiques),
`game_config()` en erreur SQL (`DISTINCT ON` + `UNION`), et des grilles de
grattage à 4–5 symboles identiques.

## 7. Prochaines étapes

1. **Upload des visuels** — bucket Storage `ad-creatives` + gestion `ad_tasks` dans l'admin
2. **Mise en ligne** — build, hébergement, domaine, checklist de production Supabase
   (SMTP, sauvegardes, confirmations d'e-mail, clés, quotas)
3. **Ajustements jeu** — les probabilités et le plafond de 35 % sont des
   recommandations : à arbitrer avec vos chiffres réels après 2–3 semaines
3. **Extensions** — notifications push/SMS, historique des parties de jeu, classement VIP

### Jeux — logique officielle

Trois jeux, tous **tirés en base** (`play_game`) et réglés là : lots, poids et
calendrier sont dans les tables `game_prizes` et `game_schedule`, donc
modifiables sans redéploiement.

**Roue — 11 lots pondérés (total 100)**

| Groupe | Lots | Poids | Chance |
| --- | --- | --- | --- |
| Petits | 25 F · 100 F · **Tour+** | 30 · 25 · 15 | 70 % |
| Moyens | 500 F · 1 000 F · Cadeau | 10 · 5 · 5 | 20 % |
| Gros | 5 000 F · 15 000 F · Écouteurs | 4,5 · 2,25 · 2,25 | 9 % |
| Jackpot | Téléphone · 25 000 F | 0,5 · 0,5 | 1 % |

> Les poids du groupe « 9 % » fournis (2 · 1 · 1 = 4) ne pouvaient pas peser 9 :
> ils sont normalisés proportionnellement (4,5 · 2,25 · 2,25) pour que le total
> fasse exactement 100 %. Ajustable dans `game_prizes`.

**Tour+** — `kind = 'extra_spin'` : rien n'est crédité et `consumed_quota = false`
dans `game_sessions`, donc le quota du jour n'est pas débité et le bouton reste actif.

**Grattage** — 9 cases, le serveur renvoie une grille contenant exactement
3 symboles identiques : 80 % petits lots (25 F, 100 F) · 19 % (500 F, 1 000 F) · 1 % Cadeau.

**Machine à sous** — 3 rouleaux (cerise / cloche / diamant), animation de 2 s :
3 cerises = 100 F · 3 cloches = 500 F · 3 diamants = 2 000 F.
*Probabilités non fournies dans la spécification : réglées à 76 % aucun gain ·
18 % cerises · 5 % cloches · 1 % diamants — à ajuster dans `game_prizes`.*

**Calendrier d'accès (`game_schedule`)**

| Niveau | Roue | Grattage | Machine à sous |
| --- | --- | --- | --- |
| LV0–1 | — | — | — |
| LV2–4 | lundi | — | — |
| LV5–9 | lundi, mercredi | 1 j/semaine (samedi) | — |
| LV10–16 | lundi, mercredi, vendredi | 2 j/semaine (mardi, samedi) | 1 j/semaine (jeudi) |
| LV17–20 (VIP) | tous les jours | tous les jours | tous les jours |

**Lots physiques** — cadeau, écouteurs et téléphone créent une ligne
`game_gifts` (statut `pending`) + une notification. L'admin les traite dans
l'onglet **Lots** de `/admin` (« En préparation » → « Marquer livré »).

## 7. Prochaines étapes

1. **Upload des visuels** — bucket Storage `ad-creatives` + gestion `ad_tasks` dans l'admin
2. **Mise en ligne** — build, hébergement, domaine, checklist de production Supabase
   (SMTP, sauvegardes, confirmations d'e-mail, clés, quotas)
3. **Ajustements jeu** — les probabilités et le plafond de 35 % sont des
   recommandations : à arbitrer avec vos chiffres réels après 2–3 semaines
3. **Extensions** — notifications push/SMS, historique des parties de jeu, classement VIP

### Grille des jeux — lots pondérés

Les 8 lots sont proportionnels au **gain quotidien du forfait** (`daily_reward`),
donc cohérents du LV1 au LV20. Le tirage est pondéré : les gros lots existent
mais tombent rarement (tirage effectué en base, dans `play_game`).

| Case | Lot (× gain quotidien) | Chance | LV1 | LV5 | LV20 |
| --- | --- | --- | --- | --- | --- |
| 1 | 0,03 × | 35 % | 20 F | 40 F | 900 F |
| 2 | 0,06 × | 25 % | 20 F | 80 F | 1 800 F |
| 3 | 0,10 × | 18 % | 20 F | 130 F | 3 000 F |
| 4 | 0,17 × | 10 % | 30 F | 220 F | 5 100 F |
| 5 | 0,25 × | 6 % | 40 F | 320 F | 7 500 F |
| 6 | 0,50 × | 3 % | 80 F | 640 F | 15 000 F |
| 7 | 1 × (gros lot) | 2 % | 160 F | 1 280 F | 30 000 F |
| 8 | 2 × (**jackpot**) | 1 % | 320 F | 2 560 F | 60 000 F |

Espérance mathématique ≈ **13 %** du gain quotidien par partie (≈ 39 % pour les
3 parties journalières du forfait) : les jackpots restent finançables.

| Clé `reward_rules` | Défaut | Effet |
| --- | --- | --- |
| `game_plays_per_day` | 3 | Parties récompensées par jour |
| `game_jackpot_multiplier` | 2 | Jackpot = multiple du gain quotidien (case 8) |
| `game_big_prize_multiplier` | 1 | Gros lot = multiple du gain quotidien (case 7) |

Pour des lots encore plus spectaculaires, montez `game_jackpot_multiplier`
(ex. `5` → jackpot LV20 = 150 000 F) : l'espérance passe alors à ≈ 17 %.
