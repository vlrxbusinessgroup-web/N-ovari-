import {
  Wallet,
  Crown,
  PlayCircle,
  Users,
  LayoutDashboard,
  Gamepad2,
  Briefcase,
  Settings,
  type LucideIcon,
} from 'lucide-react';
import { ROUTES } from '@/lib/routes';

export interface NavItem {
  label: string;
  shortLabel: string;
  path: string;
  icon: LucideIcon;
}

/** Barre de navigation fixe en bas — 5 entrées maximum (mobile-first) */
export const BOTTOM_NAV: NavItem[] = [
  { label: 'Tableau de bord', shortLabel: 'Accueil', path: ROUTES.dashboard, icon: LayoutDashboard },
  { label: 'Forfaits', shortLabel: 'Forfaits', path: ROUTES.packages, icon: Crown },
  { label: 'Tâches publicitaires', shortLabel: 'Tâches', path: ROUTES.tasks, icon: PlayCircle },
  { label: 'Portefeuille', shortLabel: 'Wallet', path: ROUTES.wallet, icon: Wallet },
  { label: 'Parrainage', shortLabel: 'Parrainage', path: ROUTES.referral, icon: Users },
];

/** Raccourcis de la grille du tableau de bord */
export const DASHBOARD_SHORTCUTS: NavItem[] = [
  { label: 'Jeux', shortLabel: 'Jeux', path: ROUTES.games, icon: Gamepad2 },
  { label: 'Parrainage', shortLabel: 'Parrainage', path: ROUTES.referral, icon: Users },
  { label: 'Carrière', shortLabel: 'Carrière', path: ROUTES.career, icon: Briefcase },
  { label: 'Paramètres', shortLabel: 'Paramètres', path: ROUTES.settings, icon: Settings },
];
