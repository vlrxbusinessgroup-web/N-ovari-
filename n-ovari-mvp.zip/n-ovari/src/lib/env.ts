/**
 * Lecture + validation des variables d'environnement.
 * On échoue "proprement" : l'application affiche un écran de configuration
 * plutôt qu'une page blanche si le .env est absent.
 */

const rawUrl = (import.meta.env.VITE_SUPABASE_URL ?? '').trim();
const rawAnonKey = (import.meta.env.VITE_SUPABASE_ANON_KEY ?? '').trim();

const isPlaceholder = (value: string) =>
  value === '' || value.includes('xxxxxxxx') || value.includes('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...');

export const env = {
  supabaseUrl: rawUrl,
  supabaseAnonKey: rawAnonKey,
  /** Numéros de collecte manuelle (T-Money / Flooz) */
  payment: {
    tmoney: import.meta.env.VITE_PAYMENT_TMONEY_NUMBER ?? '',
    flooz: import.meta.env.VITE_PAYMENT_FLOOZ_NUMBER ?? '',
  },
} as const;

/** true si le projet Supabase est correctement branché */
export const isSupabaseConfigured = !isPlaceholder(rawUrl) && !isPlaceholder(rawAnonKey);
