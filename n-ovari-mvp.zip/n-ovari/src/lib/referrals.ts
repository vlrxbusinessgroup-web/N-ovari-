/**
 * N-OVARI — Parrainage (1 seul niveau direct)
 * ----------------------------------------------------------------------------
 * La liste des filleuls est renvoyée par la fonction SQL `my_referrals()` :
 * un parrain ne peut pas lire librement la table `profiles` (RLS), il obtient
 * uniquement les informations strictement nécessaires de ses filleuls.
 */
import { supabase, TABLES, getErrorMessage } from './supabase';
import type { MyReferralRow } from '@/types/database';

export async function fetchMyReferrals(): Promise<MyReferralRow[]> {
  const { data, error } = await supabase.rpc('my_referrals');
  if (error) throw new Error(getErrorMessage(error));
  return (data ?? []) as MyReferralRow[];
}

export interface ReferralStats {
  total: number;
  validated: number;
  pending: number;
  earned: number;
}

export function computeReferralStats(rows: MyReferralRow[]): ReferralStats {
  return rows.reduce<ReferralStats>(
    (acc, row) => {
      acc.total += 1;
      if (row.status === 'validated') {
        acc.validated += 1;
        acc.earned += Number(row.bonus_amount ?? 0);
      } else if (row.status === 'pending') {
        acc.pending += 1;
      }
      return acc;
    },
    { total: 0, validated: 0, pending: 0, earned: 0 },
  );
}

export const REFERRAL_STATUS_META: Record<
  MyReferralRow['status'],
  { label: string; tone: 'accent' | 'success' | 'danger' }
> = {
  pending: { label: 'En attente', tone: 'accent' },
  validated: { label: 'Validé', tone: 'success' },
  rejected: { label: 'Rejeté', tone: 'danger' },
};

/** Règle de prime affichée à l'utilisateur (lue dans reward_rules) */
export async function fetchReferralBonusRule(): Promise<string | null> {
  const { data, error } = await supabase
    .from(TABLES.rewardRules)
    .select('value')
    .eq('key', 'referral_bonus_rate')
    .maybeSingle();
  if (error) return null;
  return (data as { value: string } | null)?.value ?? null;
}
