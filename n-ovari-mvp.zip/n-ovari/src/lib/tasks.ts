/**
 * N-OVARI — Tâches publicitaires
 * ----------------------------------------------------------------------------
 * Le crédit de la récompense n'est JAMAIS effectué depuis le client : il passe
 * par la fonction SQL `complete_ad_task` (security definer) qui vérifie
 * elle-même le forfait actif, le niveau minimum, le quota quotidien et le
 * doublon de la journée. C'est ce qui rend impossible la fabrication de solde
 * depuis la console du navigateur.
 */
import { supabase, TABLES, getErrorMessage } from './supabase';
import type { AdTask, Package, WalletTransaction } from '@/types/database';

/** Publicités actives, compatibles avec le niveau du membre */
export async function fetchActiveTasks(): Promise<AdTask[]> {
  const { data, error } = await supabase
    .from(TABLES.adTasks)
    .select('*, campaign:campaigns(*)')
    .eq('is_active', true)
    .order('created_at', { ascending: true });

  if (error) throw new Error(getErrorMessage(error));
  return (data ?? []) as AdTask[];
}

/** Début de la journée locale (minuit) au format ISO */
export function startOfToday(): string {
  const date = new Date();
  date.setHours(0, 0, 0, 0);
  return date.toISOString();
}

/**
 * Tâches déjà récompensées aujourd'hui.
 * Renvoie les `reference_id` (= id de la publicité) des gains du jour.
 */
export async function fetchTodayCompletions(userId: string): Promise<WalletTransaction[]> {
  const { data, error } = await supabase
    .from(TABLES.walletTransactions)
    .select('*')
    .eq('user_id', userId)
    .eq('type', 'task_reward')
    .gte('created_at', startOfToday())
    .order('created_at', { ascending: false });

  if (error) throw new Error(getErrorMessage(error));
  return (data ?? []) as WalletTransaction[];
}

export interface CompleteTaskResult {
  reward: number;
  tasks_done_today: number;
  tasks_limit: number;
}

/**
 * Termine une publicité et crédite la récompense (côté serveur).
 * Lève une erreur lisible si le quota est atteint ou si la pub a déjà été vue.
 */
export async function completeAdTask(taskId: string): Promise<CompleteTaskResult> {
  const { data, error } = await supabase.rpc('complete_ad_task', { p_task_id: taskId });
  if (error) throw new Error(getErrorMessage(error));
  return data as CompleteTaskResult;
}

/** Une publicité est-elle éligible au niveau du forfait ? */
export function isTaskEligible(task: AdTask, level: number): boolean {
  return task.min_package_level <= level;
}

/** Combien de publicités restent à voir aujourd'hui ? */
export function remainingQuota(
  pkg: Package | null,
  completedIds: string[],
): number {
  if (!pkg) return 0;
  return Math.max(0, pkg.tasks_per_day - completedIds.length);
}
