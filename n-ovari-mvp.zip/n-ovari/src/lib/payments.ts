/**
 * N-OVARI — Forfaits & paiements manuels
 * ----------------------------------------------------------------------------
 * Aucun montant n'est défini ici : prix, quotas et bonus viennent de la table
 * `packages`. Le paiement est manuel (T-Money / Flooz) : l'utilisateur envoie
 * l'argent puis colle sa référence ; le forfait n'est activé qu'après
 * validation de l'administration (test_payments.status = 'approved').
 */
import { supabase, TABLES, getErrorMessage } from './supabase';
import { env } from './env';
import type { Package, PaymentMethod, TestPayment } from '@/types/database';

/** Liste officielle des 20 forfaits (LV1 → LV20), triée par niveau */
export async function fetchPackages(): Promise<Package[]> {
  const { data, error } = await supabase
    .from(TABLES.packages)
    .select('*')
    .eq('is_active', true)
    .order('level', { ascending: true });

  if (error) throw new Error(getErrorMessage(error));
  return (data ?? []) as Package[];
}

/** Paiements de l'utilisateur connecté (du plus récent au plus ancien) */
export async function fetchMyPayments(userId: string): Promise<TestPayment[]> {
  const { data, error } = await supabase
    .from(TABLES.testPayments)
    .select('*, package:packages(*)')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(20);

  if (error) throw new Error(getErrorMessage(error));
  return (data ?? []) as TestPayment[];
}

export interface SubmitPaymentInput {
  userId: string;
  pkg: Package;
  method: PaymentMethod;
  reference: string;
}

/**
 * Enregistre la déclaration de paiement. Le statut `pending` est imposé par la
 * policy RLS : un utilisateur ne peut pas s'auto-valider.
 */
export async function submitPayment({
  userId,
  pkg,
  method,
  reference,
}: SubmitPaymentInput): Promise<TestPayment> {
  const cleanReference = reference.trim();

  if (cleanReference.length < 4) {
    throw new Error('Référence de transaction invalide (au moins 4 caractères).');
  }

  // Évite les doublons de référence déjà soumis par cet utilisateur
  const { data: existing } = await supabase
    .from(TABLES.testPayments)
    .select('id')
    .eq('user_id', userId)
    .eq('reference', cleanReference)
    .maybeSingle();

  if (existing) {
    throw new Error('Cette référence a déjà été enregistrée. Contactez le support si besoin.');
  }

  const { data, error } = await supabase
    .from(TABLES.testPayments)
    .insert({
      user_id: userId,
      package_id: pkg.id,
      amount: pkg.price,
      method,
      reference: cleanReference,
      status: 'pending',
    })
    .select('*, package:packages(*)')
    .single();

  if (error) throw new Error(getErrorMessage(error));
  return data as TestPayment;
}

/** Numéros de collecte affichés dans la modale (variables d'environnement) */
export const PAYMENT_NUMBERS: Record<PaymentMethod, string> = {
  tmoney: env.payment.tmoney,
  flooz: env.payment.flooz,
};

export const PAYMENT_LABELS: Record<PaymentMethod, string> = {
  tmoney: 'T-Money',
  flooz: 'Flooz',
};

/** Statuts de forfait : libellés + tons */
export const PAYMENT_STATUS_META = {
  pending: { label: 'En attente', tone: 'accent' as const },
  approved: { label: 'Validé', tone: 'success' as const },
  rejected: { label: 'Rejeté', tone: 'danger' as const },
};

export const MEMBERSHIP_STATUS_LABELS = {
  pending: 'En attente',
  active: 'Actif',
  expired: 'Expiré',
  rejected: 'Rejeté',
} as const;
