/**
 * ============================================================================
 *  N-OVARI — Client Supabase (configuration centrale)
 * ============================================================================
 *  • Client unique, réutilisé partout (singleton).
 *  • La session est persistée dans localStorage et rafraîchie automatiquement.
 *  • Aucune clé service_role ne doit jamais transiter par le frontend :
 *    toutes les opérations sensibles (validation de paiement, crédit de prime
 *    de parrainage) sont protégées par RLS + policies "admin".
 * ============================================================================
 */
import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { env, isSupabaseConfigured } from './env';

/**
 * Client non générique : les lignes renvoyées par PostgREST sont typées
 * explicitement dans chaque module de `src/lib` (casts contrôlés vers les types
 * de `src/types/database.ts`). Le schéma SQL étant géré hors du projet TS, ce
 * parti pris évite les signatures `never` de la génération de types et garde
 * une seule source de vérité : `types/database.ts`.
 */
export type TypedSupabaseClient = SupabaseClient;

function createSupabaseClient(): TypedSupabaseClient {
  if (!isSupabaseConfigured) {
    // Valeurs neutres : aucun appel réseau ne doit aboutir, mais l'app peut
    // s'afficher et présenter l'écran "Configuration requise".
    return createClient('https://placeholder.supabase.co', 'placeholder-anon-key', {
      auth: { persistSession: false, autoRefreshToken: false },
    });
  }

  return createClient(env.supabaseUrl, env.supabaseAnonKey, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
      storageKey: 'n-ovari-auth',
      flowType: 'pkce',
    },
    global: {
      headers: {
        'x-client-info': 'n-ovari-web/0.1.0',
      },
    },
    db: { schema: 'public' },
  });
}

export const supabase = createSupabaseClient();

/* -------------------------------------------------------------------------- */
/*                        Constantes & helpers de requête                     */
/* -------------------------------------------------------------------------- */

/** Noms de tables centralisés (évite les fautes de frappe dans les requêtes) */
export const TABLES = {
  profiles: 'profiles',
  packages: 'packages',
  memberPackages: 'member_packages',
  testPayments: 'test_payments',
  campaigns: 'campaigns',
  adTasks: 'ad_tasks',
  walletTransactions: 'wallet_transactions',
  withdrawalRequests: 'withdrawal_requests',
  referrals: 'referrals',
  rewardRules: 'reward_rules',
  auditLogs: 'audit_logs',
  notifications: 'notifications',
} as const;

/** Bucket Storage pour les visuels publicitaires */
export const STORAGE_BUCKETS = {
  adCreatives: 'ad-creatives',
  avatars: 'avatars',
} as const;

/**
 * Normalise une erreur Supabase en message lisible en français.
 * Utilisé par tous les formulaires pour un retour UX homogène.
 */
export function getErrorMessage(error: unknown): string {
  const fallback = 'Une erreur est survenue. Veuillez réessayer.';
  if (!error) return fallback;

  const message =
    typeof error === 'string'
      ? error
      : typeof error === 'object' && error !== null && 'message' in error
        ? String((error as { message: unknown }).message)
        : fallback;

  const dictionary: Array<[RegExp, string]> = [
    [/invalid login credentials/i, 'Identifiants incorrects. Vérifiez votre e-mail et mot de passe.'],
    [/email not confirmed/i, 'Votre adresse e-mail n’est pas encore confirmée.'],
    [/user already registered/i, 'Un compte existe déjà avec cette adresse e-mail.'],
    [/password should be at least/i, 'Le mot de passe doit contenir au moins 6 caractères.'],
    [/duplicate key value.*referral_code/i, 'Ce code parrain est déjà utilisé.'],
    [/duplicate key value.*phone/i, 'Ce numéro de téléphone est déjà enregistré.'],
    [/row-level security/i, 'Action non autorisée pour votre compte.'],
    [/failed to fetch|networkerror/i, 'Connexion au serveur impossible. Vérifiez votre réseau.'],
  ];

  for (const [pattern, translation] of dictionary) {
    if (pattern.test(message)) return translation;
  }

  return message || fallback;
}
