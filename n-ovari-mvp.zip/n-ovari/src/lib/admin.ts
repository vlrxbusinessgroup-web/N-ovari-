/**
 * N-OVARI — Administration
 * ----------------------------------------------------------------------------
 * Toutes les opérations de cette page sont doublées côté base par les policies
 * RLS "is_admin()" : forcer l'URL /admin avec un compte standard ne renvoie
 * aucune ligne et n'autorise aucune écriture.
 */
import { supabase, TABLES, getErrorMessage } from './supabase';
import type { Campaign, TestPayment, WithdrawalRequest } from '@/types/database';

/* ------------------------------ PAIEMENTS ------------------------------- */

export async function fetchPaymentQueue(): Promise<TestPayment[]> {
  const { data, error } = await supabase
    .from(TABLES.testPayments)
    .select('*, package:packages(*), profile:profiles(id, full_name, phone, referral_code)')
    .order('created_at', { ascending: false })
    .limit(100);

  if (error) throw new Error(getErrorMessage(error));
  return (data ?? []) as TestPayment[];
}

/** Valide un paiement : active le forfait, crédite le bonus ET la prime parrain */
export async function approvePayment(paymentId: string): Promise<void> {
  const { error } = await supabase.rpc('approve_payment', { p_payment_id: paymentId });
  if (error) throw new Error(getErrorMessage(error));
}

/** Rejette un paiement avec motif obligatoire */
export async function rejectPayment(paymentId: string, note: string): Promise<void> {
  const { error } = await supabase.rpc('reject_payment', {
    p_payment_id: paymentId,
    p_note: note.trim(),
  });
  if (error) throw new Error(getErrorMessage(error));
}

/* ------------------------------ CAMPAGNES ------------------------------- */

export async function fetchCampaigns(): Promise<Campaign[]> {
  const { data, error } = await supabase
    .from(TABLES.campaigns)
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw new Error(getErrorMessage(error));
  return (data ?? []) as Campaign[];
}

export async function createCampaign(input: {
  advertiser: string;
  title: string;
  description: string;
  budget: number;
}): Promise<void> {
  const { error } = await supabase.from(TABLES.campaigns).insert({
    advertiser: input.advertiser.trim(),
    title: input.title.trim(),
    description: input.description.trim() || null,
    budget: input.budget,
    status: 'draft',
  });
  if (error) throw new Error(getErrorMessage(error));
}

export async function updateCampaignStatus(
  campaignId: string,
  status: Campaign['status'],
): Promise<void> {
  const { error } = await supabase
    .from(TABLES.campaigns)
    .update({ status })
    .eq('id', campaignId);
  if (error) throw new Error(getErrorMessage(error));
}

/* ------------------------------- RETRAITS ------------------------------- */

export async function fetchWithdrawalQueue(): Promise<WithdrawalRequest[]> {
  const { data, error } = await supabase
    .from(TABLES.withdrawalRequests)
    .select('*')
    .order('created_at', { ascending: false })
    .limit(100);
  if (error) throw new Error(getErrorMessage(error));
  return (data ?? []) as WithdrawalRequest[];
}

export async function processWithdrawal(
  requestId: string,
  action: 'paid' | 'rejected',
  note?: string,
): Promise<void> {
  const { error } = await supabase.rpc('process_withdrawal', {
    p_request_id: requestId,
    p_action: action,
    p_note: note?.trim() ?? '',
  });
  if (error) throw new Error(getErrorMessage(error));
}

/* ------------------------------- STATISTIQUES --------------------------- */

export interface AdminStats {
  pendingPayments: number;
  approvedPayments: number;
  totalCollected: number;
  pendingWithdrawals: number;
  members: number;
}

export async function fetchAdminStats(payments: TestPayment[]): Promise<AdminStats> {
  const pendingPayments = payments.filter((p) => p.status === 'pending').length;
  const approved = payments.filter((p) => p.status === 'approved');
  const totalCollected = approved.reduce((sum, p) => sum + Number(p.amount ?? 0), 0);

  const [{ count: members }, { data: withdrawals }] = await Promise.all([
    supabase.from(TABLES.profiles).select('id', { count: 'exact', head: true }),
    supabase.from(TABLES.withdrawalRequests).select('status').eq('status', 'pending'),
  ]);

  return {
    pendingPayments,
    approvedPayments: approved.length,
    totalCollected,
    pendingWithdrawals: withdrawals?.length ?? 0,
    members: members ?? 0,
  };
}
