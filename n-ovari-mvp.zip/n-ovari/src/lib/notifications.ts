/**
 * N-OVARI — Notifications
 * ----------------------------------------------------------------------------
 * Les notifications sont créées exclusivement côté serveur (fonctions SQL :
 * validation de paiement, prime de parrainage, retrait payé/rejeté…).
 * Le client ne peut que les LIRE et les marquer comme lues (RLS).
 */
import { supabase, TABLES, getErrorMessage } from './supabase';
import type { Notification } from '@/types/database';

export type AppNotification = Notification;

/** true si la cloche affiche une pastille pour cette notification */
export function isUnread(notification: AppNotification): boolean {
  return notification.is_read === false;
}

export async function fetchMyNotifications(
  userId: string,
  limit = 30,
): Promise<AppNotification[]> {
  const { data, error } = await supabase
    .from(TABLES.notifications)
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) throw new Error(getErrorMessage(error));
  return (data ?? []) as AppNotification[];
}

export async function countUnread(userId: string): Promise<number> {
  const { count, error } = await supabase
    .from(TABLES.notifications)
    .select('id', { count: 'exact', head: true })
    .eq('user_id', userId)
    .eq('is_read', false);

  if (error) return 0;
  return count ?? 0;
}

export async function markAllAsRead(userId: string): Promise<void> {
  const { error } = await supabase
    .from(TABLES.notifications)
    .update({ is_read: true })
    .eq('user_id', userId)
    .eq('is_read', false);

  if (error) throw new Error(getErrorMessage(error));
}

export async function markAsRead(notificationId: string): Promise<void> {
  const { error } = await supabase
    .from(TABLES.notifications)
    .update({ is_read: true })
    .eq('id', notificationId);

  if (error) throw new Error(getErrorMessage(error));
}

/** Icône + ton associés au type de notification */
export const NOTIFICATION_META = {
  info: { tone: 'brand' as const },
  success: { tone: 'success' as const },
  warning: { tone: 'accent' as const },
  payment: { tone: 'brand' as const },
  reward: { tone: 'success' as const },
};
