/**
 * ============================================================================
 *  N-OVARI — Règles de calcul du portefeuille
 * ============================================================================
 *  Le solde n'est JAMAIS stocké "en dur" côté client : il est toujours recalculé
 *  à partir des lignes de `wallet_transactions` renvoyées par Supabase.
 *
 *  Conventions appliquées :
 *   • Un montant positif avec un type de DÉBIT est interprété comme un débit.
 *   • Un montant négatif est toujours un débit (grand livre déjà signé).
 *   • Les lignes `pending` et `rejected` ne sont pas comptabilisées.
 * ============================================================================
 */
import { supabase, TABLES, getErrorMessage } from './supabase';
import type { WalletTransaction, WalletTransactionType } from '@/types/database';

/** Types de transactions qui diminuent le solde */
const DEBIT_TYPES: ReadonlySet<WalletTransactionType> = new Set<WalletTransactionType>([
  'withdrawal',
  'adjustment',
]);

/** Statuts non comptabilisés dans le solde disponible */
const NON_SETTLED_STATUSES = new Set(['pending', 'rejected']);

/** Montant signé d'une transaction (+ crédit / − débit) */
export function signedAmount(tx: Pick<WalletTransaction, 'amount' | 'type'>): number {
  const amount = Number(tx.amount ?? 0);
  if (amount < 0) return amount;
  return DEBIT_TYPES.has(tx.type) ? -amount : amount;
}

/** true si la ligne impacte réellement le solde */
export function isSettled(tx: Pick<WalletTransaction, 'status'>): boolean {
  return !NON_SETTLED_STATUSES.has(tx.status);
}

/** Somme d'un ensemble de transactions → solde disponible */
export function computeBalance(transactions: Array<Pick<WalletTransaction, 'amount' | 'type' | 'status'>>): number {
  return transactions.reduce(
    (total, tx) => (isSettled(tx) ? total + signedAmount(tx) : total),
    0,
  );
}

export interface WalletSnapshot {
  balance: number;
  totalEarned: number;
  totalWithdrawn: number;
}

/**
 * Récupère le solde réel de l'utilisateur depuis Supabase.
 * À l'échelle du MVP, l'agrégation est faite côté client sur les colonnes
 * strictement nécessaires (RLS : l'utilisateur ne lit que ses propres lignes).
 */
export async function fetchWalletSnapshot(userId: string): Promise<WalletSnapshot> {
  const { data, error } = await supabase
    .from(TABLES.walletTransactions)
    .select('amount, type, status')
    .eq('user_id', userId);

  if (error) throw new Error(getErrorMessage(error));

  const transactions = (data ?? []) as Array<Pick<WalletTransaction, 'amount' | 'type' | 'status'>>;

  let balance = 0;
  let totalEarned = 0;
  let totalWithdrawn = 0;

  for (const tx of transactions) {
    if (!isSettled(tx)) continue;
    const signed = signedAmount(tx);
    balance += signed;
    if (signed > 0) totalEarned += signed;
    else totalWithdrawn += Math.abs(signed);
  }

  return { balance, totalEarned, totalWithdrawn };
}

/** Historique complet (du plus récent au plus ancien) */
export async function fetchWalletHistory(
  userId: string,
  limit = 50,
): Promise<WalletTransaction[]> {
  const { data, error } = await supabase
    .from(TABLES.walletTransactions)
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) throw new Error(getErrorMessage(error));
  return (data ?? []) as WalletTransaction[];
}

/** Libellés + tons d'affichage par type de transaction */
export const TRANSACTION_LABELS: Record<WalletTransactionType, { label: string; tone: 'credit' | 'debit' }> = {
  task_reward: { label: 'Gain publicité', tone: 'credit' },
  game_reward: { label: 'Gain jeu', tone: 'credit' },
  referral_bonus: { label: 'Prime parrainage', tone: 'credit' },
  package_bonus: { label: 'Bonus forfait', tone: 'credit' },
  admin_credit: { label: 'Crédit administrateur', tone: 'credit' },
  withdrawal: { label: 'Retrait', tone: 'debit' },
  withdrawal_reversal: { label: 'Retrait annulé (recrédit)', tone: 'credit' },
  adjustment: { label: 'Ajustement', tone: 'debit' },
};
