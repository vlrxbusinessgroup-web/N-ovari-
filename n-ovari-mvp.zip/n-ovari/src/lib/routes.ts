/**
 * N-OVARI — Table de routage centralisée.
 * Les URL sont en français (marché cible) ; les constantes évitent les
 * chaînes magiques dans les composants.
 */
export const ROUTES = {
  auth: '/auth',
  dashboard: '/',
  packages: '/forfaits',
  tasks: '/taches',
  games: '/jeux',
  career: '/carriere',
  referral: '/parrainage',
  wallet: '/portefeuille',
  settings: '/parametres',
  admin: '/admin',
  restricted: '/acces-restreint',
} as const;

export type RouteKey = keyof typeof ROUTES;

/** Lien de parrainage partageable */
export function buildReferralLink(referralCode: string): string {
  const origin = typeof window !== 'undefined' ? window.location.origin : 'https://n-ovari.app';
  return `${origin}${ROUTES.auth}?ref=${encodeURIComponent(referralCode)}`;
}
