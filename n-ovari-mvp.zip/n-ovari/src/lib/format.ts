/**
 * Utilitaires de formatage — marché FCFA (XOF).
 * Tous les montants affichés proviennent de Supabase, jamais de valeurs en dur.
 */

const fcfaFormatter = new Intl.NumberFormat('fr-FR', {
  maximumFractionDigits: 0,
  minimumFractionDigits: 0,
});

/** 12500 → "12 500 F" */
export function formatFCFA(amount: number | null | undefined): string {
  if (amount === null || amount === undefined || Number.isNaN(amount)) return '0 F';
  return `${fcfaFormatter.format(Math.round(amount))} F`;
}

/** 12500 → "12 500 FCFA" (usage administratif / récapitulatifs) */
export function formatFCFALong(amount: number | null | undefined): string {
  if (amount === null || amount === undefined) return '0 FCFA';
  return `${fcfaFormatter.format(Math.round(amount))} FCFA`;
}

/** 12500 → "12 500" (sans devise, pour les inputs) */
export function formatNumber(amount: number | null | undefined): string {
  if (amount === null || amount === undefined) return '0';
  return fcfaFormatter.format(Math.round(amount));
}

/** Date courte : "24 oct. 2026" */
export function formatDate(value: string | null | undefined): string {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' });
}

/** Date + heure : "24 oct. 2026 · 14:32" */
export function formatDateTime(value: string | null | undefined): string {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return `${formatDate(value)} · ${date.toLocaleTimeString('fr-FR', {
    hour: '2-digit',
    minute: '2-digit',
  })}`;
}

/** Initiales pour l'avatar : "Kossi Adjovi" → "KA" */
export function getInitials(name: string | null | undefined): string {
  if (!name) return 'NV';
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part.charAt(0).toUpperCase())
    .join('');
}

/** Téléphone masqué : "+22890000000" → "+228 90 •• •• 00" */
export function maskPhone(phone: string | null | undefined): string {
  if (!phone) return '—';
  if (phone.length < 4) return phone;
  return `${phone.slice(0, 5)} •••• ${phone.slice(-2)}`;
}

/** Libellé lisible d'un niveau de forfait : 17 → "LV17" */
export function packageLabel(level: number): string {
  return `LV${level}`;
}
