/**
 * Concatène des classes conditionnelles (alternative légère à clsx).
 * cn('p-4', isActive && 'bg-brand') → "p-4 bg-brand"
 */
export function cn(...classes: Array<string | false | null | undefined>): string {
  return classes.filter(Boolean).join(' ');
}
