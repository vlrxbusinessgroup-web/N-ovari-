/**
 * N-OVARI — Retraits
 * ----------------------------------------------------------------------------
 * Une demande de retrait est vérifiée côté serveur (`request_withdrawal`) :
 * solde suffisant, montant minimum lu dans `reward_rules`, et prise en compte
 * des demandes déjà en cours pour éviter le double engagement.
 */
import { supabase, TABLES, getErrorMessage } from './supabase';
import type { PaymentMethod, WithdrawalRequest } from '@/types/database';

export const WITHDRAWAL_STATUS_META = {
  pending: { label: 'En attente', tone: 'accent' as const },
  processing: { label: 'En traitement', tone: 'brand' as const },
  paid: { label: 'Payé', tone: 'success' as const },
  rejected: { label: 'Rejeté', tone: 'danger' as const },
};

export async function fetchMyWithdrawals(userId: string): Promise<WithdrawalRequest[]> {
  const { data, error } = await supabase
    .from(TABLES.withdrawalRequests)
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(20);

  if (error) throw new Error(getErrorMessage(error));
  return (data ?? []) as WithdrawalRequest[];
}

/** Montant minimum de retrait (paramétrable dans reward_rules) */
export async function fetchWithdrawalMinAmount(): Promise<number> {
  const { data, error } = await supabase
    .from(TABLES.rewardRules)
    .select('value')
    .eq('key', 'withdrawal_min_amount')
    .maybeSingle();
  if (error || !data) return 2000;
  const parsed = Number((data as { value: string }).value);
  return Number.isFinite(parsed) ? parsed : 2000;
}

export async function requestWithdrawal(
  amount: number,
  method: PaymentMethod,
  destination: string,
): Promise<void> {
  const cleanDestination = destination.trim();
  if (cleanDestination.length < 8) {
    throw new Error('Numéro bénéficiaire invalide.');
  }
  if (!Number.isFinite(amount) || amount <= 0) {
    throw new Error('Montant invalide.');
  }

  const { error } = await supabase.rpc('request_withdrawal', {
    p_amount: Math.round(amount),
    p_method: method,
    p_destination: cleanDestination,
  });

  if (error) throw new Error(getErrorMessage(error));
}
