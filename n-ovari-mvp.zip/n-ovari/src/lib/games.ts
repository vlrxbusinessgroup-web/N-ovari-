/**
 * N-OVARI — Jeux (logique officielle sur 20 niveaux)
 * ----------------------------------------------------------------------------
 * Le tirage pondéré et le règlement sont faits EN BASE (`play_game`).
 * La fonction renvoie le résultat immédiatement — l'animation de la roue, du
 * grattage ou des rouleaux ne fait ensuite que révéler ce résultat.
 *
 * Progression des accès sur 20 niveaux :
 *   • LV1 à LV2        : Aucun jeu accessible (« Débloqué au niveau 3 »)
 *   • LV3 à LV6        : Roue 1×/semaine (Lundi uniquement) · Grattage & Slots verrouillés
 *   • LV7 à LV11       : Roue 2×/semaine (Lundi, Mercredi) · Grattage 1×/semaine (au choix) · Slots verrouillé
 *   • LV12 à LV16      : Roue 3×/semaine (Lundi, Mercredi, Vendredi) · Grattage 2×/semaine (au choix) · Slots 1×/semaine (au choix)
 *   • LV17 à LV20 (VIP): Roue, Grattage, Slots 1×/jour chacun (accès quotidien + badge VIP doré)
 */
import { supabase, TABLES, getErrorMessage } from './supabase';

export type GameKey = 'wheel' | 'scratch' | 'slots';
export type PrizeKind = 'cash' | 'extra_spin' | 'gift';

export interface GamePrize {
  position: number;
  label: string;
  kind: PrizeKind;
  amount: number;
  weight: number;
  symbol: string | null;
}

export interface GameInfo {
  game_key: GameKey;
  open_today: boolean;
  level_ok: boolean;
  level_min: number;
  level_max?: number;
  weekdays: number[];
  plays_per_day: number;
  plays_per_week?: number;
  plays_done: number;
  plays_done_week?: number;
  next_in_days: number | null;
}

export interface GameConfig {
  has_access: boolean;
  /** Niveau de forfait à partir duquel les jeux s'ouvrent (LV3) */
  unlock_level: number;
  level: number;
  package_name?: string;
  weekday_today: number;
  /** Plafond mensuel des gains de jeu (FCFA) — 0 = pas de plafond */
  budget_month: number;
  budget_used: number;
  budget_rate: number;
  games: GameInfo[];
}

export interface PlayResult {
  game_key: GameKey;
  result_index: number;
  kind: PrizeKind;
  amount: number;
  label: string;
  symbol: string | null;
  extra_spin: boolean;
  gift_id: string | null;
  /** Grille de 9 symboles (grattage) */
  board: string[] | null;
  /** 3 symboles (machine à sous) */
  reels: string[] | null;
  plays_done_today: number;
  plays_limit: number;
  plays_done_week?: number;
  plays_limit_week?: number;
  budget_month?: number;
  budget_used?: number;
}

/* --------------------------------- Lecture -------------------------------- */

export async function fetchGameConfig(): Promise<GameConfig> {
  const { data, error } = await supabase.rpc('game_config');
  if (error) throw new Error(getErrorMessage(error));
  return data as GameConfig;
}

/** Lots d'un jeu, pour dessiner la roue ou afficher les gains possibles */
export async function fetchGamePrizes(game: GameKey): Promise<GamePrize[]> {
  const { data, error } = await supabase
    .from('game_prizes')
    .select('position, label, kind, amount, weight, symbol')
    .eq('game_key', game)
    .eq('is_active', true)
    .order('position', { ascending: true });

  if (error) throw new Error(getErrorMessage(error));
  return (data ?? []) as GamePrize[];
}

/* ---------------------------------- Jouer --------------------------------- */

export async function playGame(game: GameKey): Promise<PlayResult> {
  const { data, error } = await supabase.rpc('play_game', { p_game_key: game });
  if (error) throw new Error(getErrorMessage(error));
  return data as PlayResult;
}

/* --------------------------------- Cadeaux -------------------------------- */

export type GiftStatus = 'pending' | 'preparing' | 'delivered' | 'cancelled';

export interface GameGift {
  id: string;
  user_id: string;
  prize_label: string;
  game_key: GameKey;
  status: GiftStatus;
  admin_note: string | null;
  processed_at: string | null;
  created_at: string;
  profile?: { id: string; full_name: string | null; phone: string | null };
}

export const GIFT_STATUS_META: Record<
  GiftStatus,
  { label: string; tone: 'accent' | 'brand' | 'success' | 'danger' }
> = {
  pending: { label: 'À traiter', tone: 'accent' },
  preparing: { label: 'En préparation', tone: 'brand' },
  delivered: { label: 'Livré', tone: 'success' },
  cancelled: { label: 'Annulé', tone: 'danger' },
};

export async function fetchMyGifts(userId: string): Promise<GameGift[]> {
  const { data, error } = await supabase
    .from('game_gifts')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  if (error) throw new Error(getErrorMessage(error));
  return (data ?? []) as GameGift[];
}

export async function fetchGiftQueue(): Promise<GameGift[]> {
  const { data, error } = await supabase
    .from('game_gifts')
    .select('*, profile:profiles(id, full_name, phone)')
    .order('created_at', { ascending: false })
    .limit(100);
  if (error) throw new Error(getErrorMessage(error));
  return (data ?? []) as GameGift[];
}

export async function updateGiftStatus(
  giftId: string,
  status: GiftStatus,
  note?: string,
): Promise<void> {
  const { error } = await supabase
    .from('game_gifts')
    .update({
      status,
      admin_note: note?.trim() || null,
      processed_at: new Date().toISOString(),
    })
    .eq('id', giftId);
  if (error) throw new Error(getErrorMessage(error));
}

/* --------------------------------- Affichage ------------------------------- */

export const GAME_META: Record<
  GameKey,
  { name: string; short: string; description: string; minLevel: number }
> = {
  wheel: {
    name: 'Roue de la fortune',
    short: 'Roue',
    description: '11 lots, du lot fréquent au jackpot',
    minLevel: 3,
  },
  scratch: {
    name: 'Grattage',
    short: 'Grattage',
    description: '3 symboles identiques sur 9 cases',
    minLevel: 7,
  },
  slots: {
    name: 'Machine à sous',
    short: 'Slots',
    description: '3 rouleaux — cerise, cloche, diamant',
    minLevel: 12,
  },
};

export const WEEKDAY_NAMES = [
  'lundi',
  'mardi',
  'mercredi',
  'jeudi',
  'vendredi',
  'samedi',
  'dimanche',
] as const;

export const WEEKDAY_LABELS_CAP = [
  'Lundi',
  'Mardi',
  'Mercredi',
  'Jeudi',
  'Vendredi',
  'Samedi',
  'Dimanche',
] as const;

/** 1 (lundi) → "lundi" */
export function weekdayName(day: number): string {
  return WEEKDAY_NAMES[Math.min(Math.max(day - 1, 0), 6)];
}

/** 1 (lundi) → "Lundi" */
export function weekdayCapitalized(day: number): string {
  return WEEKDAY_LABELS_CAP[Math.min(Math.max(day - 1, 0), 6)];
}

/** Jours d'ouverture lisibles : [1,3] → "Lundi, Mercredi" */
export function weekdaysLabel(weekdays: number[]): string {
  if (weekdays.length === 7) return 'Au choix (tous les jours)';
  return weekdays.map(weekdayCapitalized).join(', ');
}

/** Règle canonique sur 20 niveaux (miroir de `game_schedule` en base) */
export function getScheduleRuleForLevel(
  gameKey: GameKey,
  level: number,
): {
  level_ok: boolean;
  level_min: number;
  level_max: number;
  weekdays: number[];
  plays_per_day: number;
  plays_per_week: number;
} {
  if (level >= 17) {
    return {
      level_ok: true,
      level_min: 17,
      level_max: 20,
      weekdays: [1, 2, 3, 4, 5, 6, 7],
      plays_per_day: 1,
      plays_per_week: 7,
    };
  }
  if (gameKey === 'wheel') {
    if (level >= 12) {
      return {
        level_ok: true,
        level_min: 12,
        level_max: 16,
        weekdays: [1, 3, 5],
        plays_per_day: 1,
        plays_per_week: 3,
      };
    }
    if (level >= 7) {
      return {
        level_ok: true,
        level_min: 7,
        level_max: 11,
        weekdays: [1, 3],
        plays_per_day: 1,
        plays_per_week: 2,
      };
    }
    if (level >= 3) {
      return {
        level_ok: true,
        level_min: 3,
        level_max: 6,
        weekdays: [1],
        plays_per_day: 1,
        plays_per_week: 1,
      };
    }
    return {
      level_ok: false,
      level_min: 3,
      level_max: 6,
      weekdays: [1],
      plays_per_day: 1,
      plays_per_week: 1,
    };
  }
  if (gameKey === 'scratch') {
    if (level >= 12) {
      return {
        level_ok: true,
        level_min: 12,
        level_max: 16,
        weekdays: [1, 2, 3, 4, 5, 6, 7],
        plays_per_day: 1,
        plays_per_week: 2,
      };
    }
    if (level >= 7) {
      return {
        level_ok: true,
        level_min: 7,
        level_max: 11,
        weekdays: [1, 2, 3, 4, 5, 6, 7],
        plays_per_day: 1,
        plays_per_week: 1,
      };
    }
    return {
      level_ok: false,
      level_min: 7,
      level_max: 11,
      weekdays: [1, 2, 3, 4, 5, 6, 7],
      plays_per_day: 1,
      plays_per_week: 1,
    };
  }
  // slots
  if (level >= 12) {
    return {
      level_ok: true,
      level_min: 12,
      level_max: 16,
      weekdays: [1, 2, 3, 4, 5, 6, 7],
      plays_per_day: 1,
      plays_per_week: 1,
    };
  }
  return {
    level_ok: false,
    level_min: 12,
    level_max: 16,
    weekdays: [1, 2, 3, 4, 5, 6, 7],
    plays_per_day: 1,
    plays_per_week: 1,
  };
}

/** Calcule le nombre de jours avant la prochaine ouverture d'un jeu */
export function computeNextInDays(
  weekdays: number[],
  weekdayToday: number,
  doneToday: boolean,
  doneWeek: boolean,
): number {
  if (doneWeek) {
    for (let d = 8 - weekdayToday; d <= 14; d++) {
      const wd = ((weekdayToday + d - 1) % 7) + 1;
      if (weekdays.includes(wd)) return d;
    }
    return 8 - weekdayToday;
  }
  const start = doneToday ? 1 : 0;
  for (let d = start; d <= 7; d++) {
    const wd = ((weekdayToday + d - 1) % 7) + 1;
    if (weekdays.includes(wd)) return d;
  }
  return 1;
}

/** Normalise l'état d'un jeu avec la règle officielle des 20 niveaux */
export function resolveGameInfo(
  key: GameKey,
  fromServer: GameInfo | undefined,
  level: number,
  weekdayToday: number,
): GameInfo {
  const rule = getScheduleRuleForLevel(key, level);
  const playsDone = fromServer?.plays_done ?? 0;
  const playsDoneWeek = fromServer?.plays_done_week ?? playsDone;
  const weekdays = rule.weekdays;
  const playsPerDay = rule.plays_per_day;
  const playsPerWeek = rule.plays_per_week;
  const levelMin = rule.level_min;
  const levelOk = rule.level_ok;
  const openDay = levelOk && weekdays.includes(weekdayToday);
  const openToday = openDay && playsDoneWeek < playsPerWeek;

  const nextInDays = levelOk
    ? computeNextInDays(
        weekdays,
        weekdayToday,
        playsDone >= playsPerDay,
        playsDoneWeek >= playsPerWeek,
      )
    : null;

  return {
    game_key: key,
    open_today: openToday,
    level_ok: levelOk,
    level_min: levelMin,
    level_max: rule.level_max,
    weekdays,
    plays_per_day: playsPerDay,
    plays_per_week: playsPerWeek,
    plays_done: playsDone,
    plays_done_week: playsDoneWeek,
    next_in_days: nextInDays,
  };
}

/**
 * Libellé de verrouillage ou de prochaine ouverture :
 *  - Niveau insuffisant : "Débloqué au niveau 3" (LV1-2) / "Niveau X requis"
 *  - Mauvais jour ou quota utilisé : "Revenez Lundi" (ou Mercredi, Vendredi…)
 */
export function nextOpeningLabel(
  game: GameInfo,
  weekdayToday: number,
  playerLevel?: number,
): string {
  if (!game.level_ok) {
    if (playerLevel !== undefined && playerLevel <= 2 && game.level_min <= 3) {
      return 'Débloqué au niveau 3';
    }
    return `Niveau ${game.level_min} requis`;
  }
  if (canPlay(game)) return 'Ouvert aujourd’hui';

  const days =
    game.next_in_days !== null && game.next_in_days > 0
      ? game.next_in_days
      : computeNextInDays(
          game.weekdays,
          weekdayToday,
          game.plays_done >= game.plays_per_day,
          (game.plays_done_week ?? 0) >= (game.plays_per_week ?? 7),
        );

  const nextDay = ((weekdayToday + days - 1) % 7) + 1;
  return `Revenez ${weekdayCapitalized(nextDay)}`;
}

/** Résumé du rythme hebdomadaire/quotidien pour une carte de jeu */
export function scheduleSummary(game: GameInfo, playerLevel: number): string {
  if (!game.level_ok) {
    return playerLevel <= 2 && game.level_min <= 3
      ? 'Débloqué au niveau 3 · Niveau 3 requis'
      : `Verrouillé · Niveau ${game.level_min} requis`;
  }
  if (playerLevel >= 17) {
    return '1 fois / jour · Accès quotidien illimité (VIP)';
  }
  const perWeek = game.plays_per_week ?? game.weekdays.length;
  if (game.weekdays.length === 7) {
    return `${perWeek} fois / semaine · Au choix du membre`;
  }
  return `${perWeek} fois / semaine · ${game.weekdays.map(weekdayCapitalized).join(', ')}`;
}

/** Un jeu est-il jouable maintenant ? */
export function canPlay(game: GameInfo | undefined): boolean {
  if (!game) return false;
  const weekLimit = game.plays_per_week ?? 7;
  const weekDone = game.plays_done_week ?? 0;
  return (
    game.level_ok &&
    game.open_today &&
    game.plays_done < game.plays_per_day &&
    weekDone < weekLimit
  );
}

/** Table utilisée pour les lots (constante partagée) */
export const GAME_PRIZES_TABLE = 'game_prizes' as const;

/** Réexport utilitaire (évite une importation supplémentaire dans les pages) */
export { TABLES };
