/**
 * ============================================================================
 *  N-OVARI — Types de la base de données Supabase
 * ============================================================================
 *  ⚠️  Ce fichier décrit le contrat entre React et PostgreSQL.
 *      Les noms de colonnes reflètent le schéma convenu du MVP. Si une colonne
 *      diffère dans votre projet Supabase, ne modifiez QUE ce fichier : tout le
 *      reste de l'application en dépend (aucun `any` ailleurs dans le code).
 *
 *  Rappel des tables existantes :
 *    profiles, packages, member_packages, test_payments, campaigns, ad_tasks,
 *    wallet_transactions, withdrawal_requests, referrals, reward_rules,
 *    audit_logs, notifications
 * ============================================================================
 */

export type UserRole = 'user' | 'admin';

/** Statuts génériques de validation (paiements, forfaits, parrainages) */
export type ValidationStatus = 'pending' | 'approved' | 'rejected';
export type MembershipStatus = 'pending' | 'active' | 'expired' | 'rejected';
export type ReferralStatus = 'pending' | 'validated' | 'rejected';
export type WithdrawalStatus =
  | 'pending'
  | 'processing'
  | 'paid'
  | 'rejected';

/** Nature d'une ligne du grand livre (wallet_transactions) */
export type WalletTransactionType =
  | 'task_reward' // gain suite à une publicité regardée
  | 'game_reward' // gain d'un mini-jeu (roue / quiz)
  | 'referral_bonus' // prime parrainage (après validation admin)
  | 'package_bonus' // bonus de bienvenue lié à un forfait
  | 'admin_credit' // crédit manuel par l'admin
  | 'withdrawal' // demande de retrait (débit)
  | 'withdrawal_reversal' // retrait rejeté → recrédit
  | 'adjustment'; // correction manuelle

export type WalletTransactionStatus = 'pending' | 'completed' | 'rejected';

export type PaymentMethod = 'tmoney' | 'flooz';

export type Json = string | number | boolean | null | { [k: string]: Json } | Json[];

/* -------------------------------------------------------------------------- */
/*                                  PROFILS                                   */
/* -------------------------------------------------------------------------- */

export interface Profile {
  id: string; // = auth.users.id
  full_name: string | null;
  phone: string | null;
  email: string | null;
  /** Code parrain unique, généré automatiquement à la création du profil */
  referral_code: string;
  /** Code du parrain (1 seul niveau direct) — null si inscription organique */
  referred_by: string | null;
  /** 'admin' débloque l'espace d'administration caché */
  role: UserRole;
  /** Forfait actif (dénormalisé pour lecture rapide) — source de vérité : member_packages */
  active_package_id: string | null;
  is_blocked: boolean;
  created_at: string;
  updated_at?: string;
}

/* -------------------------------------------------------------------------- */
/*                                  FORFAITS                                  */
/* -------------------------------------------------------------------------- */

export interface Package {
  id: string;
  /** 1 → 20 */
  level: number;
  name: string; // ex: "LV1"
  price: number; // FCFA
  tasks_per_day: number;
  daily_reward: number; // FCFA / jour
  bonus: number; // bonus d'activation FCFA
  /** LV17 → LV20 : badge doré VIP + bonus occasionnels */
  is_vip: boolean;
  is_active: boolean;
  created_at?: string;
}

export interface MemberPackage {
  id: string;
  user_id: string;
  package_id: string;
  status: MembershipStatus;
  /** Paiement à l'origine de l'activation */
  payment_id: string | null;
  activated_at: string | null;
  expires_at: string | null;
  created_at: string;
  /** Jointure en lecture (non stockée) */
  package?: Package;
}

/* -------------------------------------------------------------------------- */
/*                              PAIEMENTS MANUELS                             */
/* -------------------------------------------------------------------------- */

export interface TestPayment {
  id: string;
  user_id: string;
  package_id: string;
  amount: number; // montant attendu en FCFA
  method: PaymentMethod; // T-Money / Flooz
  /** Référence de transaction saisie par l'utilisateur */
  reference: string;
  status: ValidationStatus;
  reviewed_by: string | null;
  reviewed_at: string | null;
  admin_note: string | null;
  created_at: string;
  package?: Package;
  profile?: Pick<Profile, 'id' | 'full_name' | 'phone' | 'referral_code'>;
}

/* -------------------------------------------------------------------------- */
/*                             CAMPAGNES & TÂCHES                             */
/* -------------------------------------------------------------------------- */

export interface Campaign {
  id: string;
  advertiser: string;
  title: string;
  description: string | null;
  budget: number;
  status: 'draft' | 'active' | 'paused' | 'completed';
  starts_at: string | null;
  ends_at: string | null;
  created_by: string | null;
  created_at: string;
}

export interface AdTask {
  id: string;
  campaign_id: string;
  title: string;
  /** Visuel publicitaire affiché (Supabase Storage ou URL externe) */
  image_url: string;
  target_url: string | null;
  reward: number; // FCFA crédités à l'utilisateur
  /** Chronomètre bloquant le bouton "Suivant" (3 s par défaut) */
  duration_seconds: number;
  /** Niveau minimum de forfait requis */
  min_package_level: number;
  is_active: boolean;
  created_at: string;
  campaign?: Campaign;
}

/* -------------------------------------------------------------------------- */
/*                             PORTEFEUILLE                                    */
/* -------------------------------------------------------------------------- */

export interface WalletTransaction {
  id: string;
  user_id: string;
  amount: number; // toujours en valeur absolue (positif) ou négatif pour un débit
  type: WalletTransactionType;
  status: WalletTransactionStatus;
  description: string | null;
  /** Lien métier optionnel (ad_task, referral, withdrawal…) */
  reference_id: string | null;
  metadata?: Json;
  created_at: string;
}

export interface WithdrawalRequest {
  id: string;
  user_id: string;
  amount: number;
  method: PaymentMethod;
  destination: string; // numéro de téléphone bénéficiaire
  status: WithdrawalStatus;
  admin_note: string | null;
  processed_by: string | null;
  processed_at: string | null;
  created_at: string;
}

/* -------------------------------------------------------------------------- */
/*                                PARRAINAGE                                  */
/* -------------------------------------------------------------------------- */

export interface Referral {
  id: string;
  sponsor_id: string; // parrain
  referred_id: string; // filleul
  status: ReferralStatus;
  /** Prime créditée au parrain APRÈS validation admin du paiement du filleul */
  bonus_amount: number | null;
  validated_at: string | null;
  created_at: string;
  /** Jointure en lecture */
  referred?: Pick<Profile, 'id' | 'full_name' | 'created_at' | 'active_package_id'>;
}

/* -------------------------------------------------------------------------- */
/*                        RÈGLES, LOGS, NOTIFICATIONS                         */
/* -------------------------------------------------------------------------- */

export interface RewardRule {
  id: string;
  key: string; // ex: 'referral_bonus_rate', 'task_timer_seconds'
  label: string;
  value: string;
  description: string | null;
  updated_at?: string;
}

export interface AuditLog {
  id: string;
  actor_id: string | null;
  action: string;
  entity: string;
  entity_id: string | null;
  payload: Json | null;
  created_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  body: string | null;
  type: 'info' | 'success' | 'warning' | 'payment' | 'reward';
  is_read: boolean;
  created_at: string;
}

/* -------------------------------------------------------------------------- */
/*                    LIGNES RENVOYÉES PAR LES FONCTIONS SQL                  */
/* -------------------------------------------------------------------------- */

/** Résultat de `my_referrals()` — vue restreinte des filleuls du parrain */
export interface MyReferralRow {
  referred_id: string;
  full_name: string | null;
  status: ReferralStatus;
  joined_at: string;
  bonus_amount: number | null;
  package_level: number | null;
}

/** Résultat de `complete_ad_task()` */
export interface CompleteTaskRow {
  reward: number;
  tasks_done_today: number;
  tasks_limit: number;
}

/* -------------------------------------------------------------------------- */
/*                        HELPERS DE TYPE POUR SUPABASE                       */
/* -------------------------------------------------------------------------- */

export interface Database {
  public: {
    Tables: {
      profiles: { Row: Profile; Insert: Partial<Profile>; Update: Partial<Profile> };
      packages: { Row: Package; Insert: Partial<Package>; Update: Partial<Package> };
      member_packages: {
        Row: MemberPackage;
        Insert: Partial<MemberPackage>;
        Update: Partial<MemberPackage>;
      };
      test_payments: {
        Row: TestPayment;
        Insert: Partial<TestPayment>;
        Update: Partial<TestPayment>;
      };
      campaigns: { Row: Campaign; Insert: Partial<Campaign>; Update: Partial<Campaign> };
      ad_tasks: { Row: AdTask; Insert: Partial<AdTask>; Update: Partial<AdTask> };
      wallet_transactions: {
        Row: WalletTransaction;
        Insert: Partial<WalletTransaction>;
        Update: Partial<WalletTransaction>;
      };
      withdrawal_requests: {
        Row: WithdrawalRequest;
        Insert: Partial<WithdrawalRequest>;
        Update: Partial<WithdrawalRequest>;
      };
      referrals: { Row: Referral; Insert: Partial<Referral>; Update: Partial<Referral> };
      reward_rules: { Row: RewardRule; Insert: Partial<RewardRule>; Update: Partial<RewardRule> };
      audit_logs: { Row: AuditLog; Insert: Partial<AuditLog>; Update: Partial<AuditLog> };
      notifications: {
        Row: Notification;
        Insert: Partial<Notification>;
        Update: Partial<Notification>;
      };
    };
    Views: Record<string, never>;
    Functions: {
      is_admin: { Args: Record<string, never>; Returns: boolean };
      approve_payment: { Args: { p_payment_id: string }; Returns: null };
      reject_payment: { Args: { p_payment_id: string; p_note: string }; Returns: null };
      complete_ad_task: { Args: { p_task_id: string }; Returns: CompleteTaskRow };
      request_withdrawal: {
        Args: { p_amount: number; p_method: PaymentMethod; p_destination: string };
        Returns: null;
      };
      process_withdrawal: {
        Args: { p_request_id: string; p_action: string; p_note: string };
        Returns: null;
      };
      my_referrals: { Args: Record<string, never>; Returns: MyReferralRow[] };
    };
    Enums: Record<string, never>;
  };
}
