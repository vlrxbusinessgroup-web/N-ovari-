/**
 * ============================================================================
 *  N-OVARI — Contexte d'authentification & état du compte
 * ============================================================================
 *  Source unique de vérité côté client :
 *    • session Supabase (persistée / rafraîchie automatiquement)
 *    • profil (rôle, code parrain, forfait actif)
 *    • forfait actif (member_packages + packages)
 *    • solde réel recalculé depuis wallet_transactions
 *
 *  Règles métier portées ici :
 *    • LV0 = aucun forfait actif → `hasActivePackage === false`
 *    • `isAdmin` pilote l'accès à l'espace caché /admin
 * ============================================================================
 */
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase, TABLES, getErrorMessage } from '@/lib/supabase';
import { isSupabaseConfigured } from '@/lib/env';
import { fetchWalletSnapshot } from '@/lib/wallet';
import type { MemberPackage, Package, Profile } from '@/types/database';

/* -------------------------------------------------------------------------- */
/*                              Types du contexte                             */
/* -------------------------------------------------------------------------- */

export interface SignUpPayload {
  fullName: string;
  email: string;
  phone: string;
  password: string;
  /** Code parrain saisi par le filleul (facultatif) — 1 seul niveau direct */
  referralCode?: string;
}

interface AuthContextValue {
  session: Session | null;
  profile: Profile | null;
  /** Forfait actif (LV0 → null) */
  membership: MemberPackage | null;
  activePackage: Package | null;
  /** Solde disponible, calculé depuis wallet_transactions */
  balance: number;
  totalEarned: number;
  isAdmin: boolean;
  /** false ⇒ LV0 : tâches et jeux bloqués */
  hasActivePackage: boolean;
  isLoading: boolean;
  isConfigured: boolean;
  error: string | null;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (payload: SignUpPayload) => Promise<{ needsEmailConfirmation: boolean }>;
  signOut: () => Promise<void>;
  /** Recharge profil + forfait + solde depuis Supabase */
  refresh: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

/* -------------------------------------------------------------------------- */
/*                              Provider                                      */
/* -------------------------------------------------------------------------- */

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [membership, setMembership] = useState<MemberPackage | null>(null);
  const [activePackage, setActivePackage] = useState<Package | null>(null);
  const [balance, setBalance] = useState(0);
  const [totalEarned, setTotalEarned] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  /** Charge profil → forfait actif → solde, dans cet ordre. */
  const loadAccount = useCallback(async (userId: string) => {
    // 1. Profil (créé automatiquement par le trigger Supabase à l'inscription)
    const { data: profileRow, error: profileError } = await supabase
      .from(TABLES.profiles)
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (profileError) throw new Error(getErrorMessage(profileError));
    if (!profileRow) {
      throw new Error(
        'Profil introuvable. Le trigger de création de profil (handle_new_user) doit être installé dans Supabase.',
      );
    }

    if (!mounted.current) return;
    setProfile(profileRow as Profile);

    // 2. Forfait actif (LV0 si aucune ligne "active")
    const { data: memberRow, error: memberError } = await supabase
      .from(TABLES.memberPackages)
      .select('*')
      .eq('user_id', userId)
      .eq('status', 'active')
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (memberError) throw new Error(getErrorMessage(memberError));

    let packageRow: Package | null = null;
    const activeMembership = (memberRow as MemberPackage | null) ?? null;

    if (activeMembership?.package_id) {
      const { data: pkg, error: pkgError } = await supabase
        .from(TABLES.packages)
        .select('*')
        .eq('id', activeMembership.package_id)
        .maybeSingle();
      if (pkgError) throw new Error(getErrorMessage(pkgError));
      packageRow = (pkg as Package | null) ?? null;
    }

    // 3. Solde réel calculé depuis les transactions
    const snapshot = await fetchWalletSnapshot(userId);

    if (!mounted.current) return;
    setMembership(activeMembership);
    setActivePackage(packageRow);
    setBalance(snapshot.balance);
    setTotalEarned(snapshot.totalEarned);
  }, []);

  const refresh = useCallback(async () => {
    const userId = session?.user?.id;
    if (!userId) return;
    try {
      setError(null);
      await loadAccount(userId);
    } catch (err) {
      if (mounted.current) setError(err instanceof Error ? err.message : getErrorMessage(err));
    }
  }, [session?.user?.id, loadAccount]);

  /* ------------------------- Cycle de vie de la session ------------------- */

  useEffect(() => {
    if (!isSupabaseConfigured) {
      setIsLoading(false);
      return;
    }

    let active = true;

    supabase.auth
      .getSession()
      .then(({ data }) => {
        if (!active) return;
        setSession(data.session);
        if (!data.session) setIsLoading(false);
      })
      .catch(() => {
        if (active) setIsLoading(false);
      });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, nextSession) => {
      if (!active) return;
      setSession(nextSession);

      if (event === 'SIGNED_OUT' || !nextSession) {
        setProfile(null);
        setMembership(null);
        setActivePackage(null);
        setBalance(0);
        setTotalEarned(0);
        setIsLoading(false);
        return;
      }

      // On recharge le compte sur connexion / rafraîchissement de token
      if (event === 'SIGNED_IN' || event === 'INITIAL_SESSION' || event === 'TOKEN_REFRESHED') {
        loadAccount(nextSession.user.id)
          .catch((err) => {
            if (active) {
              setError(err instanceof Error ? err.message : getErrorMessage(err));
            }
          })
          .finally(() => {
            if (active) setIsLoading(false);
          });
      }
    });

    return () => {
      active = false;
      subscription.unsubscribe();
    };
  }, [loadAccount]);

  /* ------------------------------ Actions -------------------------------- */

  const signIn = useCallback(async (email: string, password: string) => {
    const { error: signInError } = await supabase.auth.signInWithPassword({
      email: email.trim().toLowerCase(),
      password,
    });
    if (signInError) throw new Error(getErrorMessage(signInError));
  }, []);

  const signUp = useCallback(async (payload: SignUpPayload) => {
    const referralCode = payload.referralCode?.trim().toUpperCase() || null;

    // Le trigger `handle_new_user` (côté Supabase) :
    //   • génère le code parrain du nouvel utilisateur
    //   • enregistre `referred_by` si un code parrain valide est fourni
    //   • crée la ligne `referrals` en statut "pending"
    const { data, error: signUpError } = await supabase.auth.signUp({
      email: payload.email.trim().toLowerCase(),
      password: payload.password,
      options: {
        data: {
          full_name: payload.fullName.trim(),
          phone: payload.phone.trim(),
          referral_code_used: referralCode,
        },
      },
    });

    if (signUpError) throw new Error(getErrorMessage(signUpError));

    return { needsEmailConfirmation: !data.session };
  }, []);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setProfile(null);
    setMembership(null);
    setActivePackage(null);
    setBalance(0);
    setTotalEarned(0);
  }, []);

  /* ------------------------------ Contexte ------------------------------- */

  const value = useMemo<AuthContextValue>(
    () => ({
      session,
      profile,
      membership,
      activePackage,
      balance,
      totalEarned,
      isAdmin: profile?.role === 'admin',
      hasActivePackage: Boolean(membership && activePackage),
      isLoading,
      isConfigured: isSupabaseConfigured,
      error,
      signIn,
      signUp,
      signOut,
      refresh,
    }),
    [
      session,
      profile,
      membership,
      activePackage,
      balance,
      totalEarned,
      isLoading,
      error,
      signIn,
      signUp,
      signOut,
      refresh,
    ],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

/* -------------------------------------------------------------------------- */
/*                                Hooks                                       */
/* -------------------------------------------------------------------------- */

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth doit être utilisé à l’intérieur de <AuthProvider>.');
  return ctx;
}

/** Hook dédié aux modules nécessitant un forfait actif (LV ≥ 1) */
export function usePackageAccess() {
  const { hasActivePackage, activePackage, membership } = useAuth();
  return {
    hasAccess: hasActivePackage,
    level: activePackage?.level ?? 0,
    packageName: activePackage?.name ?? 'LV0',
    tasksPerDay: activePackage?.tasks_per_day ?? 0,
    dailyReward: activePackage?.daily_reward ?? 0,
    isVip: activePackage?.is_vip ?? false,
    expiresAt: membership?.expires_at ?? null,
  };
}
