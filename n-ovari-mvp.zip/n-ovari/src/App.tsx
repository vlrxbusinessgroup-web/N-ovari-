/**
 * ============================================================================
 *  N-OVARI — Application (routage principal)
 * ============================================================================
 *  Architecture des routes
 *  -----------------------
 *  Public
 *    /auth                       Connexion / Inscription (+ ?ref=CODE)
 *
 *  Protégé (session Supabase requise → <ProtectedRoute/> + <AppShell/>)
 *    /                           Tableau de bord (solde réel, forfait, raccourcis)
 *    /forfaits                   Les 20 forfaits + paiement manuel
 *    /taches                     Tâches publicitaires   [garde LV0]
 *    /jeux                       Jeux                   [garde LV0]
 *    /portefeuille               Portefeuille + historique
 *    /parrainage                 Code parrain + filleuls
 *    /carriere                   Carrière / évolution
 *    /parametres                 Paramètres du compte
 *    /acces-restreint            Écran LV0 explicite
 *
 *  Protégé + rôle admin (espace caché → <RequireAdmin/>)
 *    /admin                      Validation des paiements, campagnes
 *
 *  Le garde LV0 n'est pas géré ici mais au niveau du module (PackageGate),
 *  afin que l'utilisateur voie l'écran "Accès restreint" dans l'app, avec sa
 *  barre de navigation, plutôt qu'une redirection muette.
 * ============================================================================
 */
import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import { ROUTES } from './lib/routes';

/* Layout & gardes */
import { ProtectedRoute, RequireAdmin } from './components/layout/RouteGuards';
import { PackageGate } from './components/layout/PackageGate';

/* Écrans système */
import { ConfigRequiredScreen, ErrorScreen, LoadingScreen } from './components/ui/States';

/* Pages */
import AuthPage from './pages/AuthPage';
import DashboardPage from './pages/DashboardPage';
import PackagesPage from './pages/PackagesPage';
import TasksPage from './pages/TasksPage';
import GamesPage from './pages/GamesPage';
import WalletPage from './pages/WalletPage';
import ReferralPage from './pages/ReferralPage';
import CareerPage from './pages/CareerPage';
import SettingsPage from './pages/SettingsPage';
import RestrictedAccessPage from './pages/RestrictedAccessPage';
import AdminPage from './pages/AdminPage';
import NotFoundPage from './pages/NotFoundPage';

export default function App() {
  const { isLoading, isConfigured, error, refresh, session } = useAuth();

  // 1. Supabase non configuré → écran de configuration (jamais de données fictives)
  if (!isConfigured) return <ConfigRequiredScreen />;

  // 2. Chargement initial de la session
  if (isLoading) return <LoadingScreen />;

  // 3. Erreur bloquante (profil manquant, RLS, réseau…)
  if (session && error) return <ErrorScreen message={error} onRetry={refresh} />;

  return (
    <Routes>
      {/* ------------------------------ Public ------------------------------ */}
      <Route path={ROUTES.auth} element={<AuthPage />} />

      {/* --------------------------- Protégé (app) -------------------------- */}
      <Route element={<ProtectedRoute />}>
        <Route path={ROUTES.dashboard} element={<DashboardPage />} />
        <Route path={ROUTES.packages} element={<PackagesPage />} />
        {/* Garde LV0 : sans forfait actif → écran "Accès restreint" */}
        <Route
          path={ROUTES.tasks}
          element={
            <PackageGate>
              <TasksPage />
            </PackageGate>
          }
        />
        <Route
          path={ROUTES.games}
          element={
            <PackageGate>
              <GamesPage />
            </PackageGate>
          }
        />
        <Route path={ROUTES.wallet} element={<WalletPage />} />
        <Route path={ROUTES.referral} element={<ReferralPage />} />
        <Route path={ROUTES.career} element={<CareerPage />} />
        <Route path={ROUTES.settings} element={<SettingsPage />} />
        <Route path={ROUTES.restricted} element={<RestrictedAccessPage />} />

        {/* ------------------- Protégé + rôle admin (caché) ---------------- */}
        <Route element={<RequireAdmin />}>
          <Route path={ROUTES.admin} element={<AdminPage />} />
        </Route>

        <Route path="*" element={<NotFoundPage />} />
      </Route>

      {/* Lien racine inconnu → redirection sûre */}
      <Route path="/index.html" element={<Navigate to={ROUTES.dashboard} replace />} />
    </Routes>
  );
}
