import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Gamepad2,
  ArrowDownLeft,
  ArrowUpRight,
  Banknote,
  Gift,
  Wallet as WalletIcon,
  PlayCircle,
  Users,
  RefreshCw,
  Clock,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { fetchWalletHistory, TRANSACTION_LABELS } from '@/lib/wallet';
import {
  fetchMyWithdrawals,
  fetchWithdrawalMinAmount,
  requestWithdrawal,
  WITHDRAWAL_STATUS_META,
} from '@/lib/withdrawals';
import { PAYMENT_LABELS } from '@/lib/payments';
import { formatFCFA, formatDateTime } from '@/lib/format';
import { cn } from '@/lib/cn';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { Alert, EmptyState, ListSkeleton } from '@/components/ui/Feedback';
import { PageHeader } from '@/components/ui/PageHeader';
import type { PaymentMethod, WalletTransaction, WithdrawalRequest } from '@/types/database';

type Filter = 'all' | 'credit' | 'debit';

const TYPE_ICONS: Record<string, typeof Gift> = {
  task_reward: PlayCircle,
  game_reward: Gamepad2,
  referral_bonus: Users,
  package_bonus: Gift,
  admin_credit: Banknote,
  withdrawal: ArrowUpRight,
  withdrawal_reversal: ArrowDownLeft,
  adjustment: RefreshCw,
};

/**
 * PORTEFEUILLE
 * -------------------------------------------------------------
 * • Solde = somme des wallet_transactions (via AuthContext).
 * • Historique lu directement dans Supabase, filtré côté affichage.
 * • Retrait : demande vérifiée côté serveur (solde + montant minimum).
 */
export default function WalletPage() {
  const { session, balance, totalEarned, refresh } = useAuth();
  const userId = session?.user.id ?? '';

  const [history, setHistory] = useState<WalletTransaction[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [minAmount, setMinAmount] = useState(2000);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<Filter>('all');

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<PaymentMethod>('tmoney');
  const [destination, setDestination] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [modalError, setModalError] = useState<string | null>(null);
  const [modalSuccess, setModalSuccess] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!userId) return;
    try {
      setIsLoading(true);
      setError(null);
      const [txs, wds, min] = await Promise.all([
        fetchWalletHistory(userId),
        fetchMyWithdrawals(userId),
        fetchWithdrawalMinAmount(),
      ]);
      setHistory(txs);
      setWithdrawals(wds);
      setMinAmount(min);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Impossible de charger le portefeuille.');
    } finally {
      setIsLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    void load();
  }, [load]);

  const filtered = useMemo(() => {
    if (filter === 'all') return history;
    return history.filter((tx) => {
      const isDebit = Number(tx.amount) < 0 || tx.type === 'withdrawal' || tx.type === 'adjustment';
      return filter === 'debit' ? isDebit : !isDebit;
    });
  }, [history, filter]);

  const spent = useMemo(
    () =>
      history.reduce((sum, tx) => {
        const isDebit = Number(tx.amount) < 0 || tx.type === 'withdrawal';
        return isDebit && tx.status === 'completed' ? sum + Math.abs(Number(tx.amount)) : sum;
      }, 0),
    [history],
  );

  const openWithdraw = () => {
    setIsModalOpen(true);
    setAmount('');
    setDestination('');
    setMethod('tmoney');
    setModalError(null);
    setModalSuccess(null);
  };

  const handleWithdraw = async () => {
    setSubmitting(true);
    setModalError(null);
    try {
      await requestWithdrawal(Number(amount), method, destination);
      setModalSuccess('Demande enregistrée. Le versement est traité par l’administration.');
      setAmount('');
      await Promise.all([load(), refresh()]);
    } catch (err) {
      setModalError(err instanceof Error ? err.message : 'Demande impossible.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="animate-fade-up">
      <PageHeader
        title="Portefeuille"
        subtitle="Vos gains et mouvements, en temps réel"
        action={
          <button
            type="button"
            onClick={() => void load()}
            aria-label="Rafraîchir"
            className="flex h-9 w-9 items-center justify-center rounded-full bg-white text-brand shadow-soft"
          >
            <RefreshCw className={cn('h-4 w-4', isLoading && 'animate-spin')} strokeWidth={2.4} />
          </button>
        }
      />

      {/* Solde */}
      <section className="px-5">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand via-brand to-brand-soft p-5 text-white shadow-float">
          <div className="absolute -right-8 -top-10 h-32 w-32 rounded-full bg-accent/20 blur-2xl" />
          <p className="text-[11px] font-semibold uppercase tracking-wider text-white/60">
            Solde disponible
          </p>
          <p className="mt-1 text-[32px] font-extrabold leading-none tracking-tight">
            {formatFCFA(balance)}
          </p>

          <div className="mt-4 grid grid-cols-2 gap-2">
            <div className="rounded-2xl bg-white/10 px-3 py-2.5 backdrop-blur">
              <p className="text-[9.5px] font-bold uppercase tracking-wide text-white/60">
                Total gagné
              </p>
              <p className="text-[13px] font-extrabold">{formatFCFA(totalEarned)}</p>
            </div>
            <div className="rounded-2xl bg-white/10 px-3 py-2.5 backdrop-blur">
              <p className="text-[9.5px] font-bold uppercase tracking-wide text-white/60">
                Total retiré
              </p>
              <p className="text-[13px] font-extrabold">{formatFCFA(spent)}</p>
            </div>
          </div>

          <div className="mt-4">
            <Button
              variant="accent"
              size="md"
              fullWidth
              onClick={openWithdraw}
              leftIcon={<Banknote className="h-[18px] w-[18px]" strokeWidth={2.4} />}
            >
              Demander un retrait
            </Button>
          </div>
        </div>
      </section>

      {/* Retraits en cours */}
      {withdrawals.filter((w) => w.status === 'pending' || w.status === 'processing').length > 0 ? (
        <section className="mt-3 px-5">
          <div className="rounded-3xl bg-accent-tint/70 p-4">
            <p className="flex items-center gap-1.5 text-[11.5px] font-extrabold uppercase tracking-wide text-accent-deep">
              <Clock className="h-3.5 w-3.5" strokeWidth={2.5} />
              Retraits en cours
            </p>
            <div className="mt-2 space-y-1.5">
              {withdrawals
                .filter((w) => w.status === 'pending' || w.status === 'processing')
                .map((w) => (
                  <div
                    key={w.id}
                    className="flex items-center justify-between rounded-xl bg-white/80 px-3 py-2"
                  >
                    <span className="text-[11.5px] font-semibold text-ink">
                      {formatFCFA(w.amount)} · {PAYMENT_LABELS[w.method]}
                    </span>
                    <Badge tone={WITHDRAWAL_STATUS_META[w.status].tone}>
                      {WITHDRAWAL_STATUS_META[w.status].label}
                    </Badge>
                  </div>
                ))}
            </div>
          </div>
        </section>
      ) : null}

      {/* Filtres */}
      <section className="mt-4 px-5">
        <div className="flex gap-1 rounded-2xl bg-slate-100 p-1">
          {(
            [
              { key: 'all', label: 'Tout' },
              { key: 'credit', label: 'Gains' },
              { key: 'debit', label: 'Débits' },
            ] as Array<{ key: Filter; label: string }>
          ).map((tab) => (
            <button
              key={tab.key}
              type="button"
              onClick={() => setFilter(tab.key)}
              className={cn(
                'flex-1 rounded-xl py-2 text-[12px] font-bold transition-all',
                filter === tab.key ? 'bg-white text-brand shadow-sm' : 'text-muted',
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </section>

      {/* Historique */}
      <section className="mt-3 px-5">
        {error ? <Alert>{error}</Alert> : null}
        {isLoading ? (
          <ListSkeleton rows={5} />
        ) : filtered.length === 0 ? (
          <EmptyState
            icon={WalletIcon}
            title="Aucun mouvement"
            description="Vos gains publicitaires, primes de parrainage et retraits apparaîtront ici."
          />
        ) : (
          <div className="space-y-2">
            {filtered.map((tx) => {
              const meta = TRANSACTION_LABELS[tx.type];
              const Icon = TYPE_ICONS[tx.type] ?? Gift;
              const raw = Number(tx.amount);
              const isDebit = raw < 0 || tx.type === 'withdrawal' || tx.type === 'adjustment';
              const display = `${isDebit ? '−' : '+'}${formatFCFA(Math.abs(raw))}`;
              return (
                <div key={tx.id} className="card flex items-center gap-3 p-3.5">
                  <div
                    className={cn(
                      'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl',
                      isDebit ? 'bg-red-50 text-red-500' : 'bg-emerald-50 text-emerald-600',
                    )}
                  >
                    <Icon className="h-[18px] w-[18px]" strokeWidth={2.3} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12.5px] font-bold text-ink">
                      {tx.description || meta?.label || 'Transaction'}
                    </p>
                    <p className="mt-0.5 text-[10.5px] text-muted">{formatDateTime(tx.created_at)}</p>
                  </div>
                  <div className="text-right">
                    <p
                      className={cn(
                        'text-[13px] font-extrabold',
                        isDebit ? 'text-red-500' : 'text-emerald-600',
                      )}
                    >
                      {display}
                    </p>
                    {tx.status !== 'completed' ? (
                      <p className="text-[9.5px] font-bold uppercase tracking-wide text-muted">
                        {tx.status === 'pending' ? 'En attente' : 'Rejeté'}
                      </p>
                    ) : null}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      <p className="mt-5 px-8 text-center text-[10.5px] leading-relaxed text-muted/60">
        Le solde est recalculé à chaque connexion à partir de vos transactions. Retrait minimum :{' '}
        {formatFCFA(minAmount)}.
      </p>

      {/* Modale de retrait */}
      <Modal
        open={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Demander un retrait"
        subtitle={`Solde disponible : ${formatFCFA(balance)} · minimum ${formatFCFA(minAmount)}`}
      >
        <div className="space-y-4">
          <div>
            <label className="label" htmlFor="amount">
              Montant à retirer (FCFA)
            </label>
            <input
              id="amount"
              type="number"
              inputMode="numeric"
              min={minAmount}
              className="field text-[16px] font-extrabold"
              placeholder={String(minAmount)}
              value={amount}
              onChange={(e) => {
                setAmount(e.target.value);
                setModalError(null);
              }}
            />
          </div>

          <div>
            <p className="label">Moyen de réception</p>
            <div className="grid grid-cols-2 gap-2">
              {(['tmoney', 'flooz'] as PaymentMethod[]).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setMethod(m)}
                  className={cn(
                    'rounded-2xl border px-3.5 py-3 text-[12.5px] font-bold transition',
                    method === m
                      ? 'border-brand bg-brand-tint/60 text-brand'
                      : 'border-line bg-white text-ink/60',
                  )}
                >
                  {PAYMENT_LABELS[m]}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="label" htmlFor="destination">
              Numéro bénéficiaire
            </label>
            <input
              id="destination"
              type="tel"
              className="field"
              placeholder="+228 90 00 00 00"
              value={destination}
              onChange={(e) => {
                setDestination(e.target.value);
                setModalError(null);
              }}
            />
          </div>

          {modalError ? <Alert>{modalError}</Alert> : null}
          {modalSuccess ? <Alert tone="success">{modalSuccess}</Alert> : null}

          <Button
            size="lg"
            fullWidth
            isLoading={submitting}
            disabled={
              Boolean(modalSuccess) ||
              !amount ||
              Number(amount) < minAmount ||
              destination.trim().length < 8
            }
            onClick={handleWithdraw}
          >
            Envoyer la demande
          </Button>

          <p className="text-[10.5px] leading-relaxed text-muted">
            Le montant est réservé dès la demande et débité lors du versement. Les demandes
            inférieures au minimum ou supérieures au solde disponible sont refusées.
          </p>
        </div>
      </Modal>
    </div>
  );
}
