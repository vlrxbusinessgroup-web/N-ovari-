import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Crown,
  Check,
  Clock4,
  Coins,
  Gift,
  Smartphone,
  ShieldCheck,
  ArrowRight,
  Search,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import {
  PAYMENT_LABELS,
  PAYMENT_NUMBERS,
  fetchMyPayments,
  fetchPackages,
  submitPayment,
} from '@/lib/payments';
import { formatFCFA, formatDateTime } from '@/lib/format';
import { cn } from '@/lib/cn';
import { Badge, VipBadge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { Alert, EmptyState, ListSkeleton } from '@/components/ui/Feedback';
import { PageHeader } from '@/components/ui/PageHeader';
import type { Package, PaymentMethod, TestPayment } from '@/types/database';

type Filter = 'all' | 'classic' | 'vip';

/**
 * FORFAITS — les 20 niveaux officiels (LV1 → LV20)
 * -------------------------------------------------------------
 * • Les données proviennent intégralement de la table `packages`.
 * • Paiement MANUEL : l'utilisateur envoie le montant puis saisit sa référence.
 * • L'activation n'a lieu qu'après validation de l'administration.
 * • LV17 → LV20 : badge doré VIP.
 */
export default function PackagesPage() {
  const { session, activePackage, membership } = useAuth();
  const userId = session?.user.id ?? '';

  const [packages, setPackages] = useState<Package[]>([]);
  const [payments, setPayments] = useState<TestPayment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<Filter>('all');
  const [query, setQuery] = useState('');

  const [selected, setSelected] = useState<Package | null>(null);
  const [method, setMethod] = useState<PaymentMethod>('tmoney');
  const [reference, setReference] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [modalError, setModalError] = useState<string | null>(null);
  const [modalSuccess, setModalSuccess] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!userId) return;
    try {
      setIsLoading(true);
      setError(null);
      const [pkgList, paymentList] = await Promise.all([
        fetchPackages(),
        fetchMyPayments(userId),
      ]);
      setPackages(pkgList);
      setPayments(paymentList);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Impossible de charger les forfaits.');
    } finally {
      setIsLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    void load();
  }, [load]);

  const pendingPayments = payments.filter((p) => p.status === 'pending');

  const visiblePackages = useMemo(() => {
    const term = query.trim().toLowerCase();
    return packages.filter((pkg) => {
      const matchFilter =
        filter === 'all' ||
        (filter === 'vip' && pkg.is_vip) ||
        (filter === 'classic' && !pkg.is_vip);
      const matchQuery =
        term === '' ||
        pkg.name.toLowerCase().includes(term) ||
        String(pkg.price).includes(term) ||
        String(pkg.level) === term;
      return matchFilter && matchQuery;
    });
  }, [packages, filter, query]);

  const openPayment = (pkg: Package) => {
    setSelected(pkg);
    setReference('');
    setModalError(null);
    setModalSuccess(null);
    setMethod('tmoney');
  };

  const closePayment = () => {
    setSelected(null);
    setReference('');
    setModalError(null);
    setModalSuccess(null);
  };

  const handleSubmit = async () => {
    if (!selected || !userId) return;
    setSubmitting(true);
    setModalError(null);
    try {
      await submitPayment({ userId, pkg: selected, method, reference });
      setModalSuccess(
        'Déclaration enregistrée. Votre forfait sera activé dès validation du paiement par l’administration.',
      );
      setReference('');
      const refreshed = await fetchMyPayments(userId);
      setPayments(refreshed);
    } catch (err) {
      setModalError(err instanceof Error ? err.message : 'Enregistrement impossible.');
    } finally {
      setSubmitting(false);
    }
  };

  const currentLevel = activePackage?.level ?? 0;

  return (
    <div className="animate-fade-up">
      <PageHeader
        title="Forfaits"
        subtitle="20 niveaux · gain quotidien en FCFA · forfait à vie"
      />

      {/* Forfait actuel */}
      {activePackage ? (
        <div className="px-5">
          <div className="card flex items-center gap-3 p-4">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-brand-tint">
              <Crown className="h-5 w-5 text-brand" strokeWidth={2.3} />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <p className="text-[13.5px] font-extrabold text-ink">
                  Forfait actuel : {activePackage.name}
                </p>
                {activePackage.is_vip ? <VipBadge /> : null}
              </div>
              <p className="mt-0.5 text-[11.5px] text-muted">
                {activePackage.tasks_per_day} tâches / jour ·{' '}
                {formatFCFA(activePackage.daily_reward)} par jour ·{' '}
                {membership?.expires_at ? `jusqu’au ${formatDateTime(membership.expires_at)}` : 'à vie'}
              </p>
            </div>
          </div>
        </div>
      ) : null}

      {/* Paiement(s) en attente */}
      {pendingPayments.length > 0 ? (
        <div className="mt-3 px-5">
          <div className="rounded-3xl bg-accent-tint/80 p-4">
            <p className="flex items-center gap-2 text-[12.5px] font-extrabold text-accent-deep">
              <ShieldCheck className="h-4 w-4" strokeWidth={2.5} />
              {pendingPayments.length} paiement{pendingPayments.length > 1 ? 's' : ''} en vérification
            </p>
            <div className="mt-2 space-y-1.5">
              {pendingPayments.slice(0, 3).map((p) => (
                <div
                  key={p.id}
                  className="flex items-center justify-between rounded-xl bg-white/70 px-3 py-2"
                >
                  <span className="text-[11.5px] font-semibold text-ink">
                    {p.package?.name ?? 'Forfait'} · {formatFCFA(p.amount)}
                  </span>
                  <span className="text-[10.5px] font-medium text-muted">
                    Réf. {p.reference}
                  </span>
                </div>
              ))}
            </div>
            <p className="mt-2 text-[10.5px] leading-relaxed text-accent-deep/80">
              L’activation est effectuée manuellement par l’administration après vérification de
              la référence.
            </p>
          </div>
        </div>
      ) : null}

      {/* Filtres */}
      <div className="mt-4 flex items-center gap-2 px-5">
        <div className="flex flex-1 gap-1 rounded-2xl bg-slate-100 p-1">
          {(
            [
              { key: 'all', label: 'Tous' },
              { key: 'classic', label: 'LV1–16' },
              { key: 'vip', label: 'VIP' },
            ] as Array<{ key: Filter; label: string }>
          ).map((tab) => (
            <button
              key={tab.key}
              type="button"
              onClick={() => setFilter(tab.key)}
              className={cn(
                'flex-1 rounded-xl py-2 text-[12px] font-bold transition-all',
                filter === tab.key ? 'bg-white text-brand shadow-sm' : 'text-muted',
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-3 px-5">
        <div className="relative">
          <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted/60" />
          <input
            className="field py-3 pl-11 text-[13px]"
            placeholder="Rechercher un niveau ou un montant…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            inputMode="search"
          />
        </div>
      </div>

      {/* Liste */}
      <div className="mt-4 px-5">
        {isLoading ? (
          <ListSkeleton rows={5} />
        ) : error ? (
          <Alert>{error}</Alert>
        ) : visiblePackages.length === 0 ? (
          <EmptyState
            icon={Crown}
            title="Aucun forfait trouvé"
            description="Modifiez votre recherche ou vérifiez que la table packages est alimentée."
          />
        ) : (
          <div className="space-y-3">
            {visiblePackages.map((pkg) => {
              const isCurrent = pkg.level === currentLevel;
              const hasPending = pendingPayments.some((p) => p.package_id === pkg.id);
              return (
                <article
                  key={pkg.id}
                  className={cn(
                    'card overflow-hidden transition-transform active:scale-[0.995]',
                    pkg.is_vip && 'ring-1 ring-amber-300/70',
                    isCurrent && 'ring-2 ring-brand/40',
                  )}
                >
                  <div className="flex items-start justify-between gap-3 p-4 pb-3">
                    <div className="flex items-center gap-2.5">
                      <div
                        className={cn(
                          'flex h-11 w-11 items-center justify-center rounded-2xl text-[13px] font-extrabold',
                          pkg.is_vip
                            ? 'bg-gradient-to-br from-amber-200 to-amber-400 text-amber-950'
                            : 'bg-brand-tint text-brand',
                        )}
                      >
                        {pkg.level}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <p className="text-[15px] font-extrabold leading-none text-ink">
                            {pkg.name}
                          </p>
                          {pkg.is_vip ? <VipBadge /> : null}
                          {isCurrent ? <Badge tone="brand">Actuel</Badge> : null}
                        </div>
                        <p className="mt-1.5 text-[11px] font-medium text-muted">
                          Forfait à vie · activation après validation
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-[16px] font-extrabold leading-none text-brand">
                        {formatFCFA(pkg.price)}
                      </p>
                      <p className="mt-1 text-[10px] font-semibold uppercase tracking-wide text-muted">
                        à payer
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 px-4">
                    <Stat icon={Clock4} label="Tâches / j" value={String(pkg.tasks_per_day)} />
                    <Stat icon={Coins} label="Gain / j" value={formatFCFA(pkg.daily_reward)} />
                    <Stat icon={Gift} label="Bonus" value={formatFCFA(pkg.bonus)} accent />
                  </div>

                  <div className="p-4 pt-3">
                    {isCurrent ? (
                      <div className="flex items-center justify-center gap-1.5 rounded-2xl bg-emerald-50 py-3 text-[12.5px] font-bold text-emerald-700">
                        <Check className="h-4 w-4" strokeWidth={3} />
                        Forfait actif
                      </div>
                    ) : hasPending ? (
                      <div className="rounded-2xl bg-accent-tint py-3 text-center text-[12.5px] font-bold text-accent-deep">
                        Paiement en attente de validation
                      </div>
                    ) : (
                      <Button
                        size="md"
                        fullWidth
                        variant={pkg.is_vip ? 'accent' : 'primary'}
                        onClick={() => openPayment(pkg)}
                        rightIcon={<ArrowRight className="h-4 w-4" strokeWidth={2.5} />}
                      >
                        {pkg.is_vip ? 'Devenir VIP' : 'Choisir ce forfait'}
                      </Button>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>

      <p className="mt-5 px-8 text-center text-[10.5px] leading-relaxed text-muted/60">
        Paiement manuel par T-Money ou Flooz. Conservez votre référence de transaction : elle
        conditionne l’activation de votre forfait.
      </p>

      {/* Modale de paiement manuel */}
      <Modal
        open={Boolean(selected)}
        onClose={closePayment}
        title={selected ? `Payer le forfait ${selected.name}` : 'Paiement'}
        subtitle={
          selected
            ? `${formatFCFA(selected.price)} · ${selected.tasks_per_day} tâches/jour · bonus ${formatFCFA(selected.bonus)}`
            : undefined
        }
      >
        {selected ? (
          <div className="space-y-4">
            {/* Étapes */}
            <ol className="space-y-2.5 rounded-2xl bg-slate-50 p-4">
              {[
                `Envoyez exactement ${formatFCFA(selected.price)} au numéro ${PAYMENT_LABELS[method]}.`,
                'Notez la référence de transaction reçue par SMS.',
                'Collez la référence ci-dessous puis validez.',
                'L’administration active votre forfait après vérification.',
              ].map((step, i) => (
                <li key={step} className="flex items-start gap-2.5 text-[12px] text-ink/75">
                  <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-brand text-[9px] font-extrabold text-white">
                    {i + 1}
                  </span>
                  {step}
                </li>
              ))}
            </ol>

            {/* Méthode */}
            <div>
              <p className="label">Moyen de paiement</p>
              <div className="grid grid-cols-2 gap-2">
                {(['tmoney', 'flooz'] as PaymentMethod[]).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setMethod(m)}
                    className={cn(
                      'flex items-center gap-2 rounded-2xl border px-3.5 py-3 text-left transition',
                      method === m
                        ? 'border-brand bg-brand-tint/60'
                        : 'border-line bg-white text-muted',
                    )}
                  >
                    <Smartphone
                      className={cn('h-4 w-4', method === m ? 'text-brand' : 'text-muted/60')}
                      strokeWidth={2.3}
                    />
                    <span
                      className={cn(
                        'text-[12.5px] font-bold',
                        method === m ? 'text-brand' : 'text-ink/60',
                      )}
                    >
                      {PAYMENT_LABELS[m]}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Numéro de collecte */}
            <div className="rounded-2xl border border-dashed border-brand/25 bg-brand-tint/40 p-4">
              <p className="text-[10.5px] font-bold uppercase tracking-wide text-brand/70">
                Numéro {PAYMENT_LABELS[method]} de réception
              </p>
              <p className="mt-1 select-all text-[16px] font-extrabold tracking-wide text-brand">
                {PAYMENT_NUMBERS[method] || 'Numéro à configurer (.env)'}
              </p>
              <p className="mt-1 text-[10.5px] text-muted">
                Montant exact : <span className="font-bold text-ink">{formatFCFA(selected.price)}</span>
              </p>
            </div>

            {/* Référence */}
            <div>
              <label className="label" htmlFor="reference">
                Référence de transaction
              </label>
              <input
                id="reference"
                className="field font-semibold uppercase tracking-wide"
                placeholder="Ex. TM240826.1432.A12345"
                value={reference}
                onChange={(e) => {
                  setReference(e.target.value.toUpperCase());
                  setModalError(null);
                }}
                autoComplete="off"
              />
            </div>

            {modalError ? <Alert>{modalError}</Alert> : null}
            {modalSuccess ? <Alert tone="success">{modalSuccess}</Alert> : null}

            <Button
              size="lg"
              fullWidth
              isLoading={submitting}
              disabled={reference.trim().length < 4 || Boolean(modalSuccess)}
              onClick={handleSubmit}
            >
              Envoyer ma référence
            </Button>

            <p className="flex items-start gap-1.5 text-[10.5px] leading-relaxed text-muted">
              <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand" />
              Aucun paiement automatique : la validation est humaine, sous 24 h ouvrées en
              moyenne. Une référence erronée entraîne le rejet de la demande.
            </p>
          </div>
        ) : null}
      </Modal>
    </div>
  );
}

function Stat({
  icon: Icon,
  label,
  value,
  accent = false,
}: {
  icon: typeof Clock4;
  label: string;
  value: string;
  accent?: boolean;
}) {
  return (
    <div
      className={cn(
        'rounded-xl px-2.5 py-2',
        accent ? 'bg-accent-tint/60' : 'bg-slate-50',
      )}
    >
      <div className="flex items-center gap-1">
        <Icon
          className={cn('h-3 w-3', accent ? 'text-accent-deep' : 'text-muted/70')}
          strokeWidth={2.5}
        />
        <p className="text-[9.5px] font-bold uppercase tracking-wide text-muted">{label}</p>
      </div>
      <p className={cn('mt-0.5 text-[12px] font-extrabold', accent ? 'text-accent-deep' : 'text-ink')}>
        {value}
      </p>
    </div>
  );
}
