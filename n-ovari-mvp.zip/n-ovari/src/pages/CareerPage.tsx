import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Crown, TrendingUp, Lock, Check, ArrowRight } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { fetchPackages } from '@/lib/payments';
import { formatFCFA } from '@/lib/format';
import { cn } from '@/lib/cn';
import { ROUTES } from '@/lib/routes';
import { Badge, VipBadge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Alert, InlineLoader } from '@/components/ui/Feedback';
import { PageHeader } from '@/components/ui/PageHeader';
import type { Package } from '@/types/database';

/**
 * CARRIÈRE — progression LV1 → LV20
 * Les paliers proviennent de la table `packages` (aucune donnée en dur).
 */
export default function CareerPage() {
  const { activePackage } = useAuth();
  const [packages, setPackages] = useState<Package[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setPackages(await fetchPackages());
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Chargement impossible.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const currentLevel = activePackage?.level ?? 0;
  const nextLevel = packages.find((p) => p.level === currentLevel + 1) ?? null;

  return (
    <div className="animate-fade-up">
      <PageHeader title="Carrière" subtitle="Votre progression dans les niveaux N-OVARI" />

      <div className="space-y-3 px-5">
        <div className="card overflow-hidden">
          <div className="flex items-center gap-3 bg-gradient-to-br from-brand to-brand-soft px-5 py-5 text-white">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/15">
              <TrendingUp className="h-6 w-6" strokeWidth={2.3} />
            </div>
            <div>
              <p className="text-[10.5px] font-bold uppercase tracking-wider text-white/60">
                Niveau actuel
              </p>
              <p className="text-lg font-extrabold leading-tight">
                {activePackage ? activePackage.name : 'LV0'}
                {activePackage?.is_vip ? ' · VIP' : ''}
              </p>
            </div>
          </div>
          <div className="p-4">
            {nextLevel ? (
              <>
                <p className="text-[12px] leading-relaxed text-muted">
                  Prochain palier :{' '}
                  <span className="font-extrabold text-ink">{nextLevel.name}</span> —{' '}
                  {nextLevel.tasks_per_day} tâches/jour,{' '}
                  {formatFCFA(nextLevel.daily_reward)} par jour.
                </p>
                <Link to={ROUTES.packages} className="mt-3 block">
                  <Button
                    size="sm"
                    fullWidth
                    rightIcon={<ArrowRight className="h-4 w-4" strokeWidth={2.5} />}
                  >
                    Évoluer vers {nextLevel.name}
                  </Button>
                </Link>
              </>
            ) : (
              <p className="text-[12px] leading-relaxed text-muted">
                Vous êtes au niveau maximum (LV20). Profitez des bonus VIP occasionnels.
              </p>
            )}
          </div>
        </div>

        {error ? <Alert>{error}</Alert> : null}

        <div className="card overflow-hidden">
          <div className="border-b border-line/70 px-4 py-3">
            <p className="text-[12px] font-extrabold text-ink">Grille des niveaux</p>
          </div>
          {isLoading ? (
            <InlineLoader />
          ) : (
            <ul className="divide-y divide-line/60">
              {packages.map((pkg) => {
                const unlocked = pkg.level <= currentLevel;
                const isCurrent = pkg.level === currentLevel;
                return (
                  <li
                    key={pkg.id}
                    className={cn(
                      'flex items-center gap-3 px-4 py-3',
                      isCurrent && 'bg-brand-tint/40',
                    )}
                  >
                    <div
                      className={cn(
                        'flex h-8 w-8 shrink-0 items-center justify-center rounded-xl text-[11px] font-extrabold',
                        pkg.is_vip
                          ? 'bg-gradient-to-br from-amber-200 to-amber-400 text-amber-950'
                          : unlocked
                            ? 'bg-emerald-50 text-emerald-600'
                            : 'bg-slate-100 text-slate-400',
                      )}
                    >
                      {unlocked ? (
                        isCurrent ? (
                          <Crown className="h-4 w-4" strokeWidth={2.5} />
                        ) : (
                          <Check className="h-4 w-4" strokeWidth={3} />
                        )
                      ) : (
                        <Lock className="h-3.5 w-3.5" strokeWidth={2.5} />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <p className="text-[12.5px] font-extrabold text-ink">{pkg.name}</p>
                        {pkg.is_vip ? <VipBadge /> : null}
                        {isCurrent ? <Badge tone="brand">Actuel</Badge> : null}
                      </div>
                      <p className="text-[10.5px] text-muted">
                        {pkg.tasks_per_day} tâches/j · {formatFCFA(pkg.daily_reward)}/j · bonus{' '}
                        {formatFCFA(pkg.bonus)}
                      </p>
                    </div>
                    <p className="text-[11.5px] font-extrabold text-brand">{formatFCFA(pkg.price)}</p>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        <p className="pb-4 text-center text-[10px] leading-relaxed text-muted/60">
          Le passage à un niveau supérieur se fait par l’achat du forfait correspondant, validé par
          l’administration.
        </p>
      </div>
    </div>
  );
}
