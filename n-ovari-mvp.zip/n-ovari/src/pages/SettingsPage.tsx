import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  BadgeCheck,
  Copy,
  Crown,
  LogOut,
  Mail,
  Phone,
  Save,
  ShieldCheck,
  User,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { supabase, TABLES, getErrorMessage } from '@/lib/supabase';
import { copyToClipboard } from '@/lib/clipboard';
import { ROUTES } from '@/lib/routes';
import { formatDate } from '@/lib/format';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Alert } from '@/components/ui/Feedback';
import { PageHeader } from '@/components/ui/PageHeader';

/** PARAMÈTRES — informations du compte et sécurité */
export default function SettingsPage() {
  const { profile, activePackage, isAdmin, signOut, refresh } = useAuth();
  const navigate = useNavigate();

  const [fullName, setFullName] = useState(profile?.full_name ?? '');
  const [phone, setPhone] = useState(profile?.phone ?? '');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const handleSave = async () => {
    if (!profile) return;
    setSaving(true);
    setError(null);
    setNotice(null);
    try {
      const { error: updateError } = await supabase
        .from(TABLES.profiles)
        .update({ full_name: fullName.trim(), phone: phone.trim() })
        .eq('id', profile.id);
      if (updateError) throw new Error(getErrorMessage(updateError));
      await refresh();
      setNotice('Profil mis à jour.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Mise à jour impossible.');
    } finally {
      setSaving(false);
    }
  };

  const handleCopyCode = async () => {
    if (!profile?.referral_code) return;
    if (await copyToClipboard(profile.referral_code)) {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    navigate(ROUTES.auth, { replace: true });
  };

  return (
    <div className="animate-fade-up">
      <PageHeader title="Paramètres" subtitle="Votre compte N-OVARI" />

      <div className="space-y-3 px-5">
        {/* Identité */}
        <section className="card p-4">
          <div className="mb-3 flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-tint">
              <User className="h-4 w-4 text-brand" strokeWidth={2.4} />
            </div>
            <div>
              <p className="text-[12.5px] font-extrabold text-ink">Informations personnelles</p>
              <p className="text-[10.5px] text-muted">Visibles par l’administration uniquement</p>
            </div>
          </div>

          <div className="space-y-3">
            <div>
              <label className="label" htmlFor="name">
                Nom complet
              </label>
              <input
                id="name"
                className="field"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
              />
            </div>
            <div>
              <label className="label" htmlFor="phone">
                Téléphone (T-Money / Flooz)
              </label>
              <div className="relative">
                <Phone className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted/60" />
                <input
                  id="phone"
                  type="tel"
                  className="field pl-11"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                />
              </div>
            </div>
            <div>
              <label className="label" htmlFor="email">
                Adresse e-mail
              </label>
              <div className="relative">
                <Mail className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted/50" />
                <input
                  id="email"
                  className="field bg-slate-50 pl-11 text-muted"
                  value={profile?.email ?? ''}
                  readOnly
                />
              </div>
            </div>

            {error ? <Alert>{error}</Alert> : null}
            {notice ? <Alert tone="success">{notice}</Alert> : null}

            <Button
              fullWidth
              isLoading={saving}
              onClick={() => void handleSave()}
              leftIcon={<Save className="h-4 w-4" strokeWidth={2.4} />}
            >
              Enregistrer
            </Button>
          </div>
        </section>

        {/* Compte */}
        <section className="card divide-y divide-line/70">
          <Row
            icon={Crown}
            label="Forfait"
            value={activePackage ? activePackage.name : 'LV0 — aucun forfait'}
            extra={activePackage?.is_vip ? <Badge tone="gold">VIP</Badge> : undefined}
          />
          <button
            type="button"
            onClick={() => void handleCopyCode()}
            className="flex w-full items-center justify-between gap-3 px-4 py-3.5 text-left"
          >
            <span className="flex items-center gap-2.5 text-[12.5px] font-semibold text-ink/70">
              <ShieldCheck className="h-4 w-4 text-brand" strokeWidth={2.4} />
              Code parrain
            </span>
            <span className="flex items-center gap-1.5 text-[12.5px] font-extrabold tracking-wide text-brand">
              {profile?.referral_code ?? '—'}
              <Copy className="h-3.5 w-3.5" strokeWidth={2.4} />
              {copied ? <span className="text-[9.5px] font-bold text-emerald-600">copié</span> : null}
            </span>
          </button>
          <Row
            icon={BadgeCheck}
            label="Rôle"
            value={isAdmin ? 'Administrateur' : 'Membre'}
            extra={isAdmin ? <Badge tone="brand">Admin</Badge> : undefined}
          />
          <Row
            icon={ShieldCheck}
            label="Membre depuis"
            value={formatDate(profile?.created_at)}
          />
        </section>

        {/* Déconnexion */}
        <button
          type="button"
          onClick={() => void handleSignOut()}
          className="flex w-full items-center justify-center gap-2 rounded-3xl border border-red-200 bg-white py-4 text-[13px] font-bold text-red-600 shadow-soft transition active:scale-[0.99]"
        >
          <LogOut className="h-4 w-4" strokeWidth={2.5} />
          Se déconnecter
        </button>

        <p className="pb-4 pt-1 text-center text-[10px] leading-relaxed text-muted/60">
          N-OVARI · version MVP 0.1.0 — Regardez · Gagnez · Évoluez
        </p>
      </div>
    </div>
  );
}

function Row({
  icon: Icon,
  label,
  value,
  extra,
}: {
  icon: typeof Crown;
  label: string;
  value: string;
  extra?: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-3 px-4 py-3.5">
      <span className="flex items-center gap-2.5 text-[12.5px] font-semibold text-ink/70">
        <Icon className="h-4 w-4 text-brand" strokeWidth={2.4} />
        {label}
      </span>
      <span className="flex items-center gap-1.5 text-[12.5px] font-bold text-ink">
        {value}
        {extra}
      </span>
    </div>
  );
}
