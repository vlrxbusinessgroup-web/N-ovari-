import { Link } from 'react-router-dom';
import { Lock, Crown, Check, ArrowRight } from 'lucide-react';
import { usePackageAccess } from '@/context/AuthContext';
import { ROUTES } from '@/lib/routes';
import { Button } from '@/components/ui/Button';

/**
 * ÉCRAN "ACCÈS RESTREINT" — niveau LV0
 * Affiché à tout utilisateur sans forfait actif (tasks, jeux).
 */
export default function RestrictedAccessPage() {
  const { packageName } = usePackageAccess();

  const perks = [
    'Débloquez les tâches publicitaires quotidiennes',
    'Gagnez des récompenses créditées en FCFA',
    'Accédez aux jeux et aux bonus de votre niveau',
  ];

  return (
    <div className="animate-fade-up px-5 py-8">
      <div className="card overflow-hidden p-6 text-center">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-accent-tint">
          <Lock className="h-7 w-7 text-accent-deep" strokeWidth={2.3} />
        </div>

        <h1 className="mt-4 text-xl font-extrabold text-ink">Accès restreint</h1>
        <p className="mt-2 text-[13px] leading-relaxed text-muted">
          Votre compte est au niveau <span className="font-bold text-ink">{packageName}</span>.
          Un forfait actif est nécessaire pour accéder à ce module.
        </p>

        <ul className="mt-5 space-y-2.5 text-left">
          {perks.map((perk) => (
            <li key={perk} className="flex items-start gap-2.5 text-[12.5px] text-ink/80">
              <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-brand-tint">
                <Check className="h-3 w-3 text-brand" strokeWidth={3} />
              </span>
              {perk}
            </li>
          ))}
        </ul>

        <Link to={ROUTES.packages} className="mt-6 block">
          <Button
            size="lg"
            fullWidth
            leftIcon={<Crown className="h-[18px] w-[18px]" strokeWidth={2.4} />}
            rightIcon={<ArrowRight className="h-[18px] w-[18px]" strokeWidth={2.5} />}
          >
            Voir les forfaits
          </Button>
        </Link>

        <p className="mt-3 text-[10.5px] leading-relaxed text-muted/70">
          Le forfait est activé dès que votre paiement T-Money / Flooz est validé par
          l’administration.
        </p>
      </div>
    </div>
  );
}
