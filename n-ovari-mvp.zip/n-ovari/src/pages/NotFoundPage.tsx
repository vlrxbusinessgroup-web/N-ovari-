import { Link } from 'react-router-dom';
import { Compass } from 'lucide-react';
import { ROUTES } from '@/lib/routes';
import { Button } from '@/components/ui/Button';

export default function NotFoundPage() {
  return (
    <div className="flex min-h-[70vh] flex-col items-center justify-center px-8 text-center">
      <div className="flex h-16 w-16 items-center justify-center rounded-3xl bg-brand-tint">
        <Compass className="h-7 w-7 text-brand" strokeWidth={2.2} />
      </div>
      <h1 className="mt-4 text-xl font-extrabold text-ink">Page introuvable</h1>
      <p className="mt-1.5 text-[13px] text-muted">
        Cette page n’existe pas ou a été déplacée.
      </p>
      <Link to={ROUTES.dashboard} className="mt-6 w-full max-w-[240px]">
        <Button fullWidth>Retour au tableau de bord</Button>
      </Link>
    </div>
  );
}
