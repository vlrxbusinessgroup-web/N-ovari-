import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ArrowRight,
  BadgeCheck,
  Clock3,
  ExternalLink,
  PlayCircle,
  Sparkles,
  Timer,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import {
  completeAdTask,
  fetchActiveTasks,
  fetchTodayCompletions,
  isTaskEligible,
} from '@/lib/tasks';
import { formatFCFA } from '@/lib/format';
import { cn } from '@/lib/cn';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Alert, EmptyState, Skeleton } from '@/components/ui/Feedback';
import { PageHeader } from '@/components/ui/PageHeader';
import type { AdTask } from '@/types/database';

const DEFAULT_TIMER = 3;

/**
 * TÂCHES PUBLICITAIRES
 * -------------------------------------------------------------
 * • Garde LV0 : sans forfait actif, l'écran "Accès restreint" s'affiche.
 * • Chronomètre bloquant (3 s) avant d'activer « Suivant ».
 * • La récompense est créditée par la fonction SQL `complete_ad_task`,
 *   qui vérifie elle-même le quota quotidien et le niveau du forfait.
 */
export default function TasksPage() {
  const { session, activePackage, refresh } = useAuth();
  const userId = session?.user.id ?? '';

  const [tasks, setTasks] = useState<AdTask[]>([]);
  const [completedIds, setCompletedIds] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [index, setIndex] = useState(0);
  const [secondsLeft, setSecondsLeft] = useState(DEFAULT_TIMER);

  const level = activePackage?.level ?? 0;
  const dailyLimit = activePackage?.tasks_per_day ?? 0;

  /* ------------------------------- Chargement ------------------------------ */

  const load = useCallback(async () => {
    if (!userId) return;
    try {
      setIsLoading(true);
      setError(null);
      const [taskList, completions] = await Promise.all([
        fetchActiveTasks(),
        fetchTodayCompletions(userId),
      ]);
      setTasks(taskList);
      setCompletedIds(
        completions.map((c) => c.reference_id).filter((id): id is string => Boolean(id)),
      );
      setIndex(0);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Impossible de charger les publicités.');
    } finally {
      setIsLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    void load();
  }, [load]);

  /* ------------------------------ File d'attente --------------------------- */

  const queue = useMemo(() => {
    return tasks
      .filter((task) => isTaskEligible(task, level))
      .filter((task) => !completedIds.includes(task.id));
  }, [tasks, level, completedIds]);

  const currentTask = queue[index] ?? queue[0] ?? null;
  const remaining = Math.max(0, dailyLimit - completedIds.length);
  const quotaReached = remaining === 0;

  /* ------------------------------- Chronomètre ----------------------------- */

  useEffect(() => {
    if (!currentTask) return;
    setSecondsLeft(DEFAULT_TIMER);
    const interval = window.setInterval(() => {
      setSecondsLeft((value) => {
        if (value <= 1) {
          window.clearInterval(interval);
          return 0;
        }
        return value - 1;
      });
    }, 1000);
    return () => window.clearInterval(interval);
  }, [currentTask?.id]);

  /* -------------------------------- Validation ----------------------------- */

  const handleNext = async () => {
    if (!currentTask || secondsLeft > 0 || submitting) return;
    setSubmitting(true);
    setError(null);
    setNotice(null);
    try {
      const result = await completeAdTask(currentTask.id);
      setNotice(
        `+${formatFCFA(result.reward)} crédités · ${result.tasks_done_today}/${result.tasks_limit} publicités aujourd’hui`,
      );
      setCompletedIds((prev) => [...prev, currentTask.id]);
      setIndex(0);
      await refresh(); // met à jour le solde affiché dans l'en-tête
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Crédit impossible.');
      await load();
    } finally {
      setSubmitting(false);
    }
  };

  /* ----------------------------------- UI ---------------------------------- */

  return (
    <div className="animate-fade-up">
      <PageHeader
        title="Tâches publicitaires"
        subtitle={
          activePackage
            ? `${activePackage.name} · ${formatFCFA(activePackage.daily_reward)} par jour`
            : undefined
        }
        action={
          <div className="rounded-2xl bg-white px-3 py-2 text-center shadow-soft">
            <p className="text-[9.5px] font-bold uppercase tracking-wide text-muted">Aujourd’hui</p>
            <p className="text-[14px] font-extrabold leading-none text-brand">
              {completedIds.length}
              <span className="text-[11px] font-bold text-muted">/{dailyLimit}</span>
            </p>
          </div>
        }
      />

      <div className="px-5">
        {/* Progression du quota */}
        <div className="mb-4">
          <div className="h-2 overflow-hidden rounded-full bg-slate-200">
            <div
              className="h-full rounded-full bg-gradient-to-r from-brand to-brand-soft transition-all duration-500"
              style={{
                width: `${dailyLimit > 0 ? Math.min(100, (completedIds.length / dailyLimit) * 100) : 0}%`,
              }}
            />
          </div>
          <p className="mt-1.5 text-[11px] font-medium text-muted">
            {quotaReached
              ? 'Quota quotidien atteint — revenez demain.'
              : `Encore ${remaining} publicité${remaining > 1 ? 's' : ''} à visionner aujourd’hui.`}
          </p>
        </div>

        {error ? (
          <div className="mb-3">
            <Alert>{error}</Alert>
          </div>
        ) : null}
        {notice ? (
          <div className="mb-3">
            <Alert tone="success">{notice}</Alert>
          </div>
        ) : null}

        {/* Contenu */}
        {isLoading ? (
          <div className="card overflow-hidden">
            <Skeleton className="h-44 w-full rounded-none" />
            <div className="space-y-3 p-4">
              <Skeleton className="h-3 w-2/3" />
              <Skeleton className="h-3 w-1/3" />
              <Skeleton className="h-12 w-full" />
            </div>
          </div>
        ) : quotaReached ? (
          <EmptyState
            icon={BadgeCheck}
            title="Objectif du jour atteint"
            description={`Vous avez validé ${completedIds.length} publicités aujourd’hui. Votre prochain quota sera disponible demain.`}
          />
        ) : !currentTask ? (
          <EmptyState
            icon={PlayCircle}
            title="Aucune publicité disponible"
            description="Toutes les campagnes en cours ont été vues ou aucune campagne n’est active pour votre niveau. Revenez plus tard."
          />
        ) : (
          <article className="card overflow-hidden">
            {/* Visuel publicitaire */}
            <div className="relative aspect-[16/10] w-full bg-gradient-to-br from-brand to-brand-soft">
              {currentTask.image_url ? (
                <img
                  src={currentTask.image_url}
                  alt={currentTask.title}
                  className="h-full w-full object-cover"
                  loading="eager"
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center">
                  <PlayCircle className="h-12 w-12 text-white/40" strokeWidth={1.6} />
                </div>
              )}

              <div className="absolute left-3 top-3 flex items-center gap-1.5">
                <Badge tone="brand" className="bg-white/95 text-brand">
                  {formatFCFA(currentTask.reward)}
                </Badge>
                {currentTask.campaign?.advertiser ? (
                  <span className="rounded-full bg-ink/60 px-2.5 py-1 text-[11px] font-bold text-white backdrop-blur">
                    {currentTask.campaign.advertiser}
                  </span>
                ) : null}
              </div>

              {/* Compte à rebours visuel */}
              {secondsLeft > 0 ? (
                <div className="absolute inset-0 flex items-center justify-center bg-ink/35 backdrop-blur-[1px]">
                  <div className="flex h-20 w-20 items-center justify-center rounded-full border-4 border-white/30 bg-white/15">
                    <span className="text-3xl font-extrabold text-white">{secondsLeft}</span>
                  </div>
                </div>
              ) : null}
            </div>

            <div className="p-4">
              <h3 className="text-[15px] font-extrabold leading-snug text-ink">
                {currentTask.title}
              </h3>
              <div className="mt-1.5 flex items-center gap-3 text-[11px] font-medium text-muted">
                <span className="flex items-center gap-1">
                  <Timer className="h-3.5 w-3.5" strokeWidth={2.4} />
                  {currentTask.duration_seconds || DEFAULT_TIMER} s
                </span>
                <span className="flex items-center gap-1">
                  <Clock3 className="h-3.5 w-3.5" strokeWidth={2.4} />
                  Gain immédiat
                </span>
                {currentTask.target_url ? (
                  <a
                    href={currentTask.target_url}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="flex items-center gap-1 text-brand"
                  >
                    <ExternalLink className="h-3.5 w-3.5" strokeWidth={2.4} />
                    Voir
                  </a>
                ) : null}
              </div>

              <div className="mt-4">
                <Button
                  size="lg"
                  fullWidth
                  isLoading={submitting}
                  disabled={secondsLeft > 0}
                  onClick={handleNext}
                  rightIcon={
                    secondsLeft > 0 ? undefined : (
                      <ArrowRight className="h-[18px] w-[18px]" strokeWidth={2.5} />
                    )
                  }
                >
                  {secondsLeft > 0 ? `Patientez ${secondsLeft} s…` : 'Suivant · encaisser'}
                </Button>
              </div>

              <p className="mt-2.5 flex items-center justify-center gap-1.5 text-[10.5px] text-muted">
                <Sparkles className="h-3 w-3 text-accent" strokeWidth={2.5} />
                La récompense est créditée immédiatement dans votre portefeuille.
              </p>
            </div>
          </article>
        )}

        {/* File d'attente (aperçu) */}
        {queue.length > 1 ? (
          <div className="mt-4">
            <p className="mb-2 text-[11px] font-extrabold uppercase tracking-wide text-ink/50">
              À suivre ({queue.length - 1})
            </p>
            <div className="flex gap-2 overflow-x-auto pb-1">
              {queue.slice(1, 6).map((task) => (
                <div
                  key={task.id}
                  className={cn(
                    'flex w-[76px] shrink-0 flex-col items-center gap-1.5 rounded-2xl bg-white p-2 shadow-soft',
                  )}
                >
                  <div className="h-12 w-full overflow-hidden rounded-xl bg-slate-100">
                    {task.image_url ? (
                      <img
                        src={task.image_url}
                        alt={task.title}
                        className="h-full w-full object-cover"
                      />
                    ) : null}
                  </div>
                  <span className="text-[9.5px] font-bold text-brand">
                    {formatFCFA(task.reward)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
