import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  BadgeCheck,
  Ban,
  Banknote,
  Check,
  CreditCard,
  Megaphone,
  Gift,
  Play,
  Plus,
  RefreshCw,
  ShieldCheck,
  Users,
  X,
  Pause,
} from 'lucide-react';
import {
  approvePayment,
  createCampaign,
  fetchAdminStats,
  fetchCampaigns,
  fetchPaymentQueue,
  fetchWithdrawalQueue,
  processWithdrawal,
  rejectPayment,
  updateCampaignStatus,
  type AdminStats,
} from '@/lib/admin';
import {
  fetchGiftQueue,
  updateGiftStatus,
  GIFT_STATUS_META,
  type GameGift,
} from '@/lib/games';
import { formatDate, formatDateTime, formatFCFA, getInitials } from '@/lib/format';
import { PAYMENT_LABELS } from '@/lib/payments';
import { cn } from '@/lib/cn';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { Alert, EmptyState, ListSkeleton } from '@/components/ui/Feedback';
import { PageHeader } from '@/components/ui/PageHeader';
import type { Campaign, TestPayment, WithdrawalRequest } from '@/types/database';

type Tab = 'payments' | 'withdrawals' | 'campaigns' | 'gifts';

/**
 * ADMINISTRATION (accès caché — rôle 'admin' requis)
 * -------------------------------------------------------------
 * • Valide les paiements manuels → active le forfait À VIE, crédite le bonus
 *   et la prime de parrainage (tout est fait côté fonction SQL).
 * • Traite les demandes de retrait.
 * • Gère les campagnes publicitaires.
 * • Double barrière : RequireAdmin (UI) + policies RLS is_admin() (base).
 */
export default function AdminPage() {
  const [tab, setTab] = useState<Tab>('payments');
  const [payments, setPayments] = useState<TestPayment[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [gifts, setGifts] = useState<GameGift[]>([]);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  /* Modale de rejet */
  const [rejectTarget, setRejectTarget] = useState<TestPayment | null>(null);
  const [rejectNote, setRejectNote] = useState('');
  /* Modale campagne */
  const [isCampaignModalOpen, setIsCampaignModalOpen] = useState(false);
  const [newCampaign, setNewCampaign] = useState({
    advertiser: '',
    title: '',
    description: '',
    budget: '',
  });
  const [creating, setCreating] = useState(false);

  const load = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      const [paymentList, withdrawalList, campaignList, giftList] = await Promise.all([
        fetchPaymentQueue(),
        fetchWithdrawalQueue(),
        fetchCampaigns(),
        fetchGiftQueue(),
      ]);
      setPayments(paymentList);
      setWithdrawals(withdrawalList);
      setCampaigns(campaignList);
      setGifts(giftList);
      setStats(await fetchAdminStats(paymentList));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Accès aux données administrateur impossible.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const pendingPayments = useMemo(
    () => payments.filter((p) => p.status === 'pending'),
    [payments],
  );
  const processedPayments = useMemo(
    () => payments.filter((p) => p.status !== 'pending'),
    [payments],
  );

  const handleApprove = async (payment: TestPayment) => {
    setBusyId(payment.id);
    setError(null);
    setNotice(null);
    try {
      await approvePayment(payment.id);
      setNotice(
        `Paiement validé. Forfait ${payment.package?.name ?? ''} activé pour ${payment.profile?.full_name ?? 'le membre'}.`,
      );
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Validation impossible.');
    } finally {
      setBusyId(null);
    }
  };

  const handleReject = async () => {
    if (!rejectTarget) return;
    setBusyId(rejectTarget.id);
    try {
      await rejectPayment(rejectTarget.id, rejectNote);
      setNotice('Paiement rejeté. Le membre a été notifié.');
      setRejectTarget(null);
      setRejectNote('');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Rejet impossible.');
    } finally {
      setBusyId(null);
    }
  };

  const handleWithdrawal = async (request: WithdrawalRequest, action: 'paid' | 'rejected') => {
    setBusyId(request.id);
    try {
      await processWithdrawal(request.id, action, action === 'rejected' ? 'Demande refusée' : '');
      setNotice(action === 'paid' ? 'Retrait marqué comme payé.' : 'Retrait rejeté.');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Traitement impossible.');
    } finally {
      setBusyId(null);
    }
  };

  const handleCreateCampaign = async () => {
    setCreating(true);
    try {
      await createCampaign({
        advertiser: newCampaign.advertiser,
        title: newCampaign.title,
        description: newCampaign.description,
        budget: Number(newCampaign.budget || 0),
      });
      setNotice('Campagne créée en brouillon.');
      setIsCampaignModalOpen(false);
      setNewCampaign({ advertiser: '', title: '', description: '', budget: '' });
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Création impossible.');
    } finally {
      setCreating(false);
    }
  };

  const handleGift = async (gift: GameGift, status: GameGift['status']) => {
    setBusyId(gift.id);
    try {
      await updateGiftStatus(gift.id, status);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Mise à jour impossible.');
    } finally {
      setBusyId(null);
    }
  };

  const toggleCampaign = async (campaign: Campaign) => {
    const next = campaign.status === 'active' ? 'paused' : 'active';
    setBusyId(campaign.id);
    try {
      await updateCampaignStatus(campaign.id, next);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Mise à jour impossible.');
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="animate-fade-up">
      <PageHeader
        title="Administration"
        subtitle="Espace réservé · validation des paiements et campagnes"
        action={
          <button
            type="button"
            onClick={() => void load()}
            aria-label="Rafraîchir"
            className="flex h-9 w-9 items-center justify-center rounded-full bg-brand text-white shadow-soft"
          >
            <RefreshCw className={cn('h-4 w-4', isLoading && 'animate-spin')} strokeWidth={2.4} />
          </button>
        }
      />

      {/* Statistiques */}
      <section className="grid grid-cols-2 gap-2 px-5">
        <div className="card p-3.5">
          <p className="flex items-center gap-1.5 text-[9.5px] font-bold uppercase tracking-wide text-muted">
            <CreditCard className="h-3 w-3 text-accent-deep" strokeWidth={2.6} />
            Paiements à valider
          </p>
          <p className="mt-1 text-[18px] font-extrabold text-ink">
            {stats?.pendingPayments ?? 0}
          </p>
        </div>
        <div className="card p-3.5">
          <p className="flex items-center gap-1.5 text-[9.5px] font-bold uppercase tracking-wide text-muted">
            <Banknote className="h-3 w-3 text-emerald-600" strokeWidth={2.6} />
            Encaissé (validé)
          </p>
          <p className="mt-1 text-[18px] font-extrabold text-ink">
            {formatFCFA(stats?.totalCollected ?? 0)}
          </p>
        </div>
        <div className="card p-3.5">
          <p className="flex items-center gap-1.5 text-[9.5px] font-bold uppercase tracking-wide text-muted">
            <Users className="h-3 w-3 text-brand" strokeWidth={2.6} />
            Membres
          </p>
          <p className="mt-1 text-[18px] font-extrabold text-ink">{stats?.members ?? 0}</p>
        </div>
        <div className="card p-3.5">
          <p className="flex items-center gap-1.5 text-[9.5px] font-bold uppercase tracking-wide text-muted">
            <Banknote className="h-3 w-3 text-red-500" strokeWidth={2.6} />
            Retraits en attente
          </p>
          <p className="mt-1 text-[18px] font-extrabold text-ink">
            {stats?.pendingWithdrawals ?? 0}
          </p>
        </div>
      </section>

      {/* Onglets */}
      <section className="mt-4 px-5">
        <div className="flex gap-1 rounded-2xl bg-slate-100 p-1">
          {(
            [
              { key: 'payments', label: `Paiements${pendingPayments.length ? ` (${pendingPayments.length})` : ''}` },
              { key: 'withdrawals', label: 'Retraits' },
              { key: 'campaigns', label: 'Campagnes' },
              {
                key: 'gifts',
                label: `Lots (${gifts.filter((g) => g.status === 'pending').length})`,
              },
            ] as Array<{ key: Tab; label: string }>
          ).map((t) => (
            <button
              key={t.key}
              type="button"
              onClick={() => setTab(t.key)}
              className={cn(
                'flex-1 rounded-xl px-1 py-2 text-[10.5px] font-bold transition-all',
                tab === t.key ? 'bg-white text-brand shadow-sm' : 'text-muted',
              )}
            >
              {t.label}
            </button>
          ))}
        </div>
      </section>

      <div className="mt-3 space-y-3 px-5">
        {error ? <Alert>{error}</Alert> : null}
        {notice ? <Alert tone="success">{notice}</Alert> : null}

        {isLoading ? <ListSkeleton rows={4} /> : null}

        {/* ------------------------------ PAIEMENTS ----------------------------- */}
        {!isLoading && tab === 'payments' ? (
          <>
            {pendingPayments.length === 0 ? (
              <EmptyState
                icon={BadgeCheck}
                title="Aucun paiement en attente"
                description="Les nouvelles déclarations T-Money / Flooz apparaîtront ici."
              />
            ) : (
              pendingPayments.map((payment) => (
                <article key={payment.id} className="card p-4">
                  <div className="flex items-start gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-brand-tint text-[12px] font-extrabold text-brand">
                      {getInitials(payment.profile?.full_name)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[13px] font-extrabold text-ink">
                        {payment.profile?.full_name || 'Membre N-OVARI'}
                      </p>
                      <p className="text-[10.5px] text-muted">
                        {payment.profile?.phone || '—'} · code{' '}
                        {payment.profile?.referral_code || '—'}
                      </p>
                    </div>
                    <Badge tone="accent">{payment.package?.name ?? 'Forfait'}</Badge>
                  </div>

                  <div className="mt-3 grid grid-cols-2 gap-2">
                    <div className="rounded-xl bg-slate-50 px-3 py-2">
                      <p className="text-[9px] font-bold uppercase tracking-wide text-muted">
                        Montant
                      </p>
                      <p className="text-[12.5px] font-extrabold text-ink">
                        {formatFCFA(payment.amount)}
                      </p>
                    </div>
                    <div className="rounded-xl bg-slate-50 px-3 py-2">
                      <p className="text-[9px] font-bold uppercase tracking-wide text-muted">
                        Moyen
                      </p>
                      <p className="text-[12.5px] font-extrabold text-ink">
                        {PAYMENT_LABELS[payment.method] ?? payment.method}
                      </p>
                    </div>
                  </div>

                  <div className="mt-2 rounded-xl border border-dashed border-brand/25 bg-brand-tint/40 px-3 py-2">
                    <p className="text-[9px] font-bold uppercase tracking-wide text-brand/70">
                      Référence déclarée
                    </p>
                    <p className="select-all text-[12.5px] font-extrabold tracking-wide text-brand">
                      {payment.reference}
                    </p>
                    <p className="mt-0.5 text-[9.5px] text-muted">
                      Soumis le {formatDateTime(payment.created_at)}
                    </p>
                  </div>

                  <div className="mt-3 flex gap-2">
                    <Button
                      size="sm"
                      fullWidth
                      isLoading={busyId === payment.id}
                      onClick={() => void handleApprove(payment)}
                      leftIcon={<Check className="h-4 w-4" strokeWidth={3} />}
                    >
                      Valider
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      fullWidth
                      className="border-red-200 text-red-600 hover:bg-red-50"
                      onClick={() => {
                        setRejectTarget(payment);
                        setRejectNote('');
                      }}
                      leftIcon={<Ban className="h-4 w-4" strokeWidth={2.4} />}
                    >
                      Rejeter
                    </Button>
                  </div>
                </article>
              ))
            )}

            {processedPayments.length > 0 ? (
              <div className="pt-2">
                <h3 className="mb-2 text-[11px] font-extrabold uppercase tracking-wide text-ink/50">
                  Historique récent
                </h3>
                <div className="space-y-2">
                  {processedPayments.slice(0, 10).map((payment) => (
                    <div key={payment.id} className="card flex items-center gap-3 p-3.5">
                      <div
                        className={cn(
                          'flex h-9 w-9 items-center justify-center rounded-xl',
                          payment.status === 'approved'
                            ? 'bg-emerald-50 text-emerald-600'
                            : 'bg-red-50 text-red-500',
                        )}
                      >
                        {payment.status === 'approved' ? (
                          <Check className="h-4 w-4" strokeWidth={3} />
                        ) : (
                          <X className="h-4 w-4" strokeWidth={3} />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[12px] font-bold text-ink">
                          {payment.profile?.full_name || 'Membre'} · {payment.package?.name ?? '—'}
                        </p>
                        <p className="text-[10px] text-muted">
                          {formatDate(payment.reviewed_at ?? payment.created_at)}
                          {payment.admin_note ? ` · ${payment.admin_note}` : ''}
                        </p>
                      </div>
                      <p className="text-[12px] font-extrabold text-ink">
                        {formatFCFA(payment.amount)}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            ) : null}
          </>
        ) : null}

        {/* ------------------------------ RETRAITS ------------------------------ */}
        {!isLoading && tab === 'withdrawals' ? (
          withdrawals.length === 0 ? (
            <EmptyState
              icon={Banknote}
              title="Aucune demande de retrait"
              description="Les demandes des membres apparaîtront ici pour traitement."
            />
          ) : (
            withdrawals.map((request) => (
              <article key={request.id} className="card p-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-[13px] font-extrabold text-ink">
                      {formatFCFA(request.amount)}
                    </p>
                    <p className="text-[10.5px] text-muted">
                      {PAYMENT_LABELS[request.method]} → {request.destination}
                    </p>
                    <p className="mt-0.5 text-[9.5px] text-muted">
                      {formatDateTime(request.created_at)}
                    </p>
                  </div>
                  <Badge
                    tone={
                      request.status === 'paid'
                        ? 'success'
                        : request.status === 'rejected'
                          ? 'danger'
                          : 'accent'
                    }
                  >
                    {request.status === 'paid'
                      ? 'Payé'
                      : request.status === 'rejected'
                        ? 'Rejeté'
                        : 'En attente'}
                  </Badge>
                </div>
                {request.status === 'pending' || request.status === 'processing' ? (
                  <div className="mt-3 flex gap-2">
                    <Button
                      size="sm"
                      fullWidth
                      isLoading={busyId === request.id}
                      onClick={() => void handleWithdrawal(request, 'paid')}
                    >
                      Marquer payé
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      fullWidth
                      className="border-red-200 text-red-600 hover:bg-red-50"
                      onClick={() => void handleWithdrawal(request, 'rejected')}
                    >
                      Rejeter
                    </Button>
                  </div>
                ) : null}
              </article>
            ))
          )
        ) : null}

        {/* ----------------------------- CAMPAGNES ------------------------------ */}
        {!isLoading && tab === 'campaigns' ? (
          <>
            <Button
              size="md"
              fullWidth
              variant="outline"
              onClick={() => setIsCampaignModalOpen(true)}
              leftIcon={<Plus className="h-4 w-4" strokeWidth={2.6} />}
            >
              Nouvelle campagne
            </Button>

            {campaigns.length === 0 ? (
              <EmptyState
                icon={Megaphone}
                title="Aucune campagne"
                description="Créez une campagne publicitaire, puis ajoutez ses visuels et récompenses."
              />
            ) : (
              campaigns.map((campaign) => (
                <article key={campaign.id} className="card p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate text-[13px] font-extrabold text-ink">
                        {campaign.title}
                      </p>
                      <p className="text-[10.5px] text-muted">{campaign.advertiser}</p>
                    </div>
                    <Badge
                      tone={
                        campaign.status === 'active'
                          ? 'success'
                          : campaign.status === 'paused'
                            ? 'accent'
                            : 'neutral'
                      }
                    >
                      {campaign.status === 'active'
                        ? 'Active'
                        : campaign.status === 'paused'
                          ? 'En pause'
                          : campaign.status === 'completed'
                            ? 'Terminée'
                            : 'Brouillon'}
                    </Badge>
                  </div>
                  <div className="mt-2 flex items-center justify-between">
                    <p className="text-[10.5px] text-muted">Budget {formatFCFA(campaign.budget)}</p>
                    <button
                      type="button"
                      onClick={() => void toggleCampaign(campaign)}
                      disabled={busyId === campaign.id || campaign.status === 'completed'}
                      className="flex items-center gap-1 rounded-xl bg-slate-100 px-3 py-1.5 text-[11px] font-bold text-ink/70 disabled:opacity-40"
                    >
                      {campaign.status === 'active' ? (
                        <>
                          <Pause className="h-3 w-3" strokeWidth={2.6} /> Mettre en pause
                        </>
                      ) : (
                        <>
                          <Play className="h-3 w-3" strokeWidth={2.6} /> Activer
                        </>
                      )}
                    </button>
                  </div>
                </article>
              ))
            )}
          </>
        ) : null}
        {/* ------------------------------- LOTS -------------------------------- */}
        {!isLoading && tab === 'gifts' ? (
          gifts.length === 0 ? (
            <EmptyState
              icon={Gift}
              title="Aucun lot à livrer"
              description="Les écouteurs, téléphones et cadeaux gagnés aux jeux apparaîtront ici."
            />
          ) : (
            gifts.map((gift) => {
              const meta = GIFT_STATUS_META[gift.status];
              return (
                <article key={gift.id} className="card p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="text-[13px] font-extrabold text-ink">{gift.prize_label}</p>
                      <p className="text-[10.5px] text-muted">
                        {gift.profile?.full_name ?? 'Membre'} ·{' '}
                        {gift.profile?.phone ?? 'téléphone non renseigné'}
                      </p>
                      <p className="text-[9.5px] text-muted/80">
                        {gift.game_key === 'wheel' ? 'Roue' : gift.game_key === 'scratch' ? 'Grattage' : 'Machine à sous'}{' '}
                        · {formatDateTime(gift.created_at)}
                      </p>
                    </div>
                    <Badge tone={meta.tone}>{meta.label}</Badge>
                  </div>

                  {gift.status !== 'delivered' && gift.status !== 'cancelled' ? (
                    <div className="mt-3 flex gap-2">
                      <Button
                        size="sm"
                        fullWidth
                        isLoading={busyId === gift.id}
                        onClick={() => void handleGift(gift, 'delivered')}
                        leftIcon={<Check className="h-4 w-4" strokeWidth={3} />}
                      >
                        Marquer livré
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        fullWidth
                        className="border-line text-ink/60"
                        onClick={() => void handleGift(gift, 'preparing')}
                      >
                        En préparation
                      </Button>
                    </div>
                  ) : null}
                </article>
              );
            })
          )
        ) : null}
      </div>

      <div className="mt-5 px-5">
        <div className="flex items-start gap-2 rounded-2xl bg-brand-tint/50 px-4 py-3">
          <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-brand" strokeWidth={2.4} />
          <p className="text-[10.5px] leading-relaxed text-brand/80">
            Chaque validation est tracée dans <span className="font-bold">audit_logs</span> et
            notifiée au membre. La prime de parrainage est créditée au même moment, jamais avant.
          </p>
        </div>
      </div>

      {/* Modale de rejet */}
      <Modal
        open={Boolean(rejectTarget)}
        onClose={() => setRejectTarget(null)}
        title="Rejeter le paiement"
        subtitle={rejectTarget ? `${rejectTarget.profile?.full_name} · ${formatFCFA(rejectTarget.amount)}` : undefined}
      >
        <div className="space-y-3">
          <label className="label" htmlFor="reject-note">
            Motif communiqué au membre
          </label>
          <textarea
            id="reject-note"
            className="field min-h-[90px] resize-none"
            placeholder="Ex. Référence introuvable auprès de l’opérateur."
            value={rejectNote}
            onChange={(e) => setRejectNote(e.target.value)}
          />
          <Button
            size="lg"
            fullWidth
            variant="dark"
            isLoading={Boolean(busyId)}
            disabled={rejectNote.trim().length < 3}
            onClick={() => void handleReject()}
          >
            Confirmer le rejet
          </Button>
        </div>
      </Modal>

      {/* Modale nouvelle campagne */}
      <Modal
        open={isCampaignModalOpen}
        onClose={() => setIsCampaignModalOpen(false)}
        title="Nouvelle campagne"
        subtitle="Elle démarre en brouillon, puis vous l’activez."
      >
        <div className="space-y-3">
          <div>
            <label className="label" htmlFor="advertiser">
              Annonceur
            </label>
            <input
              id="advertiser"
              className="field"
              placeholder="Nom de l’annonceur"
              value={newCampaign.advertiser}
              onChange={(e) => setNewCampaign({ ...newCampaign, advertiser: e.target.value })}
            />
          </div>
          <div>
            <label className="label" htmlFor="campaign-title">
              Titre
            </label>
            <input
              id="campaign-title"
              className="field"
              placeholder="Ex. Lancement produit X"
              value={newCampaign.title}
              onChange={(e) => setNewCampaign({ ...newCampaign, title: e.target.value })}
            />
          </div>
          <div>
            <label className="label" htmlFor="budget">
              Budget (FCFA)
            </label>
            <input
              id="budget"
              type="number"
              inputMode="numeric"
              className="field"
              placeholder="500000"
              value={newCampaign.budget}
              onChange={(e) => setNewCampaign({ ...newCampaign, budget: e.target.value })}
            />
          </div>
          <div>
            <label className="label" htmlFor="campaign-desc">
              Description
            </label>
            <textarea
              id="campaign-desc"
              className="field min-h-[80px] resize-none"
              placeholder="Objectif de la campagne…"
              value={newCampaign.description}
              onChange={(e) => setNewCampaign({ ...newCampaign, description: e.target.value })}
            />
          </div>
          <Button
            size="lg"
            fullWidth
            isLoading={creating}
            disabled={
              newCampaign.advertiser.trim().length < 2 ||
              newCampaign.title.trim().length < 3 ||
              Number(newCampaign.budget) <= 0
            }
            onClick={() => void handleCreateCampaign()}
          >
            Créer la campagne
          </Button>
        </div>
      </Modal>
    </div>
  );
}
