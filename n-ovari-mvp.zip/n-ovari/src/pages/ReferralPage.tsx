import { useCallback, useEffect, useState } from 'react';
import {
  Check,
  Copy,
  Gift,
  Share2,
  UserPlus,
  Users,
  Clock,
  ShieldCheck,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { buildReferralLink } from '@/lib/routes';
import { copyToClipboard } from '@/lib/clipboard';
import {
  computeReferralStats,
  fetchMyReferrals,
  REFERRAL_STATUS_META,
} from '@/lib/referrals';
import { formatDate, formatFCFA, getInitials } from '@/lib/format';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Alert, EmptyState, ListSkeleton } from '@/components/ui/Feedback';
import { PageHeader } from '@/components/ui/PageHeader';
import type { MyReferralRow } from '@/types/database';

/**
 * PARRAINAGE — un seul niveau direct
 * -------------------------------------------------------------
 * • Code parrain : profiles.referral_code (généré en base à l'inscription).
 * • La prime du parrain n'est créditée qu'APRÈS validation du paiement du
 *   filleul par l'administration (statut "validated").
 * • La liste des filleuls passe par la RPC `my_referrals()` (RLS respectée).
 */
export default function ReferralPage() {
  const { profile, refresh } = useAuth();

  const [rows, setRows] = useState<MyReferralRow[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<'code' | 'link' | null>(null);

  const referralCode = profile?.referral_code ?? '';
  const referralLink = referralCode ? buildReferralLink(referralCode) : '';

  const load = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      const data = await fetchMyReferrals();
      setRows(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Impossible de charger vos filleuls.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const stats = computeReferralStats(rows);

  const handleCopy = async (value: string, kind: 'code' | 'link') => {
    const ok = await copyToClipboard(value);
    if (ok) {
      setCopied(kind);
      window.setTimeout(() => setCopied(null), 1800);
    }
  };

  const handleShare = async () => {
    if (!referralLink) return;
    const shareData = {
      title: 'N-OVARI',
      text: `Rejoignez N-OVARI avec mon code ${referralCode} — Regardez, gagnez, évoluez.`,
      url: referralLink,
    };
    if (navigator.share) {
      try {
        await navigator.share(shareData);
        return;
      } catch {
        /* l'utilisateur a annulé : on retombe sur la copie */
      }
    }
    await handleCopy(referralLink, 'link');
  };

  return (
    <div className="animate-fade-up">
      <PageHeader
        title="Parrainage"
        subtitle="Un seul niveau direct · prime après validation du filleul"
        action={
          <button
            type="button"
            onClick={() => void refresh()}
            aria-label="Actualiser"
            className="flex h-9 w-9 items-center justify-center rounded-full bg-white text-brand shadow-soft"
          >
            <Users className="h-4 w-4" strokeWidth={2.4} />
          </button>
        }
      />

      {/* Carte code parrain */}
      <section className="px-5">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand via-brand to-brand-soft p-5 text-white shadow-float">
          <div className="absolute -right-10 -top-12 h-36 w-36 rounded-full bg-accent/20 blur-2xl" />
          <div className="relative">
            <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-white/60">
              <Gift className="h-3.5 w-3.5" strokeWidth={2.5} />
              Votre code parrain
            </p>
            <div className="mt-2 flex items-center justify-between gap-3">
              <p className="select-all text-[26px] font-extrabold leading-none tracking-[0.08em]">
                {referralCode || '——'}
              </p>
              <button
                type="button"
                onClick={() => void handleCopy(referralCode, 'code')}
                className="flex h-10 items-center gap-1.5 rounded-xl bg-white/15 px-3 text-[11.5px] font-bold backdrop-blur transition active:scale-95"
              >
                {copied === 'code' ? (
                  <>
                    <Check className="h-3.5 w-3.5" strokeWidth={3} /> Copié
                  </>
                ) : (
                  <>
                    <Copy className="h-3.5 w-3.5" strokeWidth={2.5} /> Copier
                  </>
                )}
              </button>
            </div>

            <div className="mt-4 rounded-2xl bg-white/10 px-3 py-2.5 backdrop-blur">
              <p className="text-[9.5px] font-bold uppercase tracking-wide text-white/60">
                Lien de partage
              </p>
              <p className="mt-0.5 truncate text-[11.5px] font-medium text-white/90">
                {referralLink || '—'}
              </p>
            </div>

            <div className="mt-3 grid grid-cols-2 gap-2">
              <Button
                variant="accent"
                size="sm"
                fullWidth
                onClick={handleShare}
                leftIcon={<Share2 className="h-4 w-4" strokeWidth={2.4} />}
              >
                Partager
              </Button>
              <Button
                variant="glass"
                size="sm"
                fullWidth
                onClick={() => void handleCopy(referralLink, 'link')}
                leftIcon={
                  copied === 'link' ? (
                    <Check className="h-4 w-4" strokeWidth={2.6} />
                  ) : (
                    <Copy className="h-4 w-4" strokeWidth={2.4} />
                  )
                }
              >
                {copied === 'link' ? 'Copié' : 'Copier le lien'}
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Statistiques */}
      <section className="mt-4 grid grid-cols-3 gap-2 px-5">
        {[
          { label: 'Filleuls', value: String(stats.total) },
          { label: 'Validés', value: String(stats.validated) },
          { label: 'Primes', value: formatFCFA(stats.earned) },
        ].map((item) => (
          <div key={item.label} className="card px-2 py-3 text-center">
            <p className="text-[13px] font-extrabold text-ink">{item.value}</p>
            <p className="mt-0.5 text-[9.5px] font-bold uppercase tracking-wide text-muted">
              {item.label}
            </p>
          </div>
        ))}
      </section>

      {/* Règle */}
      <section className="mt-3 px-5">
        <div className="flex items-start gap-2 rounded-2xl bg-brand-tint/60 px-4 py-3">
          <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-brand" strokeWidth={2.4} />
          <p className="text-[11px] leading-relaxed text-brand/80">
            Votre prime est créditée <span className="font-extrabold">uniquement</span> lorsque
            l’administration valide le paiement du forfait de votre filleul. Un parrainage en
            attente ne génère aucun gain.
          </p>
        </div>
      </section>

      {/* Liste des filleuls */}
      <section className="mt-4 px-5">
        <h3 className="mb-2 text-[11px] font-extrabold uppercase tracking-wide text-ink/50">
          Mes filleuls
        </h3>

        {error ? <Alert>{error}</Alert> : null}

        {isLoading ? (
          <ListSkeleton rows={3} />
        ) : rows.length === 0 ? (
          <EmptyState
            icon={UserPlus}
            title="Aucun filleul pour l’instant"
            description="Partagez votre lien : chaque membre inscrit avec votre code apparaîtra ici."
            action={
              <Button size="sm" onClick={handleShare} leftIcon={<Share2 className="h-4 w-4" />}>
                Partager mon lien
              </Button>
            }
          />
        ) : (
          <div className="space-y-2">
            {rows.map((row) => {
              const meta = REFERRAL_STATUS_META[row.status];
              return (
                <div key={row.referred_id} className="card flex items-center gap-3 p-3.5">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-brand-tint text-[12px] font-extrabold text-brand">
                    {getInitials(row.full_name)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12.5px] font-bold text-ink">
                      {row.full_name || 'Membre N-OVARI'}
                    </p>
                    <p className="mt-0.5 flex items-center gap-1 text-[10.5px] text-muted">
                      <Clock className="h-3 w-3" strokeWidth={2.4} />
                      Inscrit le {formatDate(row.joined_at)}
                      {row.package_level ? ` · LV${row.package_level}` : ''}
                    </p>
                  </div>
                  <div className="text-right">
                    <Badge tone={meta.tone}>{meta.label}</Badge>
                    {row.bonus_amount ? (
                      <p className="mt-1 text-[10.5px] font-extrabold text-emerald-600">
                        +{formatFCFA(row.bonus_amount)}
                      </p>
                    ) : null}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      <p className="mt-5 px-8 text-center text-[10.5px] leading-relaxed text-muted/60">
        Le parrainage N-OVARI est limité à un niveau direct : les filleuls de vos filleuls ne
        génèrent pas de prime.
      </p>
    </div>
  );
}
