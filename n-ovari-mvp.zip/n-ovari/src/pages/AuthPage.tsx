import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  ArrowRight,
  ArrowLeft,
  Eye,
  EyeOff,
  Gift,
  Lock,
  Mail,
  Phone,
  ShieldCheck,
  User,
  AlertCircle,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { ROUTES } from '@/lib/routes';
import { cn } from '@/lib/cn';
import { Logo, Tagline } from '@/components/ui/Logo';
import { Button } from '@/components/ui/Button';

type Mode = 'signin' | 'signup';

/**
 * AUTHENTIFICATION — Connexion / Inscription
 * -------------------------------------------------------------
 * • Le code parrain est facultatif à l'inscription (1 seul niveau direct).
 * • Il est pré-rempli automatiquement depuis le lien de partage (?ref=CODE).
 * • Le code parrain PERSONNEL de l'utilisateur est généré côté Supabase
 *   (trigger handle_new_user) : il n'est jamais fabriqué par le frontend.
 */
export default function AuthPage() {
  const { session, isLoading, signIn, signUp } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const [mode, setMode] = useState<Mode>('signin');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [referralCode, setReferralCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const prefilledRef = useMemo(
    () => (searchParams.get('ref') ?? '').trim().toUpperCase(),
    [searchParams],
  );

  useEffect(() => {
    if (prefilledRef) {
      setReferralCode(prefilledRef);
      setMode('signup');
    }
  }, [prefilledRef]);

  // Session déjà active → on entre directement
  useEffect(() => {
    if (!isLoading && session) navigate(ROUTES.dashboard, { replace: true });
  }, [isLoading, session, navigate]);

  const resetMessages = () => {
    setError(null);
    setNotice(null);
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    resetMessages();

    if (mode === 'signup') {
      if (fullName.trim().length < 3) return setError('Indiquez votre nom complet.');
      if (!/^\+?\d[\d\s]{6,}$/.test(phone.trim())) return setError('Numéro de téléphone invalide.');
      if (password.length < 6) return setError('Le mot de passe doit faire au moins 6 caractères.');
    }

    setSubmitting(true);
    try {
      if (mode === 'signin') {
        await signIn(email, password);
        navigate(ROUTES.dashboard, { replace: true });
      } else {
        const { needsEmailConfirmation } = await signUp({
          fullName,
          email,
          phone,
          password,
          referralCode: referralCode || undefined,
        });
        if (needsEmailConfirmation) {
          setNotice('Compte créé. Vérifiez votre e-mail pour confirmer votre adresse, puis connectez-vous.');
          setMode('signin');
        } else {
          navigate(ROUTES.dashboard, { replace: true });
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Une erreur est survenue.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="app-shell flex min-h-screen flex-col bg-canvas">
      {/* En-tête de marque */}
      <div className="relative overflow-hidden bg-gradient-to-br from-brand via-brand to-brand-soft px-6 pb-16 pt-12 text-white">
        <div className="absolute -right-16 -top-16 h-48 w-48 rounded-full bg-white/5" />
        <div className="absolute -bottom-24 -left-12 h-56 w-56 rounded-full bg-accent/15" />
        <div className="relative flex flex-col items-center text-center">
          <div className="rounded-3xl bg-white p-2 shadow-float">
            <Logo size={64} />
          </div>
          <h1 className="mt-4 text-2xl font-extrabold tracking-tight">N-OVARI</h1>
          <p className="mt-1.5 text-[12px] font-medium text-white/70">
            Regardez <span className="text-accent-soft">•</span> Gagnez{' '}
            <span className="text-accent-soft">•</span> Évoluez
          </p>
        </div>
      </div>

      {/* Carte formulaire */}
      <div className="relative -mt-10 flex-1 px-5 pb-8">
        <div className="card animate-fade-up p-6">
          {/* Onglets */}
          <div className="mb-5 grid grid-cols-2 gap-1 rounded-2xl bg-slate-100 p-1">
            {(
              [
                { key: 'signin', label: 'Connexion' },
                { key: 'signup', label: 'Inscription' },
              ] as Array<{ key: Mode; label: string }>
            ).map((tab) => (
              <button
                key={tab.key}
                type="button"
                onClick={() => {
                  setMode(tab.key);
                  resetMessages();
                }}
                className={cn(
                  'rounded-xl py-2.5 text-[13px] font-bold transition-all',
                  mode === tab.key ? 'bg-white text-brand shadow-sm' : 'text-muted',
                )}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="space-y-3.5">
            {mode === 'signup' ? (
              <div>
                <label className="label" htmlFor="fullName">
                  Nom complet
                </label>
                <div className="relative">
                  <User className="pointer-events-none absolute left-4 top-1/2 h-[18px] w-[18px] -translate-y-1/2 text-muted/60" />
                  <input
                    id="fullName"
                    className="field pl-11"
                    placeholder="Kossi Adjovi"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    autoComplete="name"
                    required
                  />
                </div>
              </div>
            ) : null}

            <div>
              <label className="label" htmlFor="email">
                Adresse e-mail
              </label>
              <div className="relative">
                <Mail className="pointer-events-none absolute left-4 top-1/2 h-[18px] w-[18px] -translate-y-1/2 text-muted/60" />
                <input
                  id="email"
                  type="email"
                  className="field pl-11"
                  placeholder="vous@exemple.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  autoComplete="email"
                  required
                />
              </div>
            </div>

            {mode === 'signup' ? (
              <div>
                <label className="label" htmlFor="phone">
                  Numéro de téléphone (T-Money / Flooz)
                </label>
                <div className="relative">
                  <Phone className="pointer-events-none absolute left-4 top-1/2 h-[18px] w-[18px] -translate-y-1/2 text-muted/60" />
                  <input
                    id="phone"
                    type="tel"
                    className="field pl-11"
                    placeholder="+228 90 00 00 00"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    autoComplete="tel"
                    required
                  />
                </div>
              </div>
            ) : null}

            <div>
              <label className="label" htmlFor="password">
                Mot de passe
              </label>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-4 top-1/2 h-[18px] w-[18px] -translate-y-1/2 text-muted/60" />
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  className="field pl-11 pr-11"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete={mode === 'signin' ? 'current-password' : 'new-password'}
                  required
                  minLength={6}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  aria-label={showPassword ? 'Masquer le mot de passe' : 'Afficher le mot de passe'}
                  className="absolute right-3 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-muted/60 hover:text-brand"
                >
                  {showPassword ? <EyeOff className="h-[18px] w-[18px]" /> : <Eye className="h-[18px] w-[18px]" />}
                </button>
              </div>
            </div>

            {mode === 'signup' ? (
              <div>
                <label className="label" htmlFor="referralCode">
                  Code parrain <span className="font-normal text-muted">(facultatif)</span>
                </label>
                <div className="relative">
                  <Gift className="pointer-events-none absolute left-4 top-1/2 h-[18px] w-[18px] -translate-y-1/2 text-accent-deep" />
                  <input
                    id="referralCode"
                    className="field pl-11 font-semibold uppercase tracking-wide"
                    placeholder="NOVARI-XXXX"
                    value={referralCode}
                    onChange={(e) => setReferralCode(e.target.value.toUpperCase())}
                  />
                </div>
                <p className="mt-1.5 flex items-start gap-1.5 text-[11px] leading-relaxed text-muted">
                  <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand" />
                  La prime de parrainage n’est versée à votre parrain qu’après validation de
                  votre paiement par l’administration.
                </p>
              </div>
            ) : null}

            {error ? (
              <div className="flex items-start gap-2 rounded-2xl bg-red-50 px-4 py-3 text-[12.5px] font-medium text-red-700">
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                <span>{error}</span>
              </div>
            ) : null}

            {notice ? (
              <div className="flex items-start gap-2 rounded-2xl bg-emerald-50 px-4 py-3 text-[12.5px] font-medium text-emerald-700">
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" />
                <span>{notice}</span>
              </div>
            ) : null}

            <Button
              type="submit"
              size="lg"
              fullWidth
              isLoading={submitting}
              rightIcon={<ArrowRight className="h-[18px] w-[18px]" strokeWidth={2.5} />}
            >
              {mode === 'signin' ? 'Se connecter' : 'Créer mon compte'}
            </Button>
          </form>

          <button
            type="button"
            onClick={() => {
              setMode(mode === 'signin' ? 'signup' : 'signin');
              resetMessages();
            }}
            className="mt-4 flex w-full items-center justify-center gap-1.5 text-[12.5px] font-semibold text-brand"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            {mode === 'signin' ? 'Pas encore de compte ? S’inscrire' : 'Déjà inscrit ? Se connecter'}
          </button>
        </div>

        <div className="mt-6 flex flex-col items-center gap-1.5">
          <Tagline />
          <p className="max-w-[280px] text-center text-[10.5px] leading-relaxed text-muted/70">
            Plateforme de récompenses publicitaires. Montants exprimés en FCFA. Aucune donnée
            bancaire n’est demandée.
          </p>
        </div>
      </div>
    </div>
  );
}
