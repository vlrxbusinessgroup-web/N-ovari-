import { useCallback, useEffect, useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { useAuth, usePackageAccess } from '@/context/AuthContext';
import {
  fetchGameConfig,
  fetchGamePrizes,
  fetchMyGifts,
  type GameConfig,
  type GameGift,
  type GamePrize,
} from '@/lib/games';
import { cn } from '@/lib/cn';
import { Badge, VipBadge } from '@/components/ui/Badge';
import { Alert, InlineLoader } from '@/components/ui/Feedback';
import { PageHeader } from '@/components/ui/PageHeader';
import { GamesHub } from '@/components/games/GamesHub';

/**
 * JEUX — page hôte.
 * Toutes les règles (lots, probabilités, calendrier, quota) viennent de la base.
 */
export default function GamesPage() {
  const { session, refresh } = useAuth();
  const { packageName, isVip } = usePackageAccess();
  const userId = session?.user.id ?? '';

  const [config, setConfig] = useState<GameConfig | null>(null);
  const [prizes, setPrizes] = useState<GamePrize[]>([]);
  const [gifts, setGifts] = useState<GameGift[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setError(null);
      const [cfg, wheelPrizes] = await Promise.all([fetchGameConfig(), fetchGamePrizes('wheel')]);
      setConfig(cfg);
      setPrizes(wheelPrizes);
      if (userId) setGifts(await fetchMyGifts(userId));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Chargement des jeux impossible.');
    } finally {
      setIsLoading(false);
    }
  }, [userId]);

  const refreshAll = useCallback(async () => {
    await load();
    await refresh(); // solde de l'en-tête
  }, [load, refresh]);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <div className="animate-fade-up">
      <PageHeader
        title="Jeux"
        subtitle="Lots tirés au sort par N-OVARI · crédités immédiatement"
        action={
          <div className="flex items-center gap-2">
            {isVip ? <VipBadge /> : <Badge tone="brand">{packageName}</Badge>}
            <button
              type="button"
              onClick={() => void refreshAll()}
              aria-label="Rafraîchir"
              className="flex h-9 w-9 items-center justify-center rounded-full bg-white text-brand shadow-soft"
            >
              <RefreshCw className={cn('h-4 w-4', isLoading && 'animate-spin')} strokeWidth={2.5} />
            </button>
          </div>
        }
      />

      <div className="space-y-3 px-5">
        {error ? <Alert>{error}</Alert> : null}

        {isLoading && !config ? (
          <div className="card p-6">
            <InlineLoader label="Chargement des jeux…" />
          </div>
        ) : config ? (
          <GamesHub
            games={config.games ?? []}
            prizes={prizes}
            gifts={gifts}
            level={config.level}
            hasAccess={config.has_access}
            unlockLevel={config.unlock_level ?? 3}
            budget={{ month: config.budget_month ?? 0, used: config.budget_used ?? 0 }}
            weekdayToday={config.weekday_today}
            onRefresh={refreshAll}
          />
        ) : null}

        <p className="pb-3 text-center text-[10.5px] leading-relaxed text-muted/70">
          Les lots physiques (cadeau, écouteurs, téléphone) sont remis par l’équipe N-OVARI après
          prise de contact. Les gains en FCFA sont crédités instantanément.
        </p>
      </div>
    </div>
  );
}
