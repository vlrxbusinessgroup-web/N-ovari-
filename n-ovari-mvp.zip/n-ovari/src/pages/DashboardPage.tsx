import { Link } from 'react-router-dom';
import {
  ArrowUpRight,
  Crown,
  TrendingUp,
  Clock,
  ChevronRight,
  Sparkles,
  CircleDollarSign,
} from 'lucide-react';
import { useAuth, usePackageAccess } from '@/context/AuthContext';
import { ROUTES } from '@/lib/routes';
import { formatFCFA } from '@/lib/format';
import { DASHBOARD_SHORTCUTS } from '@/lib/navigation';
import { Badge, VipBadge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';

/**
 * DASHBOARD
 * -------------------------------------------------------------
 * • Solde = somme des wallet_transactions (calculée dans AuthContext).
 * • Forfait = member_packages.status = 'active' (LV0 si aucune ligne).
 * • Aucune valeur financière en dur : tout vient de Supabase.
 */
export default function DashboardPage() {
  const { profile, balance, totalEarned } = useAuth();
  const { hasAccess, packageName, level, isVip, tasksPerDay, dailyReward, expiresAt } =
    usePackageAccess();

  const firstName = profile?.full_name?.trim().split(/\s+/)[0] ?? 'Bienvenue';

  return (
    <div className="animate-fade-up">
      {/* Carte solde */}
      <section className="px-5 pt-4">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand via-brand to-brand-soft p-5 text-white shadow-float">
          <div className="absolute -right-10 -top-12 h-36 w-36 rounded-full bg-accent/20 blur-2xl" />
          <div className="absolute -bottom-16 -left-10 h-32 w-32 rounded-full bg-white/5" />

          <div className="relative">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-white/60">
                  Bonjour
                </p>
                <h2 className="mt-0.5 text-lg font-extrabold leading-tight">{firstName}</h2>
              </div>
              {hasAccess ? (
                isVip ? (
                  <VipBadge />
                ) : (
                  <Badge tone="accent">{packageName}</Badge>
                )
              ) : (
                <Badge tone="neutral" className="bg-white/15 text-white">
                  LV0
                </Badge>
              )}
            </div>

            <p className="mt-5 text-[11px] font-semibold uppercase tracking-wider text-white/60">
              Solde disponible
            </p>
            <div className="mt-1 flex items-end gap-2">
              <p className="text-[34px] font-extrabold leading-none tracking-tight">
                {formatFCFA(balance)}
              </p>
              <span className="mb-1 text-[11px] font-semibold text-white/50">FCFA</span>
            </div>

            <div className="mt-5 flex items-center gap-2">
              <Link to={ROUTES.wallet} className="flex-1">
                <Button
                  variant="accent"
                  size="sm"
                  fullWidth
                  rightIcon={<ArrowUpRight className="h-4 w-4" strokeWidth={2.5} />}
                >
                  Portefeuille
                </Button>
              </Link>
              <Link to={ROUTES.tasks} className="flex-1">
                <Button
                  variant="glass"
                  size="sm"
                  fullWidth
                  rightIcon={<ChevronRight className="h-4 w-4" strokeWidth={2.5} />}
                >
                  Tâches
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Statistiques rapides */}
      <section className="mt-4 grid grid-cols-2 gap-3 px-5">
        <div className="card p-4">
          <div className="flex items-center gap-2 text-muted">
            <TrendingUp className="h-4 w-4 text-emerald-500" strokeWidth={2.4} />
            <p className="text-[11px] font-semibold uppercase tracking-wide">Total gagné</p>
          </div>
          <p className="mt-2 text-lg font-extrabold text-ink">{formatFCFA(totalEarned)}</p>
        </div>
        <div className="card p-4">
          <div className="flex items-center gap-2 text-muted">
            <CircleDollarSign className="h-4 w-4 text-accent-deep" strokeWidth={2.4} />
            <p className="text-[11px] font-semibold uppercase tracking-wide">Gain / jour</p>
          </div>
          <p className="mt-2 text-lg font-extrabold text-ink">
            {hasAccess ? formatFCFA(dailyReward) : '—'}
          </p>
        </div>
      </section>

      {/* Forfait actuel */}
      <section className="mt-4 px-5">
        {hasAccess ? (
          <div className="card flex items-center gap-3.5 p-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-brand-tint">
              <Crown className="h-6 w-6 text-brand" strokeWidth={2.2} />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <p className="text-[14px] font-extrabold text-ink">Forfait {packageName}</p>
                {isVip ? <VipBadge /> : null}
              </div>
              <p className="mt-0.5 flex items-center gap-1 text-[11.5px] text-muted">
                <Clock className="h-3 w-3" />
                {tasksPerDay} tâches / jour · {formatFCFA(dailyReward)} par jour
              </p>
              {expiresAt ? (
                <p className="mt-0.5 text-[11px] text-muted/80">
                  Actif jusqu’au {new Date(expiresAt).toLocaleDateString('fr-FR')}
                </p>
              ) : (
                <p className="mt-0.5 text-[11px] text-muted/80">Forfait actif</p>
              )}
            </div>
            <Link
              to={ROUTES.packages}
              aria-label="Changer de forfait"
              className="flex h-9 w-9 items-center justify-center rounded-xl bg-slate-50 text-brand"
            >
              <ChevronRight className="h-4 w-4" strokeWidth={2.5} />
            </Link>
          </div>
        ) : (
          <div className="card overflow-hidden">
            <div className="flex items-start gap-3 bg-accent-tint/70 p-4">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-white">
                <Sparkles className="h-5 w-5 text-accent-deep" strokeWidth={2.3} />
              </div>
              <div>
                <p className="text-[13.5px] font-extrabold text-ink">Compte en niveau LV0</p>
                <p className="mt-0.5 text-[11.5px] leading-relaxed text-ink/60">
                  Achetez un forfait pour débloquer les tâches publicitaires et les jeux.
                </p>
              </div>
            </div>
            <div className="p-4">
              <Link to={ROUTES.packages}>
                <Button size="md" fullWidth rightIcon={<ChevronRight className="h-4 w-4" />}>
                  Choisir un forfait
                </Button>
              </Link>
              <p className="mt-2 text-center text-[10.5px] text-muted">
                Niveau {level} · activation après validation du paiement par l’administration
              </p>
            </div>
          </div>
        )}
      </section>

      {/* Raccourcis */}
      <section className="mt-5 px-5">
        <h3 className="mb-2.5 text-[13px] font-extrabold uppercase tracking-wide text-ink/50">
          Accès rapides
        </h3>
        <div className="grid grid-cols-2 gap-3">
          {DASHBOARD_SHORTCUTS.map(({ label, path, icon: Icon }) => (
            <Link
              key={path}
              to={path}
              className="card flex items-center gap-3 p-4 transition-transform active:scale-[0.98]"
            >
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-tint">
                <Icon className="h-[20px] w-[20px] text-brand" strokeWidth={2.2} />
              </span>
              <span className="text-[13px] font-bold text-ink">{label}</span>
            </Link>
          ))}
        </div>
      </section>

      <p className="mt-6 px-8 text-center text-[10.5px] leading-relaxed text-muted/60">
        Les soldes affichés sont calculés en temps réel depuis vos transactions sécurisées.
      </p>
    </div>
  );
}
