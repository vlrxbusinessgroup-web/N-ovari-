import { NavLink } from 'react-router-dom';
import { cn } from '@/lib/cn';
import { BOTTOM_NAV } from '@/lib/navigation';

/**
 * Barre de navigation fixe en bas — charte N-OVARI.
 * Mobile-first : 5 entrées, icônes vectorielles Lucide uniquement.
 */
export function BottomNav() {
  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-40 mx-auto w-full max-w-md border-t border-line/70 bg-white/90 backdrop-blur-xl safe-bottom"
      aria-label="Navigation principale"
    >
      <ul className="grid grid-cols-5 px-1 pt-1.5">
        {BOTTOM_NAV.map(({ label, shortLabel, path, icon: Icon }) => (
          <li key={path}>
            <NavLink
              to={path}
              end={path === '/'}
              aria-label={label}
              className={({ isActive }) =>
                cn(
                  'group flex flex-col items-center gap-1 rounded-2xl px-1 py-2 transition-colors',
                  isActive ? 'text-brand' : 'text-slate-400',
                )
              }
            >
              {({ isActive }) => (
                <>
                  <span
                    className={cn(
                      'flex h-9 w-9 items-center justify-center rounded-xl transition-all duration-200',
                      isActive ? 'bg-brand-tint' : 'bg-transparent group-hover:bg-slate-50',
                    )}
                  >
                    <Icon
                      className={cn('h-[21px] w-[21px]', isActive && 'scale-[1.04]')}
                      strokeWidth={isActive ? 2.5 : 2}
                    />
                  </span>
                  <span
                    className={cn(
                      'text-[10.5px] leading-none',
                      isActive ? 'font-bold' : 'font-medium',
                    )}
                  >
                    {shortLabel}
                  </span>
                </>
              )}
            </NavLink>
          </li>
        ))}
      </ul>
    </nav>
  );
}
