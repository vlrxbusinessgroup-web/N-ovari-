import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { ROUTES } from '@/lib/routes';
import { AppShell } from './AppShell';
import { LoadingScreen } from '@/components/ui/States';

/**
 * Garde 1 — Authentification.
 * Aucun accès aux modules sans session Supabase valide.
 */
export function ProtectedRoute() {
  const { session, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) return <LoadingScreen />;

  if (!session) {
    return <Navigate to={ROUTES.auth} replace state={{ from: location.pathname }} />;
  }

  return (
    <AppShell>
      <Outlet />
    </AppShell>
  );
}

/**
 * Garde 2 — Rôle administrateur (espace caché).
 * Un utilisateur standard est renvoyé vers son tableau de bord.
 */
export function RequireAdmin() {
  const { session, isLoading, isAdmin, profile } = useAuth();

  if (isLoading) return <LoadingScreen label="Vérification des droits…" />;
  if (!session) return <Navigate to={ROUTES.auth} replace />;
  // Profil non encore chargé : on patiente plutôt que de rediriger à tort
  if (!profile) return <LoadingScreen label="Vérification des droits…" />;
  if (!isAdmin) return <Navigate to={ROUTES.dashboard} replace />;

  return <Outlet />;
}
