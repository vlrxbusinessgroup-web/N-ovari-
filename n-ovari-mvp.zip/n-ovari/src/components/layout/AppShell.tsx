import type { ReactNode } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { LogOut, ShieldCheck, Wallet } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { formatFCFA } from '@/lib/format';
import { ROUTES } from '@/lib/routes';
import { Logo } from '@/components/ui/Logo';
import { BottomNav } from './BottomNav';
import { NotificationsBell } from './NotificationsBell';

/**
 * Coquille applicative : en-tête collant + zone de contenu + navigation basse fixe.
 * L'en-tête expose le solde réel (issu de wallet_transactions) et l'accès admin
 * uniquement si le rôle du profil est 'admin'.
 */
export function AppShell({ children, hideNav = false }: { children: ReactNode; hideNav?: boolean }) {
  const { profile, balance, isAdmin, signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate(ROUTES.auth, { replace: true });
  };

  return (
    <div className="app-shell flex min-h-screen flex-col">
      <header className="sticky top-0 z-30 border-b border-line/60 bg-canvas/85 backdrop-blur-xl">
        <div className="flex items-center justify-between gap-3 px-5 py-3">
          <Link to={ROUTES.dashboard} className="flex items-center gap-2">
            <Logo size={34} />
            <div className="leading-none">
              <p className="text-[15px] font-extrabold tracking-tight text-ink">
                N<span className="text-accent">-</span>OVARI
              </p>
              <p className="mt-1 text-[10px] font-medium text-muted">
                {profile?.full_name?.split(' ')[0] ?? 'Mon espace'}
              </p>
            </div>
          </Link>

          <div className="flex items-center gap-1.5">
            <Link
              to={ROUTES.wallet}
              className="flex items-center gap-1.5 rounded-full bg-white px-3 py-2 shadow-soft"
            >
              <Wallet className="h-4 w-4 text-brand" strokeWidth={2.4} />
              <span className="text-[13px] font-extrabold text-ink">{formatFCFA(balance)}</span>
            </Link>

            {isAdmin ? (
              <Link
                to={ROUTES.admin}
                aria-label="Administration"
                className="flex h-9 w-9 items-center justify-center rounded-full bg-brand text-white shadow-soft"
              >
                <ShieldCheck className="h-[18px] w-[18px]" strokeWidth={2.4} />
              </Link>
            ) : null}

            <NotificationsBell />

            <button
              type="button"
              onClick={handleSignOut}
              aria-label="Se déconnecter"
              className="flex h-9 w-9 items-center justify-center rounded-full bg-white text-ink/40 shadow-soft transition hover:text-red-500"
            >
              <LogOut className="h-[18px] w-[18px]" strokeWidth={2.2} />
            </button>
          </div>
        </div>
      </header>

      <main className={hideNav ? 'flex-1' : 'flex-1 pb-24'}>{children}</main>

      {hideNav ? null : <BottomNav />}
    </div>
  );
}
