import { useCallback, useEffect, useState } from 'react';
import {
  Bell,
  BellRing,
  CheckCheck,
  CreditCard,
  Gift,
  Info,
  ShieldAlert,
  CheckCircle2,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import {
  countUnread,
  fetchMyNotifications,
  markAllAsRead,
  markAsRead,
  type AppNotification,
} from '@/lib/notifications';
import { formatDateTime } from '@/lib/format';
import { cn } from '@/lib/cn';
import { Modal } from '@/components/ui/Modal';
import { Alert, EmptyState, InlineLoader } from '@/components/ui/Feedback';

const ICONS = {
  info: Info,
  success: CheckCircle2,
  warning: ShieldAlert,
  payment: CreditCard,
  reward: Gift,
} as const;

const TONES: Record<AppNotification['type'], string> = {
  info: 'bg-brand-tint text-brand',
  success: 'bg-emerald-50 text-emerald-600',
  warning: 'bg-accent-tint text-accent-deep',
  payment: 'bg-brand-tint text-brand',
  reward: 'bg-emerald-50 text-emerald-600',
};

/**
 * Cloche de notifications — en-tête de l'application.
 * Les messages proviennent de la table `notifications` (écrits par les
 * fonctions SQL lors des validations de paiement, primes et retraits).
 */
export function NotificationsBell() {
  const { session } = useAuth();
  const userId = session?.user.id ?? '';

  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<AppNotification[]>([]);
  const [unread, setUnread] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refreshCount = useCallback(async () => {
    if (!userId) return;
    setUnread(await countUnread(userId));
  }, [userId]);

  useEffect(() => {
    void refreshCount();
  }, [refreshCount]);

  const openSheet = async () => {
    setOpen(true);
    setIsLoading(true);
    setError(null);
    try {
      const list = await fetchMyNotifications(userId);
      setItems(list);
      // Le compteur fait foi sur les données réellement affichées
      setUnread(list.filter((n) => n.is_read === false).length);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Chargement impossible.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleMarkAll = async () => {
    try {
      await markAllAsRead(userId);
      setItems((prev) => prev.map((n) => ({ ...n, is_read: true })));
      setUnread(0);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Action impossible.');
    }
  };

  const handleRead = async (notification: AppNotification) => {
    if (notification.is_read) return;
    await markAsRead(notification.id).catch(() => undefined);
    setItems((prev) =>
      prev.map((n) => (n.id === notification.id ? { ...n, is_read: true } : n)),
    );
    setUnread((value) => Math.max(0, value - 1));
  };

  return (
    <>
      <button
        type="button"
        onClick={() => void openSheet()}
        aria-label={
          unread > 0 ? `Notifications (${unread} non lue${unread > 1 ? 's' : ''})` : 'Notifications'
        }
        className="relative flex h-9 w-9 items-center justify-center rounded-full bg-white text-ink/60 shadow-soft"
      >
        {unread > 0 ? (
          <BellRing className="h-[18px] w-[18px] text-brand" strokeWidth={2.4} />
        ) : (
          <Bell className="h-[18px] w-[18px]" strokeWidth={2.2} />
        )}
        {unread > 0 ? (
          <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-accent px-1 text-[9px] font-extrabold text-white ring-2 ring-canvas">
            {unread > 9 ? '9+' : unread}
          </span>
        ) : null}
      </button>

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Notifications"
        subtitle={
          unread > 0
            ? `${unread} non lue${unread > 1 ? 's' : ''}`
            : items.length > 0
              ? 'Tout est à jour'
              : undefined
        }
      >
        <div className="space-y-3">
          {unread > 0 ? (
            <button
              type="button"
              onClick={() => void handleMarkAll()}
              className="flex w-full items-center justify-center gap-1.5 rounded-2xl bg-slate-100 py-2.5 text-[12px] font-bold text-ink/70"
            >
              <CheckCheck className="h-4 w-4" strokeWidth={2.6} />
              Tout marquer comme lu
            </button>
          ) : null}

          {error ? <Alert>{error}</Alert> : null}
          {isLoading ? <InlineLoader label="Chargement des notifications…" /> : null}

          {!isLoading && items.length === 0 ? (
            <EmptyState
              icon={Bell}
              title="Aucune notification"
              description="Les validations de forfait, primes de parrainage et retraits apparaîtront ici."
            />
          ) : null}

          {!isLoading
            ? items.map((notification) => {
                const Icon = ICONS[notification.type] ?? Info;
                return (
                  <button
                    key={notification.id}
                    type="button"
                    onClick={() => void handleRead(notification)}
                    className={cn(
                      'flex w-full items-start gap-3 rounded-2xl border px-3.5 py-3 text-left transition',
                      notification.is_read
                        ? 'border-line/60 bg-white'
                        : 'border-brand/15 bg-brand-tint/40',
                    )}
                  >
                    <span
                      className={cn(
                        'mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-xl',
                        TONES[notification.type] ?? 'bg-slate-100 text-slate-500',
                      )}
                    >
                      <Icon className="h-4 w-4" strokeWidth={2.5} />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center gap-1.5">
                        <span className="text-[12.5px] font-extrabold text-ink">
                          {notification.title}
                        </span>
                        {!notification.is_read ? (
                          <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />
                        ) : null}
                      </span>
                      {notification.body ? (
                        <span className="mt-0.5 block text-[11.5px] leading-relaxed text-muted">
                          {notification.body}
                        </span>
                      ) : null}
                      <span className="mt-1 block text-[10px] text-muted/70">
                        {formatDateTime(notification.created_at)}
                      </span>
                    </span>
                  </button>
                );
              })
            : null}
        </div>
      </Modal>
    </>
  );
}
