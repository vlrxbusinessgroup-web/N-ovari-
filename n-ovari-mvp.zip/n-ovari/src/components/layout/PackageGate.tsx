import type { ReactNode } from 'react';
import { usePackageAccess } from '@/context/AuthContext';
import RestrictedAccessPage from '@/pages/RestrictedAccessPage';

/**
 * RÈGLE MÉTIER ABSOLUE — LV0
 * L'utilisateur sans forfait actif ne peut ni consulter les tâches publicitaires
 * ni jouer. Les modules concernés sont enveloppés dans cette garde.
 */
export function PackageGate({ children }: { children: ReactNode }) {
  const { hasAccess } = usePackageAccess();
  if (!hasAccess) return <RestrictedAccessPage />;
  return <>{children}</>;
}
