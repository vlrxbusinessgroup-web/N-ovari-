import type { LucideIcon } from 'lucide-react';
import type { ReactNode } from 'react';
import { AlertTriangle, CheckCircle2, Info, Loader2 } from 'lucide-react';
import { cn } from '@/lib/cn';

/* -------------------------------- ALERTE -------------------------------- */

export function Alert({
  tone = 'error',
  children,
}: {
  tone?: 'error' | 'success' | 'info' | 'warning';
  children: ReactNode;
}) {
  const config = {
    error: { icon: AlertTriangle, cls: 'bg-red-50 text-red-700' },
    success: { icon: CheckCircle2, cls: 'bg-emerald-50 text-emerald-700' },
    info: { icon: Info, cls: 'bg-brand-tint text-brand' },
    warning: { icon: AlertTriangle, cls: 'bg-accent-tint text-accent-deep' },
  }[tone];
  const Icon = config.icon;
  return (
    <div
      className={cn(
        'flex items-start gap-2 rounded-2xl px-4 py-3 text-[12.5px] font-medium leading-relaxed',
        config.cls,
      )}
    >
      <Icon className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={2.3} />
      <span>{children}</span>
    </div>
  );
}

/* ------------------------------- VIDE ---------------------------------- */

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
}: {
  icon: LucideIcon;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-3xl border border-dashed border-line bg-white/60 px-6 py-10 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-tint">
        <Icon className="h-6 w-6 text-brand" strokeWidth={2.2} />
      </div>
      <p className="mt-3 text-[14px] font-extrabold text-ink">{title}</p>
      {description ? (
        <p className="mt-1 max-w-[260px] text-[12px] leading-relaxed text-muted">{description}</p>
      ) : null}
      {action ? <div className="mt-4">{action}</div> : null}
    </div>
  );
}

/* ------------------------------ SKELETON -------------------------------- */

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn('animate-pulse rounded-2xl bg-slate-200/70', className)} />;
}

export function ListSkeleton({ rows = 4 }: { rows?: number }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="card flex items-center gap-3 p-4">
          <Skeleton className="h-11 w-11 rounded-xl" />
          <div className="flex-1 space-y-2">
            <Skeleton className="h-3 w-1/2" />
            <Skeleton className="h-2.5 w-1/3" />
          </div>
          <Skeleton className="h-3 w-14" />
        </div>
      ))}
    </div>
  );
}

/* ------------------------------- SPINNER -------------------------------- */

export function InlineLoader({ label }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-2 py-6 text-[12.5px] font-medium text-muted">
      <Loader2 className="h-4 w-4 animate-spin text-brand" strokeWidth={2.5} />
      {label ?? 'Chargement…'}
    </div>
  );
}
