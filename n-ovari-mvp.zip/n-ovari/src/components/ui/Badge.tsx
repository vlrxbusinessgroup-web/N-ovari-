import { Crown } from 'lucide-react';
import { cn } from '@/lib/cn';

export function Badge({
  children,
  tone = 'brand',
  className,
}: {
  children: React.ReactNode;
  tone?: 'brand' | 'accent' | 'neutral' | 'success' | 'danger' | 'gold';
  className?: string;
}) {
  const tones: Record<string, string> = {
    brand: 'bg-brand-tint text-brand',
    accent: 'bg-accent-tint text-accent-deep',
    neutral: 'bg-slate-100 text-slate-600',
    success: 'bg-emerald-50 text-emerald-700',
    danger: 'bg-red-50 text-red-600',
    gold: 'bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-200 text-amber-900 shadow-sm',
  };
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide',
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

/** Badge exclusif LV17 → LV20 */
export function VipBadge({ className }: { className?: string }) {
  return (
    <Badge tone="gold" className={className}>
      <Crown className="h-3 w-3" strokeWidth={2.75} />
      VIP
    </Badge>
  );
}
