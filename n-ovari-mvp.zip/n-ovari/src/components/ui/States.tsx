import { Loader2, Settings2, AlertTriangle } from 'lucide-react';
import { Button } from './Button';
import { Logo, Tagline } from './Logo';

/** Écran de chargement global */
export function LoadingScreen({ label = 'Chargement de votre espace…' }: { label?: string }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-5 bg-canvas px-6">
      <Logo size={72} />
      <div className="flex items-center gap-2 text-[13px] font-medium text-muted">
        <Loader2 className="h-4 w-4 animate-spin text-brand" strokeWidth={2.5} />
        {label}
      </div>
    </div>
  );
}

/** Écran affiché si les variables d'environnement Supabase sont absentes */
export function ConfigRequiredScreen() {
  return (
    <div className="flex min-h-screen flex-col justify-center bg-canvas px-6 py-12">
      <div className="card p-7 text-center">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-tint">
          <Settings2 className="h-7 w-7 text-brand" strokeWidth={2.2} />
        </div>
        <h1 className="text-xl font-extrabold text-ink">Connexion Supabase requise</h1>
        <p className="mt-2 text-[13px] leading-relaxed text-muted">
          Créez un fichier <code className="rounded bg-slate-100 px-1.5 py-0.5 text-[12px]">.env</code> à la
          racine du projet à partir de <code className="rounded bg-slate-100 px-1.5 py-0.5 text-[12px]">.env.example</code>,
          puis renseignez <code className="rounded bg-slate-100 px-1.5 py-0.5 text-[12px]">VITE_SUPABASE_URL</code> et{' '}
          <code className="rounded bg-slate-100 px-1.5 py-0.5 text-[12px]">VITE_SUPABASE_ANON_KEY</code>.
        </p>
        <p className="mt-3 text-[12px] text-muted/80">
          Aucun chiffre n’est simulé : l’application ne démarre qu’une fois la base réelle branchée.
        </p>
        <div className="mt-5">
          <Tagline />
        </div>
      </div>
    </div>
  );
}

/** Écran d'erreur applicatif (RLS, réseau, profil manquant…) */
export function ErrorScreen({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="flex min-h-screen flex-col justify-center bg-canvas px-6">
      <div className="card p-7 text-center">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-red-50">
          <AlertTriangle className="h-7 w-7 text-red-500" strokeWidth={2.2} />
        </div>
        <h1 className="text-lg font-extrabold text-ink">Une erreur est survenue</h1>
        <p className="mt-2 text-[13px] leading-relaxed text-muted">{message}</p>
        {onRetry ? (
          <Button className="mt-5" fullWidth onClick={onRetry}>
            Réessayer
          </Button>
        ) : null}
      </div>
    </div>
  );
}
