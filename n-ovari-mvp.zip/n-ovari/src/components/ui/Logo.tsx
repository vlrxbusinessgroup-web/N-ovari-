import { cn } from '@/lib/cn';

/** Logo officiel N-OVARI (asset /public/logo-n-ovari.png) */
export function Logo({ className, size = 40 }: { className?: string; size?: number }) {
  return (
    <img
      src="/logo-n-ovari.png"
      alt="N-OVARI"
      width={size}
      height={size}
      className={cn('object-contain select-none', className)}
      style={{ width: size, height: size }}
      draggable={false}
    />
  );
}

/** Signature textuelle "Regardez · Gagnez · Évoluez" */
export function Tagline({ className }: { className?: string }) {
  return (
    <p className={cn('text-[11px] font-medium tracking-wide text-muted', className)}>
      Regardez <span className="text-accent">•</span> Gagnez{' '}
      <span className="text-accent">•</span> Évoluez
    </p>
  );
}
