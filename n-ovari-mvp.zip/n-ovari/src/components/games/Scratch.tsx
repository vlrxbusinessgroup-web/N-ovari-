import { useCallback, useRef, useState } from 'react';
import { Eraser, Gift, Hand, Sparkles } from 'lucide-react';
import { playGame, type PlayResult } from '@/lib/games';
import { formatFCFA } from '@/lib/format';
import { cn } from '@/lib/cn';
import { Button } from '@/components/ui/Button';
import { Alert } from '@/components/ui/Feedback';
import { GameSymbol } from './GameSymbol';

const CELLS = 9;

/**
 * GRATTAGE — 3 symboles identiques sur 9 cases
 * -------------------------------------------------------------
 * • Le serveur tire le lot (80 % petits lots, 19 % lots moyens, 1 % cadeau)
 *   et renvoie la grille de 9 symboles : exactement 3 symboles gagnants.
 * • L'utilisateur gratte les cases au doigt ; le gain s'affiche dès que les
 *   3 symboles identiques sont révélés.
 */
export function Scratch({
  locked,
  lockedLabel,
  onPlayed,
}: {
  locked: boolean;
  lockedLabel?: string;
  onPlayed: (r: PlayResult) => void;
}) {
  const [board, setBoard] = useState<string[] | null>(null);
  const [revealed, setRevealed] = useState<boolean[]>(Array(CELLS).fill(false));
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<PlayResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const dragging = useRef(false);

  const start = async () => {
    if (loading || locked) return;
    setError(null);
    setLoading(true);
    setResult(null);
    setBoard(null);
    setRevealed(Array(CELLS).fill(false));
    try {
      const data = await playGame('scratch');
      setBoard(data.board ?? []);
      setResult(data);
      onPlayed(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Grattage impossible.');
    } finally {
      setLoading(false);
    }
  };

  const reveal = useCallback((index: number) => {
    setRevealed((prev) => {
      if (prev[index]) return prev;
      const next = [...prev];
      next[index] = true;
      return next;
    });
  }, []);

  const revealAll = () => setRevealed(Array(CELLS).fill(true));

  const winnerSymbol = result?.symbol ?? null;
  const revealedWinning = board
    ? board.filter((s, i) => revealed[i] && s === winnerSymbol).length
    : 0;
  const isWin = Boolean(result && result.kind !== 'cash') || Boolean(result && result.amount > 0);
  const showResult = Boolean(result) && (revealedWinning >= 3 || revealed.every(Boolean));

  return (
    <div className="card overflow-hidden">
      <div className="flex items-center justify-between gap-2 border-b border-line/60 px-4 py-3">
        <div>
          <p className="text-[10px] font-bold uppercase tracking-wider text-muted">Jeu 2</p>
          <h2 className="text-[15px] font-extrabold leading-tight text-ink">Grattage</h2>
        </div>
        <span className="flex items-center gap-1 rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-bold text-ink/60">
          <Hand className="h-3 w-3" strokeWidth={2.8} />
          3 symboles identiques
        </span>
      </div>

      <div className="space-y-3 p-4">
        {error ? <Alert>{error}</Alert> : null}

        {!board ? (
          <div className="rounded-3xl border-2 border-dashed border-brand/20 bg-brand-tint/30 px-4 py-10 text-center">
            <Gift className="mx-auto h-8 w-8 text-brand" strokeWidth={2.2} />
            <p className="mt-2 text-[12.5px] font-extrabold text-ink">9 cases à gratter</p>
            <p className="mx-auto mt-1 max-w-[240px] text-[11.5px] leading-relaxed text-muted">
              Trouvez 3 symboles identiques pour gagner le lot associé.
            </p>
          </div>
        ) : (
          <div
            className="grid grid-cols-3 gap-2 select-none touch-none"
            onPointerDown={() => {
              dragging.current = true;
            }}
            onPointerUp={() => {
              dragging.current = false;
            }}
            onPointerLeave={() => {
              dragging.current = false;
            }}
          >
            {board.map((symbol, i) => (
              <button
                key={i}
                type="button"
                aria-label={revealed[i] ? 'Case grattée' : 'Gratter cette case'}
                onPointerDown={() => reveal(i)}
                onPointerEnter={() => {
                  if (dragging.current) reveal(i);
                }}
                className={cn(
                  'relative flex h-[68px] items-center justify-center overflow-hidden rounded-2xl transition-all',
                  revealed[i]
                    ? 'bg-white ring-1 ring-line'
                    : 'bg-gradient-to-br from-brand to-brand-soft',
                )}
              >
                {revealed[i] ? (
                  <GameSymbol symbol={symbol} size="md" />
                ) : (
                  <span className="text-[10px] font-extrabold uppercase tracking-wide text-white/70">
                    Gratter
                  </span>
                )}
              </button>
            ))}
          </div>
        )}

        {board && !revealed.every(Boolean) ? (
          <button
            type="button"
            onClick={revealAll}
            className="flex w-full items-center justify-center gap-1.5 rounded-2xl bg-slate-100 py-2.5 text-[11.5px] font-bold text-ink/60"
          >
            <Eraser className="h-3.5 w-3.5" strokeWidth={2.6} />
            Tout révéler
          </button>
        ) : null}

        {showResult && result ? (
          isWin ? (
            <div
              className={cn(
                'rounded-2xl px-4 py-3 text-center',
                result.kind === 'gift'
                  ? 'bg-gradient-to-br from-amber-200 via-yellow-300 to-amber-200 text-amber-950'
                  : 'bg-emerald-50 text-emerald-700',
              )}
            >
              <p className="text-[11px] font-extrabold uppercase tracking-wide">
                {result.kind === 'gift' ? 'Lot décroché' : '3 symboles identiques'}
              </p>
              <p className="text-[22px] font-extrabold leading-tight">
                {result.kind === 'gift' ? result.label : formatFCFA(result.amount)}
              </p>
              <p className="mt-0.5 text-[10.5px] opacity-80">
                {result.kind === 'gift'
                  ? 'Enregistré · l’équipe N-OVARI vous contacte'
                  : 'Crédité sur votre portefeuille'}
              </p>
            </div>
          ) : (
            <div className="rounded-2xl bg-slate-100 px-4 py-3 text-center">
              <p className="text-[11.5px] font-extrabold text-ink/70">Pas de combinaison</p>
              <p className="text-[10.5px] text-muted">Retentez à la prochaine ouverture.</p>
            </div>
          )
        ) : board ? (
          <p className="flex items-center justify-center gap-1.5 text-[11px] text-muted">
            <Sparkles className="h-3.5 w-3.5 text-accent" strokeWidth={2.5} />
            {3 - revealedWinning} symbole{3 - revealedWinning > 1 ? 's' : ''} identique
            {3 - revealedWinning > 1 ? 's' : ''} restant à trouver
          </p>
        ) : null}

        <Button size="lg" fullWidth isLoading={loading} disabled={locked} onClick={() => void start()}>
          {locked ? (lockedLabel ?? 'Quota atteint') : board ? 'Nouvelle grille' : 'Obtenir une grille'}
        </Button>
      </div>
    </div>
  );
}
