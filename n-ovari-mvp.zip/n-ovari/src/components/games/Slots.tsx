import { useEffect, useRef, useState } from 'react';
import { Play, Sparkles } from 'lucide-react';
import { playGame, type PlayResult } from '@/lib/games';
import { formatFCFA } from '@/lib/format';
import { Button } from '@/components/ui/Button';
import { Alert } from '@/components/ui/Feedback';
import { GameSymbol } from './GameSymbol';

const SPIN_MS = 2000;
const TICK_MS = 90;
const ALL = ['cherry', 'bell', 'gem'] as const;

/**
 * MACHINE À SOUS — 3 rouleaux (cerise, cloche, diamant)
 * -------------------------------------------------------------
 * • 3 🍒 = 100 F · 3 🔔 = 500 F · 3 💎 = 2 000 F
 * • Le serveur tire le résultat avant l'animation ; les rouleaux tournent
 *   pendant 2 secondes puis s'arrêtent sur les symboles renvoyés.
 * (Les emojis de la spécification sont rendus en icônes Lucide, conformément
 *  à la charte graphique : aucun emoji dans l'interface.)
 */
export function Slots({
  locked,
  lockedLabel,
  onPlayed,
}: {
  locked: boolean;
  lockedLabel?: string;
  onPlayed: (r: PlayResult) => void;
}) {
  const [reels, setReels] = useState<string[]>(['cherry', 'bell', 'gem']);
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState<PlayResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const interval = useRef<number | null>(null);

  useEffect(() => () => {
    if (interval.current) window.clearInterval(interval.current);
  }, []);

  const spin = async () => {
    if (spinning || locked) return;
    setError(null);
    setResult(null);
    setSpinning(true);

    // Rouleaux qui défilent
    interval.current = window.setInterval(() => {
      setReels([
        ALL[Math.floor(Math.random() * ALL.length)],
        ALL[Math.floor(Math.random() * ALL.length)],
        ALL[Math.floor(Math.random() * ALL.length)],
      ]);
    }, TICK_MS);

    try {
      const data = await playGame('slots');
      // Arrêt après 2 s sur le résultat renvoyé par le serveur
      window.setTimeout(() => {
        if (interval.current) window.clearInterval(interval.current);
        setReels(data.reels ?? ['cherry', 'bell', 'gem']);
        setResult(data);
        setSpinning(false);
        onPlayed(data);
      }, SPIN_MS);
    } catch (err) {
      if (interval.current) window.clearInterval(interval.current);
      setSpinning(false);
      setError(err instanceof Error ? err.message : 'Partie impossible.');
    }
  };

  return (
    <div className="card overflow-hidden">
      <div className="flex items-center justify-between gap-2 border-b border-line/60 px-4 py-3">
        <div>
          <p className="text-[10px] font-bold uppercase tracking-wider text-muted">Jeu 3</p>
          <h2 className="text-[15px] font-extrabold leading-tight text-ink">Machine à sous</h2>
        </div>
        <span className="rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-bold text-ink/60">
          3 rouleaux
        </span>
      </div>

      <div className="space-y-3 p-4">
        {error ? <Alert>{error}</Alert> : null}

        <div className="rounded-3xl bg-gradient-to-br from-brand via-brand to-brand-soft p-4">
          <div className="grid grid-cols-3 gap-2">
            {reels.map((symbol, i) => (
              <div
                key={i}
                className="flex h-[74px] items-center justify-center rounded-2xl bg-white/95 shadow-inner"
              >
                <GameSymbol symbol={symbol} size="lg" />
              </div>
            ))}
          </div>
          <p className="mt-2 text-center text-[10px] font-semibold text-white/70">
            3 identiques = gain · {spinning ? 'en cours…' : 'à vous de jouer'}
          </p>
        </div>

        {/* Table des gains */}
        <div className="grid grid-cols-3 gap-2">
          {[
            { symbol: 'cherry', amount: 100 },
            { symbol: 'bell', amount: 500 },
            { symbol: 'gem', amount: 2000 },
          ].map((row) => (
            <div key={row.symbol} className="rounded-xl bg-slate-50 px-2 py-2 text-center">
              <div className="flex justify-center gap-0.5">
                {[0, 1, 2].map((n) => (
                  <GameSymbol key={n} symbol={row.symbol} size="sm" className="h-6 w-6 rounded-md" />
                ))}
              </div>
              <p className="mt-1 text-[11px] font-extrabold text-ink">{formatFCFA(row.amount)}</p>
            </div>
          ))}
        </div>

        {result ? (
          result.amount > 0 ? (
            <div className="rounded-2xl bg-emerald-50 px-4 py-3 text-center">
              <p className="text-[11px] font-extrabold uppercase tracking-wide text-emerald-700">
                {result.label}
              </p>
              <p className="text-[22px] font-extrabold leading-tight text-emerald-700">
                {formatFCFA(result.amount)}
              </p>
              <p className="mt-0.5 text-[10.5px] text-emerald-700/80">
                Crédité sur votre portefeuille
              </p>
            </div>
          ) : (
            <div className="rounded-2xl bg-slate-100 px-4 py-3 text-center">
              <p className="text-[11.5px] font-extrabold text-ink/70">Aucun alignement</p>
              <p className="text-[10.5px] text-muted">Retentez à la prochaine ouverture.</p>
            </div>
          )
        ) : (
          <p className="flex items-center justify-center gap-1.5 text-[11px] text-muted">
            <Sparkles className="h-3.5 w-3.5 text-accent" strokeWidth={2.5} />
            Tirage sécurisé par N-OVARI
          </p>
        )}

        <Button
          size="lg"
          fullWidth
          isLoading={spinning}
          disabled={locked}
          onClick={() => void spin()}
          leftIcon={<Play className="h-[18px] w-[18px]" strokeWidth={2.6} />}
        >
          {locked ? (lockedLabel ?? 'Quota atteint') : spinning ? 'Les rouleaux tournent…' : result ? 'Rejouer' : 'Lancer les rouleaux'}
        </Button>
      </div>
    </div>
  );
}
