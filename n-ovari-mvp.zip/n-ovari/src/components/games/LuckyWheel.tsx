import { useMemo, useState } from 'react';
import { RotateCw, Trophy, Sparkles } from 'lucide-react';
import { playGame, type GamePrize, type PlayResult } from '@/lib/games';
import { formatFCFA } from '@/lib/format';
import { cn } from '@/lib/cn';
import { Button } from '@/components/ui/Button';
import { Alert } from '@/components/ui/Feedback';

/** Habillage par famille de lots : plus le lot est rare, plus la case est dorée. */
const PALETTE: Record<string, { fill: string; text: string }> = {
  small: { fill: '#4C1D95', text: '#FFFFFF' },
  mid: { fill: '#7C3AED', text: '#FFFFFF' },
  big: { fill: '#D97706', text: '#FFFFFF' },
  gift: { fill: '#FBBF24', text: '#3B0F7A' },
  jackpot: { fill: '#FDE68A', text: '#4C1D95' },
};

/** Ordre officiel des 11 lots (index = position en base) */
const RARITY = [
  'small', // 25 F
  'small', // 100 F
  'gift', // Tour+ (mis en avant, mais fréquent)
  'mid', // 500 F
  'mid', // 1 000 F
  'gift', // Cadeau
  'big', // 5 000 F
  'big', // 15 000 F
  'gift', // Écouteurs
  'jackpot', // Téléphone
  'jackpot', // 25 000 F
];

/** Libellé court pour tenir dans une case */
function shortLabel(prize: GamePrize): string {
  if (prize.kind === 'extra_spin') return 'Tour+';
  if (prize.kind === 'gift') return prize.label === 'Écouteurs' ? 'Écout.' : prize.label;
  if (prize.amount >= 1000) return `${prize.amount / 1000}k`;
  return String(prize.amount);
}

function polar(cx: number, cy: number, r: number, angleDeg: number) {
  const rad = ((angleDeg - 90) * Math.PI) / 180;
  return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
}

/**
 * ROUE DE LA FORTUNE — 11 lots pondérés (logique officielle)
 * -------------------------------------------------------------
 * Le résultat est tiré par le serveur AVANT l'animation : la roue ne fait
 * qu'atterrir sur la case renvoyée.
 * « Tour+ » ne consomme pas le quota : le bouton reste actif.
 */
export function LuckyWheel({
  prizes,
  locked,
  lockedLabel,
  onPlayed,
}: {
  prizes: GamePrize[];
  locked: boolean;
  lockedLabel?: string;
  onPlayed: (result: PlayResult) => void;
}) {
  const [rotation, setRotation] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState<PlayResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const segments = prizes.length || 11;
  const angle = 360 / segments;

  const jackpot = useMemo(
    () => prizes.reduce((best, p) => (p.position === 10 ? p : best), prizes[0]),
    [prizes],
  );

  const spin = async () => {
    if (spinning || locked) return;
    setError(null);
    setResult(null);
    setSpinning(true);

    try {
      // 1. Tirage serveur (le résultat est connu AVANT l'animation)
      const data = await playGame('wheel');

      // 2. Animation : la case gagnante s'arrête sous le curseur (en haut)
      const targetAngle = 360 - (data.result_index * angle + angle / 2);
      const current = ((rotation % 360) + 360) % 360;
      const delta = ((targetAngle - current) % 360 + 360) % 360;
      setRotation(rotation + 360 * 5 + delta);

      window.setTimeout(() => {
        setResult(data);
        setSpinning(false);
        onPlayed(data);
      }, 4200);
    } catch (err) {
      setSpinning(false);
      setError(err instanceof Error ? err.message : 'Partie impossible.');
    }
  };

  return (
    <div className="card overflow-hidden">
      <div className="relative overflow-hidden bg-gradient-to-br from-brand via-brand to-brand-soft px-4 pb-3 pt-4 text-white">
        <div className="absolute -right-10 -top-12 h-32 w-32 rounded-full bg-accent/25 blur-2xl" />
        <div className="relative flex items-center justify-between">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-wider text-white/60">Jeu 1</p>
            <h2 className="text-[15px] font-extrabold leading-tight">Roue de la fortune</h2>
          </div>
          {jackpot ? (
            <span className="flex items-center gap-1 rounded-full bg-gradient-to-r from-amber-300 to-yellow-200 px-2.5 py-1 text-[10px] font-extrabold text-amber-950">
              <Trophy className="h-3 w-3" strokeWidth={3} />
              Jackpot {formatFCFA(jackpot.amount)}
            </span>
          ) : null}
        </div>

        <div className="relative mx-auto mt-3 w-[224px]">
          <div className="absolute -top-1 left-1/2 z-20 -translate-x-1/2">
            <div className="h-0 w-0 border-x-[9px] border-t-[16px] border-x-transparent border-t-accent drop-shadow" />
          </div>

          <div
            className="transition-transform duration-[4000ms] ease-[cubic-bezier(0.16,1,0.3,1)]"
            style={{ transform: `rotate(${rotation}deg)` }}
          >
            <svg viewBox="0 0 220 220" className="w-full drop-shadow-xl">
              <circle cx="110" cy="110" r="104" fill="#FFFFFF" fillOpacity="0.12" />
              {prizes.map((prize, i) => {
                const style = PALETTE[RARITY[i] ?? 'small'];
                const start = i * angle;
                const end = start + angle;
                const midAngle = start + angle / 2;
                // Position à l'écran après rotation de la roue
                const effectiveMid = (((midAngle + rotation) % 360) + 360) % 360;
                const a = polar(110, 110, 96, start);
                const b = polar(110, 110, 96, end);
                return (
                  <g key={prize.position}>
                    <path
                      d={`M110,110 L${a.x.toFixed(2)},${a.y.toFixed(2)} A96,96 0 0 1 ${b.x.toFixed(2)},${b.y.toFixed(2)} Z`}
                      fill={style.fill}
                      stroke="#FFFFFF"
                      strokeOpacity="0.35"
                      strokeWidth="1"
                    />
                    {/* Libellé orienté vers l'extérieur. L'orientation est
                        recalculée selon la rotation réelle de la roue : les lots
                        restent lisibles une fois la roue arrêtée. */}
                    <g transform={`rotate(${midAngle} 110 110)`}>
                      <text
                        x="110"
                        y="42"
                        fill={style.text}
                        fontSize={prize.kind === 'gift' ? 6.5 : 8.5}
                        fontWeight="800"
                        textAnchor="middle"
                        dominantBaseline="middle"
                        transform={
                          // Un libellé est « à l'envers » quand sa direction est
                          // dans (90°, 270°) : on le retourne dans ce cas.
                          effectiveMid > 90 && effectiveMid < 270
                            ? 'rotate(180 110 42)'
                            : undefined
                        }
                      >
                        {shortLabel(prize)}
                      </text>
                    </g>
                  </g>
                );
              })}
              <circle cx="110" cy="110" r="24" fill="#FFFFFF" />
              <circle cx="110" cy="110" r="16" fill="#4C1D95" />
              <text
                x="110"
                y="111"
                fill="#FFFFFF"
                fontSize="10"
                fontWeight="800"
                textAnchor="middle"
                dominantBaseline="middle"
              >
                F
              </text>
            </svg>
          </div>
        </div>
      </div>

      <div className="space-y-3 p-4">
        {error ? <Alert>{error}</Alert> : null}

        {result && !spinning ? (
          result.kind === 'extra_spin' ? (
            <div className="rounded-2xl bg-accent-tint px-4 py-3 text-center">
              <p className="text-[11px] font-extrabold uppercase tracking-wide text-accent-deep">
                Tour gratuit !
              </p>
              <p className="text-[13px] font-bold text-accent-deep">
                Votre quota n’a pas été débité, la roue est relancée.
              </p>
            </div>
          ) : result.kind === 'gift' ? (
            <div className="rounded-2xl bg-gradient-to-br from-amber-200 via-yellow-300 to-amber-200 px-4 py-3 text-center text-amber-950">
              <p className="text-[11px] font-extrabold uppercase tracking-wide">Lot décroché</p>
              <p className="text-[22px] font-extrabold leading-tight">{result.label}</p>
              <p className="mt-0.5 text-[10.5px] opacity-80">
                Enregistré · l’équipe N-OVARI vous contacte pour la remise
              </p>
            </div>
          ) : (
            <div className="rounded-2xl bg-emerald-50 px-4 py-3 text-center">
              <p className="text-[11px] font-extrabold uppercase tracking-wide text-emerald-700">
                Vous avez gagné
              </p>
              <p className="text-[24px] font-extrabold leading-tight text-emerald-700">
                {formatFCFA(result.amount)}
              </p>
              <p className="mt-0.5 text-[10.5px] text-emerald-700/80">
                Crédité sur votre portefeuille
              </p>
            </div>
          )
        ) : (
          <p className="flex items-center justify-center gap-1.5 text-[11px] text-muted">
            <Sparkles className="h-3.5 w-3.5 text-accent" strokeWidth={2.5} />
            Tirage sécurisé · 11 lots dont 3 lots physiques
          </p>
        )}

        <Button
          size="lg"
          fullWidth
          onClick={() => void spin()}
          isLoading={spinning}
          disabled={locked}
          leftIcon={
            <RotateCw
              className={cn('h-[18px] w-[18px]', spinning && 'animate-spin')}
              strokeWidth={2.4}
            />
          }
        >
          {locked
            ? (lockedLabel ?? 'Quota atteint')
            : spinning
              ? 'La roue tourne…'
              : result?.extra_spin
                ? 'Tour gratuit — relancer'
                : result
                  ? 'Rejouer'
                  : 'Tourner la roue'}
        </Button>
      </div>
    </div>
  );
}
