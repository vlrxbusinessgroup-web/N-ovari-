import { Bell, Cherry, CircleDollarSign, Gem, Gift, Star } from 'lucide-react';
import { cn } from '@/lib/cn';

/**
 * Symboles de jeu — icônes vectorielles Lucide (aucun emoji dans l'interface).
 * Les clés correspondent aux `symbol` renvoyés par la base.
 */
const SYMBOLS = {
  coin: { Icon: CircleDollarSign, tone: 'text-accent-deep', bg: 'bg-accent-tint' },
  star: { Icon: Star, tone: 'text-brand', bg: 'bg-brand-tint' },
  gem: { Icon: Gem, tone: 'text-sky-600', bg: 'bg-sky-50' },
  bell: { Icon: Bell, tone: 'text-amber-600', bg: 'bg-amber-50' },
  cherry: { Icon: Cherry, tone: 'text-red-500', bg: 'bg-red-50' },
  gift: { Icon: Gift, tone: 'text-emerald-600', bg: 'bg-emerald-50' },
} as const;

export type SymbolKey = keyof typeof SYMBOLS;

export function GameSymbol({
  symbol,
  size = 'md',
  className,
}: {
  symbol: string;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}) {
  const config = SYMBOLS[(symbol as SymbolKey) ?? 'coin'] ?? SYMBOLS.coin;
  const Icon = config.Icon;
  const box = { sm: 'h-8 w-8 rounded-lg', md: 'h-11 w-11 rounded-xl', lg: 'h-14 w-14 rounded-2xl' }[size];
  const icon = { sm: 'h-4 w-4', md: 'h-5 w-5', lg: 'h-7 w-7' }[size];

  return (
    <span className={cn('flex items-center justify-center', box, config.bg, className)}>
      <Icon className={cn(icon, config.tone)} strokeWidth={2.2} />
    </span>
  );
}
