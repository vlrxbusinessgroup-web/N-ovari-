import { useState } from 'react';
import {
  ArrowLeft,
  ChevronRight,
  Dices,
  Disc3,
  Gift,
  Hand,
  Lock,
  CalendarDays,
  CheckCircle2,
} from 'lucide-react';
import {
  GAME_META,
  canPlay,
  nextOpeningLabel,
  resolveGameInfo,
  scheduleSummary,
  weekdaysLabel,
  type GameInfo,
  type GameKey,
  type GamePrize,
  type PlayResult,
  GIFT_STATUS_META,
  type GameGift,
} from '@/lib/games';
import { formatFCFA } from '@/lib/format';
import { cn } from '@/lib/cn';
import { VipBadge } from '@/components/ui/Badge';
import { Alert } from '@/components/ui/Feedback';
import { LuckyWheel } from './LuckyWheel';
import { Scratch } from './Scratch';
import { Slots } from './Slots';

const ICONS: Record<GameKey, typeof Disc3> = {
  wheel: Disc3,
  scratch: Hand,
  slots: Dices,
};

const ORDER: GameKey[] = ['wheel', 'scratch', 'slots'];

/**
 * HUB DES JEUX — cadenas et calendrier sur les 20 niveaux.
 * -------------------------------------------------------------
 * • LV1–LV2   : Aucun jeu accessible — cadenas « Débloqué au niveau 3 »
 * • LV3–LV6   : Roue 1×/semaine (Lundi uniquement) · Grattage & Slots verrouillés
 * • LV7–LV11  : Roue 2×/semaine (Lundi, Mercredi) · Grattage 1×/semaine (au choix) · Slots verrouillé
 * • LV12–LV16 : Roue 3×/semaine (Lundi, Mercredi, Vendredi) · Grattage 2×/semaine (au choix) · Slots 1×/semaine (au choix)
 * • LV17–LV20 : Roue, Grattage, Slots 1×/jour chacun + badge « VIP » doré sur chaque carte
 */
export function GamesHub({
  games,
  prizes,
  gifts,
  level,
  hasAccess,
  unlockLevel,
  budget,
  weekdayToday,
  onRefresh,
}: {
  games: GameInfo[];
  prizes: GamePrize[];
  gifts: GameGift[];
  level: number;
  hasAccess: boolean;
  unlockLevel: number;
  budget: { month: number; used: number };
  weekdayToday: number;
  onRefresh: () => Promise<void>;
}) {
  const [active, setActive] = useState<GameKey | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const isVip = level >= 17;
  const byKey = (key: GameKey) =>
    resolveGameInfo(
      key,
      games.find((g) => g.game_key === key),
      level,
      weekdayToday,
    );

  const activeInfo = active ? byKey(active) : undefined;

  const handlePlayed = async (result: PlayResult) => {
    if (result.extra_spin) {
      setNotice('Tour gratuit obtenu : votre quota n’a pas été débité.');
    } else if (result.kind === 'gift') {
      setNotice(`Lot enregistré : ${result.label}. L’équipe N-OVARI vous contacte.`);
    } else if (result.amount > 0) {
      setNotice(`+${formatFCFA(result.amount)} crédités sur votre portefeuille.`);
    } else {
      setNotice(null);
    }
    await onRefresh();
  };

  /* ------------------------------- Jeu ouvert ------------------------------ */

  if (active && activeInfo) {
    const locked = !canPlay(activeInfo);
    const lockedLabel = nextOpeningLabel(activeInfo, weekdayToday, level);
    return (
      <div className="space-y-3">
        <button
          type="button"
          onClick={() => {
            setActive(null);
            setNotice(null);
          }}
          className="flex items-center gap-1.5 text-[12px] font-bold text-brand"
        >
          <ArrowLeft className="h-4 w-4" strokeWidth={2.6} />
          Tous les jeux
        </button>

        <GameAccessBar info={activeInfo} level={level} weekdayToday={weekdayToday} />

        {notice ? <Alert tone="success">{notice}</Alert> : null}

        {active === 'wheel' ? (
          <LuckyWheel
            prizes={prizes}
            locked={locked}
            lockedLabel={lockedLabel}
            onPlayed={handlePlayed}
          />
        ) : active === 'scratch' ? (
          <Scratch locked={locked} lockedLabel={lockedLabel} onPlayed={handlePlayed} />
        ) : (
          <Slots locked={locked} lockedLabel={lockedLabel} onPlayed={handlePlayed} />
        )}
      </div>
    );
  }

  /* --------------------------------- Hub ---------------------------------- */

  const pendingGifts = gifts.filter((g) => g.status === 'pending' || g.status === 'preparing');

  return (
    <div className="space-y-3">
      {/* LV1 et LV2 : Aucun jeu accessible — cadenas avec "Débloqué au niveau 3" */}
      {!hasAccess || level < unlockLevel ? (
        <div className="card flex items-center gap-3 border border-amber-200 bg-amber-50/90 p-4">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-amber-200/80 text-amber-900">
            <Lock className="h-5 w-5" strokeWidth={2.6} />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[12.5px] font-extrabold text-amber-950">
              Débloqué au niveau {unlockLevel}
            </p>
            <p className="mt-0.5 text-[11px] leading-snug text-amber-900/80">
              Aucun jeu n’est accessible aux niveaux LV1 et LV2 (votre niveau : LV{level}). Passez
              au forfait LV{unlockLevel} ou supérieur pour jouer.
            </p>
          </div>
        </div>
      ) : null}

      {ORDER.map((key, index) => {
        const info = byKey(key);
        const meta = GAME_META[key];
        const Icon = ICONS[key];
        const playable = canPlay(info);
        const doneToday = info.plays_done >= info.plays_per_day;
        const weekLimit = info.plays_per_week ?? 7;
        const weekDone = info.plays_done_week ?? 0;
        const doneWeek = weekDone >= weekLimit;
        const comebackLabel = nextOpeningLabel(info, weekdayToday, level);

        return (
          <button
            key={key}
            type="button"
            disabled={!playable}
            onClick={() => setActive(key)}
            className={cn(
              'card flex w-full items-center gap-3 p-4 text-left transition-all',
              playable
                ? 'active:scale-[0.99]'
                : 'cursor-not-allowed bg-slate-50/95 opacity-75',
            )}
          >
            <span
              className={cn(
                'flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl',
                playable
                  ? 'bg-gradient-to-br from-brand to-brand-soft text-white'
                  : 'bg-slate-200/80 text-slate-400',
              )}
            >
              {info.level_ok ? (
                <Icon className="h-6 w-6" strokeWidth={2.2} />
              ) : (
                <Lock className="h-5 w-5" strokeWidth={2.5} />
              )}
            </span>

            <span className="min-w-0 flex-1">
              <span className="flex flex-wrap items-center gap-1.5">
                <span className="text-[13.5px] font-extrabold text-ink">{meta.name}</span>
                {isVip ? <VipBadge className="px-2 py-0.5 text-[9px]" /> : null}
                {playable ? (
                  <span className="rounded-full bg-emerald-50 px-1.5 py-0.5 text-[9px] font-extrabold uppercase text-emerald-700">
                    Ouvert
                  </span>
                ) : null}
              </span>

              <span className="mt-0.5 block text-[11px] text-muted">{meta.description}</span>

              <span className="mt-1 flex items-center gap-1 text-[10.5px] font-semibold text-ink/70">
                {!info.level_ok ? (
                  <>
                    <Lock className="h-3 w-3 shrink-0 text-slate-400" strokeWidth={2.8} />
                    <span>
                      {level <= 2 && info.level_min <= 3
                        ? 'Débloqué au niveau 3 · Niveau 3 requis'
                        : `Niveau ${info.level_min} requis`}
                    </span>
                  </>
                ) : doneToday || doneWeek ? (
                  <>
                    <CheckCircle2 className="h-3 w-3 shrink-0 text-emerald-600" strokeWidth={2.8} />
                    <span>
                      {doneToday ? 'Joué aujourd’hui' : 'Quota hebdo utilisé'} · {comebackLabel}
                    </span>
                  </>
                ) : playable ? (
                  <>
                    <CalendarDays className="h-3 w-3 shrink-0 text-brand" strokeWidth={2.8} />
                    <span>
                      {isVip
                        ? `${info.plays_done}/${info.plays_per_day} aujourd’hui · jouable maintenant`
                        : `${weekDone}/${weekLimit} cette semaine · jouable maintenant`}
                    </span>
                  </>
                ) : (
                  <>
                    <CalendarDays className="h-3 w-3 shrink-0 text-slate-400" strokeWidth={2.8} />
                    <span>{comebackLabel}</span>
                  </>
                )}
              </span>

              <span className="mt-0.5 block text-[10px] text-muted/80">
                {scheduleSummary(info, level)}
              </span>
            </span>

            {/* Bouton / badge d'état à droite de la carte */}
            {playable ? (
              <span className="inline-flex shrink-0 items-center gap-1 rounded-xl bg-brand px-2.5 py-1.5 text-[10.5px] font-extrabold text-white shadow-soft">
                Jouer
                <ChevronRight className="h-3.5 w-3.5" strokeWidth={2.8} />
              </span>
            ) : !info.level_ok ? (
              <span className="inline-flex shrink-0 items-center gap-1 rounded-xl bg-slate-200/80 px-2.5 py-1.5 text-[10px] font-extrabold text-slate-500">
                <Lock className="h-3 w-3" strokeWidth={2.6} />
                {level <= 2 && info.level_min <= 3
                  ? 'Débloqué au niveau 3'
                  : `Niveau ${info.level_min} requis`}
              </span>
            ) : (
              <span className="inline-flex shrink-0 items-center gap-1 rounded-xl bg-slate-200/80 px-2.5 py-1.5 text-[10px] font-extrabold text-slate-500">
                {comebackLabel}
              </span>
            )}
            <span className="sr-only">Jeu {index + 1}</span>
          </button>
        );
      })}

      {/* Lots physiques gagnés */}
      {pendingGifts.length > 0 ? (
        <div className="card p-4">
          <p className="flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-wide text-ink/50">
            <Gift className="h-3.5 w-3.5 text-accent-deep" strokeWidth={2.6} />
            Mes lots à recevoir
          </p>
          <div className="mt-2 space-y-2">
            {pendingGifts.map((gift) => (
              <div
                key={gift.id}
                className="flex items-center justify-between rounded-xl bg-slate-50 px-3 py-2"
              >
                <span className="text-[12px] font-bold text-ink">{gift.prize_label}</span>
                <span
                  className={cn(
                    'rounded-full px-2 py-0.5 text-[9.5px] font-extrabold uppercase',
                    gift.status === 'pending'
                      ? 'bg-accent-tint text-accent-deep'
                      : 'bg-brand-tint text-brand',
                  )}
                >
                  {GIFT_STATUS_META[gift.status].label}
                </span>
              </div>
            ))}
          </div>
        </div>
      ) : null}

      {hasAccess && budget.month > 0 ? (
        <div className="card p-3.5">
          <div className="flex items-center justify-between">
            <p className="text-[10px] font-bold uppercase tracking-wider text-muted">
              Plafond de gains du mois
            </p>
            <p className="text-[10.5px] font-extrabold text-ink/70">
              {formatFCFA(budget.used)} / {formatFCFA(budget.month)}
            </p>
          </div>
          <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-slate-200">
            <div
              className={cn(
                'h-full rounded-full transition-all',
                budget.used >= budget.month
                  ? 'bg-red-400'
                  : 'bg-gradient-to-r from-brand to-brand-soft',
              )}
              style={{
                width: `${
                  budget.month > 0 ? Math.min(100, (budget.used / budget.month) * 100) : 0
                }%`,
              }}
            />
          </div>
        </div>
      ) : null}
    </div>
  );
}

/** Rappel du rythme d'ouverture au-dessus du jeu ouvert */
function GameAccessBar({
  info,
  level,
  weekdayToday,
}: {
  info: GameInfo;
  level: number;
  weekdayToday: number;
}) {
  const playable = canPlay(info);
  const isVip = level >= 17;
  return (
    <div className="flex items-center justify-between gap-2 rounded-2xl bg-white px-3.5 py-2.5 shadow-soft">
      <span className="flex items-center gap-1.5 text-[10.5px] font-semibold text-ink/60">
        <CalendarDays className="h-3.5 w-3.5 text-brand" strokeWidth={2.6} />
        {weekdaysLabel(info.weekdays)}
      </span>
      <div className="flex items-center gap-1.5">
        {isVip ? <VipBadge className="px-2 py-0.5 text-[9px]" /> : null}
        <span
          className={cn(
            'rounded-full px-2 py-0.5 text-[10px] font-extrabold',
            playable ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-muted',
          )}
        >
          {playable
            ? `${info.plays_per_day - info.plays_done} partie restante`
            : nextOpeningLabel(info, weekdayToday, level)}
        </span>
      </div>
    </div>
  );
}
